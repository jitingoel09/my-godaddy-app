/**
 * Jitin Goel - Consultation & Advisory Service Worker
 * Powered by Workbox to enable robust progressive offline features.
 */

// Load Workbox from the official Google CDN
importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.4.1/workbox-sw.js');

if (self.workbox) {
  console.log('âœ¨ Cosmic Workbox Service Worker initialized successfully!');

  // Force incoming service workers to activate immediately to skip waiting queue.
  self.workbox.core.skipWaiting();
  self.workbox.core.clientsClaim();

  // Cache-busting versioned prefixes
  const CACHE_PREFIX = 'jitin-goel-v1';
  const CACHE_NAMES = {
    pages: `${CACHE_PREFIX}-pages`,
    assets: `${CACHE_PREFIX}-assets`,
    images: `${CACHE_PREFIX}-images`,
    fonts: `${CACHE_PREFIX}-fonts`,
  };

  // 1. Pages / Primary Document navigation caching using NetworkFirst.
  // This prioritizes the newest content if online, and drops back instantly to the cached cache-shell when offline.
  self.workbox.routing.registerRoute(
    ({ request }) => request.mode === 'navigate',
    new self.workbox.strategies.NetworkFirst({
      cacheName: CACHE_NAMES.pages,
      plugins: [
        new self.workbox.expiration.ExpirationPlugin({
          maxEntries: 10,
          maxAgeSeconds: 7 * 24 * 60 * 60, // 7 Days
        }),
      ],
    })
  );

  // 2. Bundled React JavaScript & Tailwind Stylesheets (Vite immutable assets).
  // Uses CacheFirst since Vite files are fully content-hashed and immutable.
  self.workbox.routing.registerRoute(
    ({ request }) =>
      request.destination === 'script' ||
      request.destination === 'style',
    new self.workbox.strategies.CacheFirst({
      cacheName: CACHE_NAMES.assets,
      plugins: [
        new self.workbox.expiration.ExpirationPlugin({
          maxEntries: 50,
          maxAgeSeconds: 30 * 24 * 60 * 60, // 30 Days
        }),
      ],
    })
  );

  // 3. Image caching (all local icons, portraits, and Unsplash photographs for dynamic blog posts).
  // Utilizes CacheFirst to prevent redundant external Unsplash asset calls and speed up visual presentation.
  self.workbox.routing.registerRoute(
    ({ request }) => request.destination === 'image',
    new self.workbox.strategies.CacheFirst({
      cacheName: CACHE_NAMES.images,
      plugins: [
        new self.workbox.cacheableResponse.CacheableResponsePlugin({
          statuses: [0, 200], // Cache opaque responses too
        }),
        new self.workbox.expiration.ExpirationPlugin({
          maxEntries: 80,
          maxAgeSeconds: 30 * 24 * 60 * 60, // 30 Days
          purgeOnQuotaError: true,
        }),
      ],
    })
  );

  // 4. Google Fonts Stylesheets and Font Files caching.
  // Leverages CacheFirst to secure immediate loading of custom display & mono typography.
  self.workbox.routing.registerRoute(
    ({ url }) => url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com',
    new self.workbox.strategies.CacheFirst({
      cacheName: CACHE_NAMES.fonts,
      plugins: [
        new self.workbox.cacheableResponse.CacheableResponsePlugin({
          statuses: [0, 200],
        }),
        new self.workbox.expiration.ExpirationPlugin({
          maxEntries: 20,
          maxAgeSeconds: 365 * 24 * 60 * 60, // 1 Year
        }),
      ],
    })
  );

  // Fallback array for immediate caching on service worker installation
  const STATIC_SHELL = [
    '/',
    '/index.html',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Playfair+Display:wght@300;400;500;600;700&display=swap'
  ];

  self.addEventListener('install', (event) => {
    event.waitUntil(
      caches.open(CACHE_NAMES.pages).then((cache) => {
        return cache.addAll(STATIC_SHELL);
      })
    );
  });
} else {
  console.error('âŒ Workbox failed to download or parse.');
}
