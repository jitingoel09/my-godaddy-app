/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Navbar } from './components/Navbar';
import { ProgressBar } from './components/ProgressBar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { ValueProposition } from './components/ValueProposition';
import { startPerfInstrumentation, notePerfMutation, useRenderCountDev } from './dev/perfInstrumentation';
import { BackToTop } from './components/BackToTop';
import { Chatbot } from './components/Chatbot';
import { DailyThought } from './components/DailyThought';
import { StrategyWisdomBand } from './components/StrategyWisdomBand';
import { WhoThisIsFor } from './components/WhoThisIsFor';
import { StartHere } from './components/StartHere';
import { ReflectExperience } from './components/ReflectExperience';
import { WhyStrategyAlone } from './components/WhyStrategyAlone';
import { ConsultationProcess } from './components/ConsultationProcess';
import { DecisionDriftQuiz } from './components/DecisionDriftQuiz';
import { MobileBookNow } from './components/MobileBookNow';
import { ShareButton } from './components/ShareButton';

import { SectionDivider } from './components/SectionDivider';
import { motion, AnimatePresence, MotionConfig } from 'motion/react';
import { audioEngine } from './lib/audio';
import { WifiOff } from 'lucide-react';

const Blog = lazy(() => import('./components/Blog').then(m => ({ default: m.Blog })));
const CosmicTools = lazy(() => import('./components/CosmicTools').then(m => ({ default: m.CosmicTools })));
// Far-below-the-fold sections (last ~6 sections on the page) — code-split
// via the exact same lazy()+Suspense pattern already used for Blog and
// CosmicTools above. This reduces the initial JS bundle that must be
// parsed/executed on first load; each still renders fully once its chunk
// resolves (near-instant on any reasonable connection), so SEO-crawlers
// that execute JS and content-visibility are unaffected — same guarantee
// the existing Blog/CosmicTools lazy-loading already relies on.
const FAQ = lazy(() => import('./components/FAQ').then(m => ({ default: m.FAQ })));
const BattleTested = lazy(() => import('./components/BattleTested').then(m => ({ default: m.BattleTested })));
const Contact = lazy(() => import('./components/Contact').then(m => ({ default: m.Contact })));
const Newsletter = lazy(() => import('./components/Newsletter').then(m => ({ default: m.Newsletter })));
const Footer = lazy(() => import('./components/Footer').then(m => ({ default: m.Footer })));

function SectionSkeleton() {
  return (
    <div className="py-24 space-y-12 animate-pulse w-full max-w-7xl mx-auto px-6">
      <div className="h-10 bg-white/5 rounded-md w-1/3 mx-auto"></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-64 bg-white/5 border border-white/10 rounded-2xl"></div>
        ))}
      </div>
    </div>
  );
}

function SectionReveal({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

const sectionTitles: Record<string, string> = {
  home: 'Jitin Goel Consulting | Strategic Clarity for Growth',
  about: 'Jitin Goel - My Journey',
  services: 'Jitin Goel - Services',
  'interactive-tools': 'Jitin Goel - Cosmic Tools',
  book: 'Jitin Goel - Book Appointment',
  packages: 'Jitin Goel - Packages',
  faq: 'Jitin Goel - FAQ',
  blog: 'Jitin Goel - Insights & Updates',
  contact: 'Jitin Goel - Contact',
};

const sectionDescriptions: Record<string, string> = {
  home: 'Strategic clarity for business growth, career direction, personal transformation, and cosmic decision-support. Practical consulting, not generic advice.',
  about: "Jitin Goel's background: 20+ years in the boardroom and 26 years reading Vedic cycles, combining corporate strategy with astrological timing.",
  services: 'Business Strategy & Growth, Career & Professional Consulting, Personal Transformation, and Cosmic Astrology Consultation — bespoke services for real decisions.',
  'interactive-tools': 'Free numerology and Vastu Shastra calculators — practical, quick tools to guide your next business or personal decision.',
  book: 'Book a private consultation with Jitin Goel for business strategy, career direction, personal clarity, or Vedic timing guidance.',
  packages: 'Consulting packages designed for founders, executives, and individuals seeking structured, ongoing strategic support.',
  faq: 'Answers to common questions about the consulting process, astrology consultations, and how Vedic wisdom integrates with business strategy.',
  blog: 'Insights on business strategy, career growth, Vedic astrology, numerology, and Vastu Shastra — practical articles for real-world decisions.',
  contact: 'Get in touch with Jitin Goel Consulting to start your strategic clarity journey — business, career, personal, or Vedic timing guidance.',
};

export default function App() {
  useRenderCountDev("App");
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    if (import.meta.env.DEV) startPerfInstrumentation();
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        // Find the deeply intersecting entry (we only update if it is intersecting)
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            if (id && sectionTitles[id]) {
              document.title = sectionTitles[id];
              const metaDesc = document.querySelector('meta[name="description"]');
              if (metaDesc && sectionDescriptions[id]) {
                metaDesc.setAttribute('content', sectionDescriptions[id]);
              }
            }
          }
        });
      },
      { rootMargin: '-40% 0px -60% 0px' }
    );

    const observeSections = () => {
      const sections = document.querySelectorAll('section[id]');
      sections.forEach((section) => observer.observe(section));
    };

    observeSections();

    // Observe body for injected/lazy-loaded sections. Debounced via rAF:
    // a burst of DOM mutations (very common — React batches many changes
    // together, e.g. a modal opening or the calendar re-rendering) would
    // otherwise trigger a full document.querySelectorAll re-scan on EVERY
    // single mutation. Collapsing bursts into one re-scan per frame keeps
    // the same behavior (new sections still get observed) with far less
    // redundant DOM-querying work.
    let mutationRafId: number | null = null;
    const mutationObserver = new MutationObserver(() => {
      if (import.meta.env.DEV) notePerfMutation();
      if (mutationRafId !== null) return;
      mutationRafId = requestAnimationFrame(() => {
        mutationRafId = null;
        observeSections();
        window.dispatchEvent(new CustomEvent("jg:sections-mutated"));
      });
    });

    mutationObserver.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
      if (mutationRafId !== null) cancelAnimationFrame(mutationRafId);
    };
  }, []);



  useEffect(() => {
    const handleInteraction = () => {
      audioEngine.play();
      ['mousedown', 'keydown', 'touchstart'].forEach(env => 
        window.removeEventListener(env, handleInteraction)
      );
    };
    ['mousedown', 'keydown', 'touchstart'].forEach(env => 
      window.addEventListener(env, handleInteraction, { once: true })
    );

    return () => {
      ['mousedown', 'keydown', 'touchstart'].forEach(env => 
        window.removeEventListener(env, handleInteraction)
      );
    };
  }, []);

  return (
    <MotionConfig reducedMotion="user">
    <div className="min-h-screen font-sans text-text-main selection:bg-gold-500 selection:text-brand-900 relative">
      <div className="noise-bg"></div>
      <ProgressBar />
      <Navbar />
      <main className="relative z-10 w-full overflow-hidden">
        <Hero />
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><DecisionDriftQuiz /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><WhoThisIsFor /></SectionReveal>
        <SectionReveal><StartHere /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><ReflectExperience /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><StrategyWisdomBand /></SectionReveal>
        <SectionReveal><WhyStrategyAlone /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><Services /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><About /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><ValueProposition /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><ConsultationProcess /></SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal><DailyThought /></SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <CosmicTools />
          </Suspense>
        </SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <FAQ />
          </Suspense>
        </SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <BattleTested />
          </Suspense>
        </SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <Contact />
          </Suspense>
        </SectionReveal>
        <SectionReveal><SectionDivider /></SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <Newsletter />
          </Suspense>
        </SectionReveal>
        <SectionReveal>
          <Suspense fallback={<SectionSkeleton />}>
            <Blog />
          </Suspense>
        </SectionReveal>
      </main>
      <Suspense fallback={<SectionSkeleton />}>
        <Footer />
      </Suspense>
      <BackToTop />
      <ShareButton />
      <Chatbot />
      <MobileBookNow />

      {/* Floating Offline Status notification banner */}
      <AnimatePresence>
        {!isOnline && (
          <motion.div
            initial={{ opacity: 0, y: -45, x: "-50%", scale: 0.95 }}
            animate={{ opacity: 1, y: 0, x: "-50%", scale: 1 }}
            exit={{ opacity: 0, y: -30, x: "-50%", scale: 0.95 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 px-5 py-3.5 rounded-full bg-brand-900/90 backdrop-blur-xl border border-gold-500/30 text-gold-400 font-sans text-xs flex items-center gap-3.5 shadow-2xl max-w-[90vw] sm:max-w-md pointer-events-auto"
            style={{ originX: 0.5 }}
          >
            <div className="flex h-2 w-2 relative flex-shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-gold-500"></span>
            </div>
            <WifiOff className="w-4 h-4 text-gold-500 flex-shrink-0" />
            <span className="leading-snug">
              offline mode active. Content synced to your device memory.
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
    </MotionConfig>
  );
}
