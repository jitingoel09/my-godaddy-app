import { motion } from "motion/react";
import { Sparkles, Briefcase, Star, ShieldCheck, Target } from "lucide-react";
import vastuImg from "../assets/images/indian_office_vastu_1780754658041.webp";
import cosmicModernEthos from "../assets/images/ethos_cosmic_clarity_1781077305949.webp";
import imgCorporatePortrait from "../assets/images/jitin_about_portrait.webp";
import { useCustomImages } from "../hooks/useCustomImages";

export function About() {
  const { profileImage } = useCustomImages();

  return (
    <section
      id="about"
      className="py-14 bg-page-bg-900 border-t border-gold-500/20 text-text-main relative overflow-hidden"
    >
      <div
        className="absolute inset-0 opacity-[0.07] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${vastuImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-900 via-transparent to-page-bg-900 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-8"
          >
            <div className="mb-8">
              <h3 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
                About Jitin Goel Consulting
              </h3>
              <h2 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif mb-4 font-normal">
                Precision Strategy. <span className="gold-underline text-gold-400">Perfect Timing.</span>
              </h2>
              <p className="text-sm sm:text-base text-text-main italic border-l-2 border-gold-500/50 pl-4 font-serif">
                "True leadership is the master alignment of timely commercial action with profound inner clarity."
              </p>
            </div>

            <div className="text-text-main opacity-100 space-y-7 leading-relaxed font-normal">
              <div className="flex flex-col sm:flex-row gap-6 items-center flex-wrap sm:flex-nowrap bg-brand-800/30 p-5 rounded-2xl border border-gold-500/10 mb-6">
                <div className="relative shrink-0 rounded-xl overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
                  <img
                    src={profileImage || imgCorporatePortrait}
                    alt="Jitin Goel - 20+ Year Leadership Experience"
                    className="small-profile-avatar w-32 h-32 sm:w-36 sm:h-36 object-cover"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{ boxShadow: 'inset 0 0 22px 8px rgba(0,0,0,0.55)' }}
                    aria-hidden="true"
                  ></div>
                </div>
                <div>
                  <p className="text-xs sm:text-sm text-text-main font-normal">
                    Jitin Goel Consulting is built on one core belief: business, career, personal life, and timing are not separate — they influence each other. Jitin brings <strong className="text-gold-500 font-medium inline-flex items-center gap-1.5"><Briefcase className="w-4 h-4 text-gold-500/80" /> 20+ years of executive leadership</strong> in sales, operations, and business strategy, paired with <strong className="text-gold-500 font-medium inline-flex items-center gap-1.5"><Star className="w-4 h-4 text-gold-500/80" /> 26 years studying Vedic astrology</strong>. Together, these two disciplines examine your complete picture — not just one piece of it.
                  </p>
                </div>
              </div>
              <div className="space-y-4 text-text-main">
                <p>
                  My practice spans four areas: <strong className="text-gold-500 font-medium">Business Strategy & Growth Consulting, Career & Professional Consulting, Personal Transformation Consulting,</strong> and <strong className="text-gold-500 font-medium inline-flex items-center gap-1.5"><Star className="w-4 h-4 text-gold-500/80" /> Cosmic Astrology Consultation</strong>.
                </p>
                
                <div className="bg-brand-950/50 border border-gold-500/20 shadow-inner p-5 sm:p-6 rounded-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gold-500/5 rounded-bl-full pointer-events-none transition-transform duration-700 group-hover:scale-110"></div>
                  <h4 className="text-[11px] sm:text-xs font-mono text-gold-500 uppercase tracking-widest font-bold flex items-center gap-2.5 mb-1">
                    <Sparkles className="w-4 h-4" />
                    The JG Double Helix Framework
                  </h4>
                  <p className="text-[10px] sm:text-xs text-gold-400/70 italic mb-3 font-serif">
                    Where Strategy and Timing Interconnect
                  </p>
                  <p className="text-xs text-text-main/60 mb-4 leading-relaxed">
                    My signature methodology: two strands — Strategy and Timing — examined together, because a decision made with the right plan but the wrong timing is still the wrong decision.
                  </p>
                  <div className="space-y-4 relative z-10">
                    <p className="text-sm leading-relaxed text-text-main/90 border-l-[3px] border-gold-500/20 pl-4 py-0.5">
                      <strong className="text-gold-400 font-semibold">Strand One — Timing</strong>: I map planetary cycles (<em className="text-gold-400 not-italic uppercase text-[10px] tracking-wider font-semibold">Dasha</em>) and transits (<em className="text-gold-400 not-italic uppercase text-[10px] tracking-wider font-semibold">Gochar</em>) as decision support, helping you time major moves and navigate transitions with clarity.
                    </p>
                    <p className="text-sm leading-relaxed text-text-main/90 border-l-[3px] border-gold-500/20 pl-4 py-0.5">
                      <strong className="text-gold-400 font-semibold">Strand Two — Strategy</strong>: I diagnose organizational bottlenecks, accelerate revenue growth, and prepare executives for senior appointments with practical, decision-ready guidance.
                    </p>
                  </div>
                </div>

                <p>
                  Business clarity and personal conviction go hand in hand — we help you lead your market with confidence, at every stage of growth.
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
            className="flex flex-col gap-8 justify-center items-center h-full relative w-full"
          >
            <div className="bg-brand-800 border border-gold-500 text-text-main p-6 sm:p-10 shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5)] rounded-2xl relative overflow-hidden group max-w-md w-full">
              <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent"></div>
              
              {/* Photo representation in The Ethos as per headline */}
              <div className="w-full h-44 rounded-xl overflow-hidden mb-6 border border-gold-500/20 relative z-10">
                <img 
                  src={cosmicModernEthos} 
                  alt="Vedic Astrology meets Corporate Strategy Ethos" 
                  className="w-full h-full object-cover opacity-100 transition-transform duration-700 group-hover:scale-105" 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-800 via-brand-800/10 to-transparent"></div>
              </div>

              <div className="relative z-10 flex flex-col items-center justify-center text-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gold-500/20 flex items-center justify-center text-gold-500 group-hover:scale-110 transition-transform duration-500">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-gold-400 font-bold mb-2">The Ethos</div>
                  <p className="font-serif text-2xl mb-4 text-amber-400 group-hover:text-amber-300 transition-colors drop-shadow-sm">
                    The Master Vision
                  </p>
                  <p className="text-xs sm:text-sm text-text-main leading-relaxed font-normal space-y-4">
                    <span className="block mb-3">
                      To help founders, executives, and professionals make clearer decisions — in business, in career, and in the choices that shape both.
                    </span>
                    <span className="block">
                      Real business experience and Vedic timing intelligence, examined together — not as separate disciplines, but as one complete picture.
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Foundation & Credentials */}
        <motion.div
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.25 }}
          className="mt-24 pt-16 border-t border-gold-500/20"
        >
          <div className="text-center max-w-3xl mx-auto mb-10 px-4">
            <h3 className="text-2xl sm:text-3xl font-serif text-gold-400 drop-shadow-sm font-medium mb-3">
              Built on Two Decades of Real Experience
            </h3>
            <p className="max-w-xl mx-auto text-text-main/80 font-normal text-sm sm:text-base">
              Jitin Goel Consulting was founded to channel over 20 years of hands-on corporate leadership — across sales, operations, and business strategy — directly into practical consulting for our clients.
            </p>
          </div>

          <div className="bg-brand-800/50 border border-gold-500/20 rounded-2xl p-5 sm:p-7 backdrop-blur-sm max-w-4xl mx-auto">

            <div className="text-left mb-6 pb-4 border-b border-gold-500/10">
              <div className="text-[10px] uppercase tracking-[0.2em] text-gold-500 font-bold mb-1 font-mono">
                My Foundation
              </div>
              <h4 className="text-xl sm:text-2xl font-serif text-text-main">
                Real Experience, Applied Directly
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-4 rounded-xl bg-brand-950/40 border border-gold-500/10">
                <Star className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-text-main mb-1">26 Years of Vedic Astrology Study</div>
                  <div className="text-xs text-text-main/70 leading-relaxed">Chart analysis and timing, used as decision support — not superstition.</div>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 rounded-xl bg-brand-950/40 border border-gold-500/10">
                <Briefcase className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-text-main mb-1">20+ Years in Enterprise Leadership</div>
                  <div className="text-xs text-text-main/70 leading-relaxed">Sales, operations, and strategy at the executive level — hands-on, not theory.</div>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 rounded-xl bg-brand-950/40 border border-gold-500/10">
                <Target className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-text-main mb-1">4 Focused Specializations</div>
                  <div className="text-xs text-text-main/70 leading-relaxed">Business, professional, personal, and astrology consulting — each with a dedicated, structured approach.</div>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 rounded-xl bg-brand-950/40 border border-gold-500/10">
                <ShieldCheck className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-text-main mb-1">Direct, Personal Engagement</div>
                  <div className="text-xs text-text-main/70 leading-relaxed">Every consultation is worked directly with Jitin — no junior handoffs, no templated advice.</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-gold-500/10 w-full">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-serif text-gold-500 mb-1">20+</div>
                <div className="text-[10px] sm:text-xs text-text-main uppercase tracking-wider">Years Leadership Experience</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-serif text-gold-500 mb-1">4</div>
                <div className="text-[10px] sm:text-xs text-text-main uppercase tracking-wider">Core Specializations</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-serif text-gold-500 mb-1">100%</div>
                <div className="text-[10px] sm:text-xs text-text-main uppercase tracking-wider">Direct Client Commitment</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
