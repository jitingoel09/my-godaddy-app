import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUp } from "lucide-react";

import { useRenderCountDev } from "../dev/perfInstrumentation";

export function BackToTop() {
  useRenderCountDev("BackToTop");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 500) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility, { passive: true });

    return () => {
      window.removeEventListener("scroll", toggleVisibility);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={scrollToTop}
          className="floating-control-widget scroll-to-top-btn"
          aria-label="Back to top"
        >
          <ArrowUp className="w-[1.1em] h-[1.1em]" strokeWidth={1.5} />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
