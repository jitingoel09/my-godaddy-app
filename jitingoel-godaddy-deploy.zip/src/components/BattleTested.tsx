import { motion } from "motion/react";
import { ShieldCheck } from "lucide-react";
import chairsImg from "../assets/images/boardroom_chairs_authority.webp";

export function BattleTested() {
  return (
    <section id="battle-tested" className="py-16 bg-page-bg-800 relative border-t border-b border-gold-500/10 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.10] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${chairsImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-800 via-transparent to-page-bg-800 pointer-events-none"></div>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-12 h-12 rounded-full bg-[#8B3005] border border-gold-500/30 flex items-center justify-center mx-auto mb-5">
            <ShieldCheck className="w-5 h-5 text-gold-400" />
          </div>
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-gold-500 mb-4 font-mono font-bold">
            Why Trust This
          </h2>
          <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif text-text-main font-bold tracking-tight mb-6 leading-tight">
            Battle-Tested in the Corporate World
          </h3>
          <div className="space-y-4 text-sm sm:text-base text-text-main/80 leading-relaxed">
            <p>
              I haven't spent my career consulting from the sidelines. I've spent it <strong className="text-gold-400 font-semibold">managing enterprise sales and operations</strong> — real budgets, real teams, real numbers, for over 20 years.
            </p>
            <p>
              When I tell you something will work, it's not theory. It's execution I've already lived through, under the kind of pressure that doesn't leave room for guesswork.
            </p>
            <p className="font-medium text-text-main">
              You're not hiring an idea. You're hiring two decades of decisions that had to be right.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
