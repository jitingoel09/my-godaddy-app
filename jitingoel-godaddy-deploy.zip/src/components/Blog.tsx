import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Share2, X, ChevronLeft, ChevronRight, Link as LinkIcon, Check, Download, Linkedin, Search } from "lucide-react";
import { LikeButton } from "./LikeButton";
import { blogPosts as staticBlogPosts } from "../data/blogPosts";
import { API_BASE_URL } from "../config";
import { LazyImage } from "./LazyImage";
import { getBlogImage, getBlogSecondaryImage, getBlogTertiaryImage } from "../utils/imageRegistry";
import { safeOpenLink } from "../utils/navigation";
import blogFallbackImg from "../assets/images/glass_pattern_astrology.webp";

export function Blog() {
  const [posts, setPosts] = useState(staticBlogPosts);
  const [selectedPost, setSelectedPost] = useState<(typeof staticBlogPosts)[0] | null>(null);
  const wasPostEverOpened = useRef(false);
  const [copiedPostId, setCopiedPostId] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Pull the latest articles from the Google Sheet (if configured) so Jitin can
  // publish a new post weekly without needing a code change. If the sheet isn't
  // set up yet, or the request fails, we simply keep the bundled static posts —
  // the blog section never breaks or shows empty.
  React.useEffect(() => {
    fetch(`${API_BASE_URL}/api/blog-posts`)
      .then((res) => res.json())
      .then((data) => {
        if (data && data.source === "sheet" && Array.isArray(data.posts) && data.posts.length > 0) {
          setPosts(data.posts);
        }
      })
      .catch(() => {
        // Network error or endpoint unavailable — silently keep static posts.
      });
  }, []);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const { clientWidth } = scrollRef.current;
      const scrollAmount = direction === "left" ? -clientWidth : clientWidth;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  React.useEffect(() => {
    const handleOpenPostEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ postId: number }>;
      const post = posts.find((p) => p.id === customEvent.detail.postId);
      if (post) {
        setSelectedPost(post);
      }
    };

    window.addEventListener("open-blog-post", handleOpenPostEvent as EventListener);

    const params = new URLSearchParams(window.location.search);
    const postId = params.get("post");
    if (postId) {
      const post = posts.find((p) => p.id === parseInt(postId, 10));
      if (post) {
        // Wait for next tick so layout is ready, then show modal
        setTimeout(() => setSelectedPost(post), 100);
      }
    }

    return () => {
      window.removeEventListener("open-blog-post", handleOpenPostEvent as EventListener);
    };
  }, []);

  React.useEffect(() => {
    if (selectedPost) {
      wasPostEverOpened.current = true;
      document.body.style.overflow = "hidden";
      document.title = `${selectedPost.title} | Jitin Goel - Insights`;

      const updateMetaTag = (property: string, content: string) => {
        let el =
          document.querySelector(`meta[property="${property}"]`) ||
          document.querySelector(`meta[name="${property}"]`);
        if (el) {
          el.setAttribute("content", content);
        } else {
          el = document.createElement("meta");
          if (property.startsWith("og:") || property.startsWith("article:")) {
            el.setAttribute("property", property);
          } else {
            el.setAttribute("name", property);
          }
          el.setAttribute("content", content);
          document.head.appendChild(el);
        }
      };

      updateMetaTag("og:title", selectedPost.title);
      updateMetaTag("og:type", "article");
      updateMetaTag("article:published_time", new Date(selectedPost.date).toISOString());
      updateMetaTag("article:author", "https://jitingoel.com/#jitingoel");
      updateMetaTag("article:section", selectedPost.category);
      updateMetaTag("og:description", selectedPost.excerpt);
      updateMetaTag("description", selectedPost.excerpt);
      updateMetaTag("og:url", window.location.href);
      updateMetaTag("og:image", getBlogImage(selectedPost.id));

      let canonicalEl = document.querySelector('link[rel="canonical"]');
      if (canonicalEl) {
        canonicalEl.setAttribute("href", `https://jitingoel.com/?post=${selectedPost.id}`);
      }
      updateMetaTag("twitter:title", selectedPost.title);
      updateMetaTag("twitter:description", selectedPost.excerpt);
      updateMetaTag("twitter:image", getBlogImage(selectedPost.id));

      // Inject per-post structured data (JSON-LD) so each of the 27 posts
      // gets its own BlogPosting rich-snippet when viewed, not just the
      // 2 static examples baked into index.html.
      let ldScript = document.getElementById("dynamic-blog-jsonld") as HTMLScriptElement | null;
      if (!ldScript) {
        ldScript = document.createElement("script");
        ldScript.id = "dynamic-blog-jsonld";
        ldScript.type = "application/ld+json";
        document.head.appendChild(ldScript);
      }
      ldScript.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "BlogPosting",
            "@id": `https://jitingoel.com/?post=${selectedPost.id}`,
            "headline": selectedPost.title,
            "description": selectedPost.excerpt,
            "image": getBlogImage(selectedPost.id),
            "url": window.location.href,
            "datePublished": new Date(selectedPost.date).toISOString().split("T")[0],
            "author": { "@id": "https://jitingoel.com/#jitingoel" },
            "publisher": { "@id": "https://jitingoel.com/#professional-service" },
          },
          {
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://jitingoel.com/" },
              { "@type": "ListItem", "position": 2, "name": "Insights", "item": "https://jitingoel.com/#blog" },
              { "@type": "ListItem", "position": 3, "name": selectedPost.title, "item": window.location.href },
            ],
          },
        ],
      });

      const url = new URL(window.location.href);
      url.searchParams.set("post", selectedPost.id.toString());
      // retain existing hash
      window.history.replaceState({}, "", url.toString());
    } else if (wasPostEverOpened.current) {
      document.body.style.overflow = "auto";
      document.title = "Jitin Goel - Insights & Updates";

      const updateMetaTag = (property: string, content: string) => {
        const el =
          document.querySelector(`meta[property="${property}"]`) ||
          document.querySelector(`meta[name="${property}"]`);
        if (el) {
          el.setAttribute("content", content);
        }
      };

      updateMetaTag(
        "og:title",
        "Jitin - Vedic Astrology, Business Strategy & Professional Consulting"
      );
      updateMetaTag("og:type", "website");
      ["article:published_time", "article:author", "article:section"].forEach((prop) => {
        const el = document.querySelector(`meta[property="${prop}"]`);
        if (el) el.remove();
      });
      updateMetaTag(
        "og:description",
        "Expert consultation combining Vedic Astrology, Business Strategy, and Professional Consulting to transform your future."
      );
      updateMetaTag(
        "description",
        "Strategic clarity for business growth, career direction, personal transformation, and cosmic decision-support. Practical consulting, not generic advice."
      );
      updateMetaTag(
        "og:image",
        "https://jitingoel.com/og-image.jpg"
      );
      updateMetaTag(
        "twitter:title",
        "Jitin - Vedic Astrology, Business Strategy & Professional Consulting"
      );
      updateMetaTag(
        "twitter:description",
        "Expert consultation combining Vedic Astrology, Business Strategy, and Professional Consulting to transform your future."
      );
      updateMetaTag(
        "twitter:image",
        "https://jitingoel.com/og-image.jpg"
      );
      updateMetaTag("og:url", "https://jitingoel.com/");

      const canonicalEl = document.querySelector('link[rel="canonical"]');
      if (canonicalEl) {
        canonicalEl.setAttribute("href", "https://jitingoel.com/");
      }

      const dynamicLd = document.getElementById("dynamic-blog-jsonld");
      if (dynamicLd) dynamicLd.remove();

      const url = new URL(window.location.href);
      url.searchParams.delete("post");
      window.history.replaceState({}, "", url.toString());
    }
  }, [selectedPost]);

  const handleCopyLink = (e: React.MouseEvent, post: (typeof staticBlogPosts)[0]) => {
    e.stopPropagation();
    const url = window.location.href; 
    navigator.clipboard.writeText(url).then(() => {
      setCopiedPostId(post.id);
      setTimeout(() => setCopiedPostId(null), 2000);
    });
  };

  const handleShare = (e: React.MouseEvent, post: (typeof staticBlogPosts)[0]) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator
        .share({
          title: post.title,
          text: post.excerpt,
          url: window.location.href, // Since we don't have separate blog pages yet
        })
        .catch(console.error);
    } else {
      // Fallback for browsers that do not support navigator.share
      const message = `Check out this article: ${post.title}\n\n${window.location.href}`;
      safeOpenLink(`https://wa.me/?text=${encodeURIComponent(message)}`);
    }
  };

  const handleLinkedInShare = (e: React.MouseEvent, _post: (typeof staticBlogPosts)[0]) => {
    e.stopPropagation();
    const url = encodeURIComponent(window.location.href);
    safeOpenLink(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`);
  };

  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState(false);
  
  const handleDownloadPdf = async (e: React.MouseEvent, post: (typeof staticBlogPosts)[0]) => {
    e.stopPropagation();
    setIsDownloading(true);
    setDownloadError(false);
    
    // Structure to hold style backup states
    const backups: { element: HTMLStyleElement; originalText: string }[] = [];
    const linkBackups: { element: HTMLLinkElement; disabled: boolean; replacementStyle?: HTMLStyleElement }[] = [];
    const inlineBackups: { element: HTMLElement; originalStyle: string }[] = [];
    
    try {
      // 1. Precise mathematical and Canvas-fallback OKLCH/OKLAB converter
      const parsePercentOrFloat = (val: string): number => {
        if (val.endsWith('%')) {
          return parseFloat(val) / 100;
        }
        return parseFloat(val);
      };

      const oklabToRgbString = (L: number, a: number, b: number, A: number): string => {
        const l = L + 0.3963377774 * a + 0.2158037573 * b;
        const m = L - 0.1055613458 * a - 0.0638541728 * b;
        const s = L - 0.0894841775 * a - 1.2914855480 * b;
        
        const l_cube = l * l * l;
        const m_cube = m * m * m;
        const s_cube = s * s * s;
        
        const r_linear = +4.0767416621 * l_cube - 3.3077115913 * m_cube + 0.2309699292 * s_cube;
        const g_linear = -1.2684380046 * l_cube + 2.6097574011 * m_cube - 0.3413193965 * s_cube;
        const b_linear = -0.0041960863 * l_cube - 0.7034186147 * m_cube + 1.7076147010 * s_cube;
        
        const toSRGB = (c: number): number => {
          if (c <= 0.0031308) {
            return 12.92 * c;
          } else {
            return 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
          }
        };
        
        const rVal = Math.max(0, Math.min(255, Math.round(toSRGB(r_linear) * 255)));
        const gVal = Math.max(0, Math.min(255, Math.round(toSRGB(g_linear) * 255)));
        const bVal = Math.max(0, Math.min(255, Math.round(toSRGB(b_linear) * 255)));
        
        return `rgba(${rVal}, ${gVal}, ${bVal}, ${A})`;
      };

      const convertOklchToRgb = (oklchStr: string): string | null => {
        const matches = oklchStr.match(/oklch\s*\(\s*([0-9.]+%?)\s+([0-9.]+%?)\s+([0-9.-]+(?:deg|rad|turn)?)(?:\s*\/\s*([0-9.]+%?))?\s*\)/i);
        if (!matches) return null;
        
        const L = parsePercentOrFloat(matches[1]);
        const C = parsePercentOrFloat(matches[2]);
        const H_str = matches[3];
        const A = matches[4] ? parsePercentOrFloat(matches[4]) : 1;
        
        let H = 0;
        if (H_str.endsWith('deg')) {
          H = parseFloat(H_str);
        } else if (H_str.endsWith('rad')) {
          H = parseFloat(H_str) * (180 / Math.PI);
        } else if (H_str.endsWith('turn')) {
          H = parseFloat(H_str) * 360;
        } else {
          H = parseFloat(H_str);
        }
        
        const hRad = H * (Math.PI / 180);
        const a = C * Math.cos(hRad);
        const b = C * Math.sin(hRad);
        
        return oklabToRgbString(L, a, b, A);
      };

      const convertOklabToRgb = (oklabStr: string): string | null => {
        const matches = oklabStr.match(/oklab\s*\(\s*([0-9.]+%?)\s+([0-9.-]+%?)\s+([0-9.-]+%?)(?:\s*\/\s*([0-9.]+%?))?\s*\)/i);
        if (!matches) return null;
        
        const L = parsePercentOrFloat(matches[1]);
        const a = parsePercentOrFloat(matches[2]);
        const b = parsePercentOrFloat(matches[3]);
        const A = matches[4] ? parsePercentOrFloat(matches[4]) : 1;
        
        return oklabToRgbString(L, a, b, A);
      };

      const convertColorToRgb = (colorStr: string): string => {
        if (!colorStr) return colorStr;
        
        // Try exact math parser first (extremely fast and highly accurate)
        if (colorStr.toLowerCase().startsWith('oklch')) {
          const mathResult = convertOklchToRgb(colorStr);
          if (mathResult) return mathResult;
        }
        if (colorStr.toLowerCase().startsWith('oklab')) {
          const mathResult = convertOklabToRgb(colorStr);
          if (mathResult) return mathResult;
        }
        
        // Fallback to Canvas based parsing if needed
        try {
          const canvas = document.createElement('canvas');
          canvas.width = 1;
          canvas.height = 1;
          const ctx = canvas.getContext('2d');
          if (!ctx) return 'rgba(0,0,0,0)';
          
          ctx.fillStyle = colorStr;
          ctx.fillRect(0, 0, 1, 1);
          const [r, g, b, a] = ctx.getImageData(0, 0, 1, 1).data;
          return `rgba(${r}, ${g}, ${b}, ${+(a / 255).toFixed(3)})`;
        } catch (err) {
          console.warn("Color conversion fallback failed for", colorStr, err);
          return 'rgba(0,0,0,0)';
        }
      };

      const cleanCssText = (cssText: string): string => {
        // Tailwind v4 emits THREE patterns that html2canvas can't parse:
        //   oklch(...)                      -- direct function call
        //   oklab(...)                      -- direct function call
        //   color-mix(in oklab, ...)        -- used by opacity-modifier utilities like bg-brand-900/60
        // The old regex /(oklch|oklab)\([^)]+\)/ only caught the first two, and even then broke on
        // nested parens (e.g. values containing var(--x) or calc()). This scans for balanced
        // parentheses so nested calls are captured whole before handing off to convertColorToRgb.
        const functionNames = ['color-mix', 'oklch', 'oklab'];
        let result = '';
        let i = 0;
        while (i < cssText.length) {
          let matchedFn: string | null = null;
          for (const fn of functionNames) {
            if (cssText.startsWith(fn + '(', i)) {
              matchedFn = fn;
              break;
            }
          }
          if (matchedFn) {
            let depth = 0;
            let j = i + matchedFn.length;
            for (; j < cssText.length; j++) {
              if (cssText[j] === '(') depth++;
              else if (cssText[j] === ')') {
                depth--;
                if (depth === 0) { j++; break; }
              }
            }
            const fullMatch = cssText.slice(i, j);
            result += convertColorToRgb(fullMatch);
            i = j;
          } else {
            result += cssText[i];
            i++;
          }
        }
        return result;
      };

      // 2. Backup and clean <style> elements
      const styleElements = Array.from(document.querySelectorAll('style'));
      for (const style of styleElements) {
        const text = style.textContent || '';
        if (text.includes('oklch') || text.includes('oklab')) {
          backups.push({ element: style, originalText: text });
          style.textContent = cleanCssText(text);
        }
      }

      // 3. Backup and clean same-origin <link> elements
      const linkElements = Array.from(document.querySelectorAll('link[rel="stylesheet"]')) as HTMLLinkElement[];
      for (const link of linkElements) {
        try {
          if (link.href) {
            const linkUrl = new URL(link.href, window.location.href);
            if (linkUrl.origin === window.location.origin) {
              const response = await fetch(link.href);
              const text = await response.text();
              if (text.includes('oklch') || text.includes('oklab')) {
                const cleanText = cleanCssText(text);
                const styleEl = document.createElement('style');
                styleEl.textContent = cleanText;
                document.head.appendChild(styleEl);
                
                linkBackups.push({ element: link, disabled: link.disabled, replacementStyle: styleEl });
                link.disabled = true;
              }
            }
          }
        } catch (e) {
          console.warn("Could not clean external stylesheet", link.href, e);
        }
      }

      // Capture the modal content.
      const element = document.getElementById("pdf-content-container");
      if (!element) {
        setIsDownloading(false);
        return;
      }

      // 4. Backup and clean inline style attributes
      const elementsToClean = [element, ...Array.from(element.querySelectorAll('*'))] as HTMLElement[];
      for (const el of elementsToClean) {
        if (typeof el.getAttribute === 'function') {
          const styleAttr = el.getAttribute('style');
          if (styleAttr && (styleAttr.includes('oklch') || styleAttr.includes('oklab'))) {
            inlineBackups.push({ element: el, originalStyle: styleAttr });
            el.setAttribute('style', cleanCssText(styleAttr));
          }
        }
      }
      
      const opt = {
        margin:       0.5,
        filename:     `${post.category.replace(/\s+/g, "_")}_${post.title.replace(/\s+/g, "_").slice(0, 30)}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
      };
      
      // @ts-ignore
      const html2pdfModule = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default ? html2pdfModule.default : html2pdfModule;
      
      // @ts-ignore
      await (typeof html2pdf === 'function' ? html2pdf() : html2pdf).set(opt).from(element).save();
    } catch (err) {
      console.error("PDF generation failed", err);
      setDownloadError(true);
    } finally {
      // Restore <style> elements
      for (const backup of backups) {
        backup.element.textContent = backup.originalText;
      }
      // Restore <link> elements
      for (const backup of linkBackups) {
        backup.element.disabled = backup.disabled;
        if (backup.replacementStyle) {
          backup.replacementStyle.remove();
        }
      }
      // Restore inline style attributes
      for (const backup of inlineBackups) {
        backup.element.setAttribute('style', backup.originalStyle);
      }
      
      setIsDownloading(false);
    }
  };

  const filteredPosts = posts.filter((post) => {
    const matchesCategory = selectedCategory === "All" || post.category === selectedCategory;
    const matchesSearch = searchQuery.trim() === "" || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section
      id="blog"
      className="py-14 bg-page-bg-900 relative border-t border-gold-500/20"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-gold-500/20 pb-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-2xl bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm"
          >
            <h3 className="text-xs sm:text-sm uppercase tracking-widest text-white mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
              Blog
            </h3>
            <h2 className="section-title text-3xl sm:text-4xl font-serif mb-4 font-bold">
              Latest Articles & Thoughts
            </h2>
            <p className="text-base text-text-main/90 leading-relaxed font-normal">
              Read my latest thoughts on personal growth, career strategies,
              business mindset, and the deep wisdom of Vedic astrology.
            </p>
          </motion.div>
          <div className="flex gap-4 mt-8 md:mt-0">
            <button
              onClick={() => scroll("left")}
              className="p-3 bg-brand-800 border border-gold-500/20 text-gold-500 hover:bg-gold-500 hover:text-brand-900 transition-colors"
              aria-label="Previous article"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={() => scroll("right")}
              className="p-3 bg-brand-800 border border-gold-500/20 text-gold-500 hover:bg-gold-500 hover:text-brand-900 transition-colors"
              aria-label="Next article"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Dynamic Search Bar */}
        <div className="mb-8 max-w-xl">
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-gold-600 to-[#8B3005] rounded-full blur opacity-15 group-focus-within:opacity-30 transition duration-300"></div>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gold-500/60 group-focus-within:text-gold-400 transition-colors" />
              <input
                type="text"
                placeholder="Search articles by title, excerpt or keyword..."
                aria-label="Search articles by title, excerpt or keyword"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-10 py-3 bg-brand-950/40 border border-gold-500/20 rounded-full text-sm text-text-main placeholder-text-main/40 focus:outline-none focus:border-gold-500/60 focus:bg-brand-950/65 transition-all duration-300 shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-text-main/50 hover:text-gold-400 p-1 rounded-full hover:bg-gold-500/10 transition-colors"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
          {searchQuery && (
            <div className="mt-3 text-xs text-text-main/60 flex items-center gap-2">
              <span className="bg-gold-500/10 text-gold-400 px-2.5 py-0.5 rounded border border-gold-500/25">
                {filteredPosts.length} {filteredPosts.length === 1 ? "article" : "articles"} found
              </span>
              <button
                onClick={() => setSearchQuery("")}
                className="text-gold-500 hover:underline hover:text-gold-400 font-medium transition-colors"
              >
                Clear filter
              </button>
            </div>
          )}
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2.5 mb-10 overflow-x-auto pb-4 scrollbar-none border-b border-gold-500/10">
          {[
            "All",
            "Numerology",
            "Vastu Shastra",
            "Career Consulting",
            "Vedic Astrology",
            "Business Strategy",
            "Personal Transformation",
            "Corporate Workshops",
            "Professional Consulting",
          ].map((category) => (
            <button
              key={category}
              onClick={() => {
                setSelectedCategory(category);
                if (scrollRef.current) {
                  scrollRef.current.scrollTo({ left: 0, behavior: "smooth" });
                }
              }}
              className={`px-4 py-2 text-[11px] font-sans tracking-wider uppercase rounded-full border transition-all shrink-0 ${
                selectedCategory === category
                  ? "bg-gold-500 text-brand-900 border-gold-500 font-bold shadow-lg shadow-gold-500/10"
                  : "bg-brand-900 text-text-main/80 border-gold-500/20 hover:border-gold-500/40 hover:bg-brand-800"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="relative">
          <div 
            ref={scrollRef}
            className="flex overflow-x-auto snap-x snap-mandatory gap-6 pb-8 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-0 lg:px-0"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            <style>{`
              .hide-scrollbar::-webkit-scrollbar {
                display: none;
              }
            `}</style>
            <>
              {filteredPosts.length === 0 ? (
                <div className="w-full text-center py-12 text-text-main opacity-80">
                  No articles found in this category.
                </div>
              ) : (
                filteredPosts.map((post, index) => (
                  <motion.article
                    key={post.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: (index % 6) * 0.08 }}
                    onClick={() => setSelectedPost(post)}
                    className="hide-scrollbar snap-start snap-always shrink-0 w-full group cursor-pointer border border-gold-500/10 p-4 lg:p-8 hover:border-gold-500/30 transition-colors hover:bg-brand-800 flex flex-col md:flex-row gap-8 h-full relative"
                  >
                  <div className="w-full md:w-1/2 aspect-[16/10] bg-brand-700 mb-6 md:mb-0 overflow-hidden border border-brand-800 relative grow-0 shrink-0">
                    <LazyImage
                      src={getBlogImage(post.id)}
                      alt={post.title}
                      className="w-full h-full object-cover transform opacity-100 group-hover:scale-105 group-hover:opacity-100 transition-all duration-700"
                      containerClassName="w-full h-full absolute inset-0"
                    />
                  </div>
                  
                  <div className="flex flex-col flex-1 justify-center">
                    <div className="flex justify-between items-start mb-6 w-full">
                      <span className="text-[10px] uppercase tracking-widest text-gold-500 bg-gold-500/10 px-3 py-1.5 rounded font-bold">
                        {post.category}
                      </span>
                      <div className="flex bg-brand-900 border border-gold-500/20 rounded">
                        <LikeButton /* postId property not in original LikeButton type but it works for layout, we can just leave empty if it errors */ />
                        <button
                          onClick={(e) => handleCopyLink(e, post)}
                          className="p-3 transition-colors border-l border-gold-500/20 text-gold-500 hover:text-gold-400 hover:bg-gold-500/10 focus:outline-none"
                          aria-label="Copy link"
                        >
                          {copiedPostId === post.id ? <Check className="h-4 w-4" /> : <LinkIcon className="h-4 w-4" />}
                        </button>
                        <button
                          onClick={(e) => handleShare(e, post)}
                          className="p-3 transition-colors border-l border-gold-500/20 text-gold-500 hover:text-gold-400 hover:bg-gold-500/10 focus:outline-none"
                          aria-label="Share article"
                        >
                          <Share2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    <h4 className="text-2xl md:text-3xl font-serif text-text-main group-hover:text-gold-400 transition-colors mb-4 md:mb-6 leading-snug">
                      {post.title}
                    </h4>
                    
                    <p className="text-base text-text-main mb-8 font-normal line-clamp-3 leading-relaxed">
                      {post.excerpt}
                    </p>
                    
                    <div className="mt-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center text-xs text-text-main gap-4">
                        <span className="flex items-center uppercase tracking-widest">
                          <span className="w-1.5 h-1.5 rounded-full bg-gold-500/50 mr-2"></span>
                          {post.date}
                        </span>
                        <span>•</span>
                        <span className="uppercase tracking-widest">
                          {post.readTime}
                        </span>
                      </div>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPost(post);
                        }}
                        className="inline-flex items-center text-[10px] uppercase tracking-widest font-bold text-text-main group-hover:text-gold-500 transition-colors rounded px-2 py-1"
                        aria-label={`Read article: ${post.title}`}
                      >
                        Read Article
                        <ChevronRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </motion.article>
                ))
              )}
            </>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-brand-900/95 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-brand-900 border border-gold-500/30 w-full max-w-4xl min-h-[50vh] max-h-[90vh] overflow-y-auto relative rounded shadow-2xl"
            >
              <button
                onClick={() => setSelectedPost(null)}
                className="absolute top-4 right-4 p-2 z-10 bg-brand-800/80 rounded-full text-text-main hover:text-gold-500 hover:bg-brand-700 transition border border-gold-500/20"
              >
                <X className="w-5 h-5" />
              </button>

              <div 
                className="w-full h-64 md:h-96 bg-cover bg-center border-b border-gold-500/20 bg-brand-800"
                style={{
                  backgroundImage: `url(${getBlogImage(selectedPost.id)})`
                }}
              />

              <div className="p-8 md:p-12" id="pdf-content-container">
                <div className="flex items-center text-xs text-text-main space-x-3 uppercase tracking-widest mb-6">
                  <span className="text-gold-500 font-bold opacity-1000">
                    {selectedPost.category}
                  </span>
                  <span>•</span>
                  <span>{selectedPost.readTime}</span>
                  <span>•</span>
                  <span>{selectedPost.date}</span>
                </div>

                <h2 className="text-3xl md:text-5xl font-serif text-text-main mb-8 leading-tight font-bold">
                  {selectedPost.title}
                </h2>

                <div className="prose prose-invert prose-gold max-w-none text-text-main text-lg leading-relaxed space-y-6">
                  <p className="text-xl font-normal text-text-main mb-8 border-l-2 border-gold-500 pl-6 italic">
                    {selectedPost.excerpt}
                  </p>

                  <p>
                    When we examine the foundational principles of {selectedPost.category.toLowerCase()}, 
                    it becomes apparent that intention and cosmic alignment share a profound relationship. 
                    In the fast-paced modern landscape, strategic action is often prioritized over intuitive resonance. 
                    However, the true masters of their craft understand that timing, environment, and unseen forces 
                    play a pivotal role in long-term success.
                  </p>

                  <h3 className="text-2xl font-serif text-text-main mt-12 mb-4 text-gold-400 font-bold">
                    The Power of Alignment
                  </h3>
                  <p>
                    Whether it involves reorganizing a corporate structure or redefining a personal trajectory, 
                    the underlying energy dictates the outcome. {selectedPost.excerpt.toLowerCase()} This demands more 
                    than just hard work; it demands deep self-awareness and a willingness to harmonize with natural cycles.
                  </p>

                  <p>
                    Consider the implications of operating out of sync with these cycles. Projects experience delays, 
                    communications falter, and leadership feels exhausting rather than empowering. By bringing your actions 
                    into alignment with the wisdom of {selectedPost.category.toLowerCase()}, you reduce that friction. You begin 
                    to move with the current of success rather than endlessly fighting against it.
                  </p>

                  <figure className="my-10 overflow-hidden rounded-3xl border border-gold-500/20 bg-brand-950/60 p-2.5 shadow-xl transition-all hover:border-gold-500/35">
                    <img
                      src={getBlogSecondaryImage(selectedPost.id, selectedPost.category)}
                      alt={`${selectedPost.category} foundational concept`}
                      className="w-full max-h-[380px] object-cover rounded-2xl"
                      referrerPolicy="no-referrer"
                      onError={(e) => { (e.target as HTMLImageElement).src = blogFallbackImg; }}
                    />
                    <figcaption className="text-[11px] text-text-main/50 mt-3 text-center font-sans tracking-widest italic uppercase">
                      Figure 1: Harmonious integration - combining strategic action with {selectedPost.category} wisdom
                    </figcaption>
                  </figure>

                  <h3 className="text-2xl font-serif text-text-main mt-12 mb-4 text-gold-400 font-bold">
                    Practical Integration Strategies
                  </h3>
                  <ul className="list-disc pl-6 space-y-3 text-text-main marker:text-gold-500">
                    <li><strong>Observation:</strong> Track the patterns between your efforts and the corresponding energetic cycles. Notice when resistance is highest.</li>
                    <li><strong>Space Cleansing:</strong> Ensure your physical environment reflects your operational goals. Clutter inevitably breeds mental fog.</li>
                    <li><strong>Actionable Timing:</strong> Delay crucial launches or aggressive strategies during restrictive planetary periods. Reserve that time for deep planning and restructuring.</li>
                    <li><strong>Resilience Building:</strong> Use adverse situations as immediate feedback loops to tighten your strategic framework.</li>
                  </ul>

                  <figure className="my-10 overflow-hidden rounded-3xl border border-gold-500/20 bg-brand-950/60 p-2.5 shadow-xl transition-all hover:border-gold-500/35">
                    <img
                      src={getBlogTertiaryImage(selectedPost.id, selectedPost.category)}
                      alt={`${selectedPost.category} practical execution`}
                      className="w-full max-h-[380px] object-cover rounded-2xl"
                      referrerPolicy="no-referrer"
                      onError={(e) => { (e.target as HTMLImageElement).src = blogFallbackImg; }}
                    />
                    <figcaption className="text-[11px] text-text-main/50 mt-3 text-center font-sans tracking-widest italic uppercase">
                      Figure 2: Grounding and development - applying ancient systems to real-world achievements
                    </figcaption>
                  </figure>

                  <p className="mt-8 pt-8 border-t border-gold-500/20">
                    The journey of mastery is subtle. It involves turning the invisible into the structural foundation of your life and business.
                    When {selectedPost.title.toLowerCase()} is understood fully, you equip yourself with an unfair advantage in the marketplace.
                  </p>
                </div>
              </div>
                
              <div className="p-8 md:p-12 pt-0 md:pt-0">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pt-8 border-t border-gold-500/20 gap-6">
                  <p className="text-sm uppercase tracking-widest text-text-main">Share or Download this insight</p>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex flex-wrap gap-4">
                      <button 
                        onClick={(e) => handleDownloadPdf(e, selectedPost)} 
                        disabled={isDownloading}
                        className="flex items-center gap-2 px-4 py-3 bg-brand-800 rounded-full hover:bg-gold-500/20 hover:text-gold-500 transition border border-gold-500/30 text-sm font-medium touch-manipulation disabled:opacity-100"
                      >
                        <Download className="w-4 h-4" />
                        {isDownloading ? "Generating PDF..." : "Download PDF"}
                      </button>
                    <button onClick={(e) => handleLinkedInShare(e, selectedPost)} className="p-3 bg-brand-800 rounded-full hover:bg-[#0A66C2] hover:text-white transition border border-gold-500/30 group touch-manipulation" aria-label="Share to LinkedIn">
                      <Linkedin className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    </button>
                    <button onClick={(e) => handleCopyLink(e, selectedPost)} className="p-3 bg-brand-800 rounded-full hover:bg-gold-500/20 hover:text-gold-500 transition border border-gold-500/30 group touch-manipulation" aria-label="Copy Link">
                      {copiedPostId === selectedPost.id ? <Check className="w-5 h-5" /> : <LinkIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />}
                    </button>
                    <button onClick={(e) => handleShare(e, selectedPost)} className="p-3 bg-brand-800 rounded-full hover:bg-gold-500/20 hover:text-gold-500 transition border border-gold-500/30 group touch-manipulation" aria-label="Share">
                      <Share2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    </button>
                    </div>
                    {downloadError && (
                      <p className="text-xs text-red-400">
                        PDF download failed. Please try again, or contact us if this keeps happening.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
