import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { API_BASE_URL } from "../config";
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  Clock,
  Star,
  Info,
  Video,
  Monitor,
  Phone,
  MessageCircle,
  CheckCircle2,
  X,
  Loader2,
} from "lucide-react";
import confetti from "canvas-confetti";
import { safeOpenLink } from "../utils/navigation";
import celestialCalendarHero from "../assets/images/celestial_calendar_hero_1781078420922.webp";
import { PrePaymentModal } from "./PrePaymentModal";

// Local YYYY-MM-DD date-key generator — uses local getters (not UTC), matching
// the same approach the Calendar Grid already uses for its own date keys, so
// "today" is computed consistently regardless of the user's timezone.
const toLocalDateKey = (date: Date): string =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

// Auspicious consultation dates, sourced live from the /api/auspicious-dates
// endpoint (server.ts), which calls a genuine Panchang API. See that
// endpoint's comments for the exact provider and Yoga rules used. This
// component never invents dates itself — if the API isn't configured or
// fails, the calendar simply shows no stars for that year.
type AuspiciousDateInfo = {
  title: string;
  desc: string;
  type: "wealth" | "beginnings" | "health" | "general";
};

// Static, immutable, manually-approved auspicious-date mapping. No API, no
// calculation, no recurrence — just a direct ISO-date lookup.
const AUSPICIOUS_DATES: Record<string, AuspiciousDateInfo> = {
  "2026-07-11": { title: "Sarvartha Siddhi Yoga + Amrit Siddhi Yoga", desc: "Highly auspicious window for important undertakings.", type: "general" },
  "2026-07-19": { title: "Sarvartha Siddhi Yoga + Ravi Yoga", desc: "Highly auspicious window for important undertakings.", type: "general" },
  "2026-07-24": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-07-26": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-08-08": { title: "Sarvartha Siddhi Yoga + Amrit Siddhi Yoga", desc: "Highly auspicious window for important undertakings.", type: "general" },
  "2026-08-16": { title: "Sarvartha Siddhi Yoga + Amrit Siddhi Yoga", desc: "Highly auspicious window for important undertakings.", type: "general" },
  "2026-08-20": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-08-23": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-08-30": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-09-01": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-09-17": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-09-30": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-10-05": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-10-06": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-10-14": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-10-28": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-01": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-15": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-16": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-22": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-24": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-11-25": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-12-13": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-12-20": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-12-23": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2026-12-25": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-01-02": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-01-04": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-01-15": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-01-20": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-01-27": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-02-06": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-02-11": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-02-12": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-02-15": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-02-18": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-03-05": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-03-11": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-03-15": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-03-18": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-04-06": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-04-18": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-04-23": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-04-25": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-05-08": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-05-16": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-05-23": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-06-01": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-06-17": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-06-27": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
  "2027-06-29": { title: "Sarvartha Siddhi Yoga", desc: "Auspicious for all important acts and general prosperity.", type: "general" },
};

interface BookingCalendarProps {
  selectedService?: string;
  setSelectedService?: (val: string) => void;
}

export function BookingCalendar({
  selectedService: externalSelectedService,
  setSelectedService: externalSetSelectedService,
}: BookingCalendarProps = {}) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [currentMonthDate, setCurrentMonthDate] = useState(
    new Date(today.getFullYear(), today.getMonth(), 1),
  );
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [meetingMode, setMeetingMode] = useState<"whatsapp" | "zoom" | "teams" | "phone">("whatsapp");
  const [wantsReminders, setWantsReminders] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [syncFailed, setSyncFailed] = useState(false);
  const [prePaymentOpen, setPrePaymentOpen] = useState(false);
  const [prePaymentServiceForModal, setPrePaymentServiceForModal] = useState("");
  const [showChecklist, setShowChecklist] = useState(false);
  const [stripeEnabled, setStripeEnabled] = useState(false);
  const [paymentLinkEnabled, setPaymentLinkEnabled] = useState(false);
  const paymentConfigured = stripeEnabled || paymentLinkEnabled;
  const [showStripeSuccess, setShowStripeSuccess] = useState(false);
  const [stripeBookingDetails, setStripeBookingDetails] = useState<any | null>(null);

  useEffect(() => {
    // 1. Fetch Stripe availability status from back-end
    fetch(`${API_BASE_URL}/api/payment-config`)
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.stripeEnabled === "boolean") {
          setStripeEnabled(data.stripeEnabled);
        }
        if (data && typeof data.paymentLinkEnabled === "boolean") {
          setPaymentLinkEnabled(data.paymentLinkEnabled);
        }
      })
      .catch((err) => console.error("Error fetching payment-config:", err));

    // 2. Handle returning Stripe checkout session confirmation
    if (window.location.hash === "#success") {
      confetti({
        particleCount: 200,
        spread: 85,
        origin: { y: 0.5 },
        colors: ["#D4AF37", "#FF9900", "#10B981", "#FFFFFF"]
      });

      const pendingStr = localStorage.getItem("pending_stripe_booking");
      if (pendingStr) {
        try {
          const pending = JSON.parse(pendingStr);
          pending.paymentStatus = "Payment Completed";
          
          const existingData = JSON.parse(localStorage.getItem("appointment_leads") || "[]");
          localStorage.setItem("appointment_leads", JSON.stringify([pending, ...existingData]));
          
          setStripeBookingDetails(pending);
          localStorage.removeItem("pending_stripe_booking");
        } catch (e) {
          console.error("Failed to parse pending booking:", e);
        }
      }

      setShowStripeSuccess(true);

      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      } else {
        window.location.hash = "";
      }
    }
  }, []);

  // Keyboard accessibility: Escape closes whichever modal is currently open.
  useEffect(() => {
    if (!showChecklist && !showStripeSuccess) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowChecklist(false);
        setShowStripeSuccess(false);
      }
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [showChecklist, showStripeSuccess]);

  const year = currentMonthDate.getFullYear();
  const month = currentMonthDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const dayNames = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

  const days = [];
  for (let i = 0; i < firstDayIndex; i++) {
    days.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i);
  }

  const prevMonth = () => {
    setCurrentMonthDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonthDate(new Date(year, month + 1, 1));
  };

  // Available consultation hours:
  //   Monday - Friday: 10:00 AM - 2:00 PM  AND  4:00 PM - 8:00 PM
  //   Saturday - Sunday: 4:00 PM - 8:00 PM only
  const weekdayTimeSlots = [
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
  ];
  const weekendTimeSlots = [
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
  ];
  const timeSlots = (() => {
    if (!selectedDate) return weekdayTimeSlots;
    const dayOfWeek = selectedDate.getDay(); // 0 = Sunday, 6 = Saturday
    return (dayOfWeek === 0 || dayOfWeek === 6) ? weekendTimeSlots : weekdayTimeSlots;
  })();

  const handleDateSelect = (day: number) => {
    const date = new Date(year, month, day);
    if (date >= today) {
      setSelectedDate(date);
      setSelectedTime(null);
    }
  };

  const isSelected = (day: number) => {
    if (!selectedDate) return false;
    return (
      selectedDate.getDate() === day &&
      selectedDate.getMonth() === month &&
      selectedDate.getFullYear() === year
    );
  };

  const isPast = (day: number) => {
    const date = new Date(year, month, day);
    return date < today;
  };

  const [internalSelectedService, internalSetSelectedService] = useState<string>("");
  const selectedService = externalSelectedService !== undefined ? externalSelectedService : internalSelectedService;
  const setSelectedService = externalSetSelectedService !== undefined ? externalSetSelectedService : internalSetSelectedService;

  const generateWhatsAppLink = (customName?: string, customService?: string, customDateTime?: string) => {
    const parts = ["Hello Jitin Goel Consulting, I would like to book a consultation."];
    if (customName) parts.push(`My name is ${customName}.`);
    if (customService) parts.push(`I'm interested in: ${customService}.`);
    if (customDateTime) parts.push(`Preferred slot: ${customDateTime}.`);
    const message = parts.join(" ");
    return `https://wa.me/918796578959?text=${encodeURIComponent(message)}`;
  };

  return (
    <section
      className="py-24 px-6 sm:px-12 bg-page-bg-900 border-t border-gold-500/10 relative overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[600px] h-[600px] bg-gold-500/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-amber-500 text-sm font-bold tracking-[0.2em] uppercase mb-4 flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-gold-400" /> Calendar
            </span>
            <h2 className="text-4xl md:text-5xl font-serif text-gold-500 drop-shadow-md mb-6 font-bold">
              Schedule Your <br />
              <span className="italic text-amber-500 drop-shadow-sm">Consultation</span>
            </h2>
            <p className="text-text-main leading-relaxed mb-8 text-lg font-normal">
              Select a convenient date and time from the calendar. Once you find
              an available slot, we will instantly connect you on WhatsApp to
              finalize your appointment.
            </p>

            {/* Visual Steps */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-brand-800 border border-gold-400/30 text-gold-400 flex items-center justify-center font-bold text-sm shrink-0 shadow-[0_0_10px_rgba(52,211,153,0.2)]">
                  1
                </div>
                <div>
                  <h4 className="text-gold-400 font-bold mb-1">
                    Select a Date
                  </h4>
                  <p className="text-amber-200/70 text-sm">
                    Choose an available day from the interactive calendar.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-brand-800 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-sm shrink-0 shadow-[0_0_10px_rgba(245,158,11,0.2)]">
                  2
                </div>
                <div>
                  <h4 className="text-amber-500 font-bold mb-1">Pick a Time</h4>
                  <p className="text-amber-200/70 text-sm">
                    Select from the available time slots for your chosen day.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className={`w-8 h-8 rounded-full bg-brand-800 border ${paymentConfigured ? "border-amber-400/30 text-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.2)]" : "border-green-400/30 text-green-400 shadow-[0_0_10px_rgba(74,222,128,0.2)]"} flex items-center justify-center font-bold text-sm shrink-0`}>
                  3
                </div>
                <div>
                  <h4 className={`${paymentConfigured ? "text-amber-400" : "text-green-400"} font-bold mb-1`}>
                    {paymentConfigured ? "Secure Your Booking" : "Confirm on WhatsApp"}
                  </h4>
                  <p className="text-text-main text-sm leading-relaxed">
                    {paymentConfigured
                      ? "Complete secure payment to instantly reserve your consultation. Pricing is tailored to your specific needs and will be confirmed before payment."
                      : "Send the pre-filled message directly to our WhatsApp to secure your booking."}
                  </p>
                </div>
              </div>
            </div>

            {/* Cosmic Alignment Segment */}
            <div className="mt-12 p-6 rounded-2xl bg-brand-800/60 border border-gold-500/20 relative overflow-hidden group shadow-lg">
              <div className="absolute inset-0 bg-gradient-to-br from-gold-500/5 to-transparent"></div>
              <div className="flex flex-col sm:flex-row gap-6 items-center relative z-10">
                <div className="w-16 h-16 rounded-xl border border-gold-500/30 bg-gold-500/10 flex items-center justify-center shrink-0 shadow-md">
                  <Star className="w-8 h-8 text-gold-500 fill-gold-500/20 animate-pulse" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-gold-400 font-bold mb-1.5 flex items-center gap-1.5">
                    <Star className="w-3 h-3 fill-gold-400 text-gold-400" /> Cosmic Sync & Alignment
                  </div>
                  <h4 className="text-md font-serif text-amber-500 mb-1 tracking-wide">
                    Auspicious Timing Windows
                  </h4>
                  <p className="text-xs text-text-main font-normal leading-relaxed">
                    Schedule consultations during highly favorable alignment windows (indicated with <span className="text-gold-400 font-medium">★ Stars</span> in our live calendar) to synchronize essential decisions with natural fortune.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Calendar UI */}
          <div className="flex flex-col gap-4">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-brand-800/80 backdrop-blur-md border border-gold-500/40 text-gold-400 px-4 py-3 rounded-lg shadow-lg flex items-center justify-between mb-2 relative overflow-hidden group"
            >
               <div className="absolute inset-0 bg-gold-500/5 group-hover:bg-gold-500/10 transition-colors"></div>
               <div className="flex items-center gap-3">
                 <span className="relative flex h-3 w-3 shrink-0">
                   <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-400 opacity-100"></span>
                   <span className="relative inline-flex rounded-full h-3 w-3 bg-gold-500"></span>
                 </span>
                 <span className="text-xs font-bold uppercase tracking-widest relative z-10">High Demand: Limited slots remaining this week</span>
               </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="bg-[#1A0F0A]/90 backdrop-blur-2xl rounded-2xl border border-gold-500/25 p-6 md:p-8 shadow-2xl relative overflow-hidden w-full shadow-[0_0_50px_rgba(197,168,128,0.15)]"
            >
              {/* Premium Photogenic Background Image Backdrop */}
              <div className="absolute inset-0 z-0 opacity-100 pointer-events-none select-none mix-blend-screen">
                <img
                  src={celestialCalendarHero}
                  alt="Celestial Constellations Backdrop"
                  className="w-full h-full object-cover scale-110 filter blur-[3px]"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-[#1A0F0A]/95 via-[#0D0705]/70 to-[#1A0F0A]/95"></div>
              </div>

              {/* Premium Photogenic Cover Header of the Interactive Calendar */}
              <div className="relative z-10 h-44 rounded-xl overflow-hidden mb-8 border border-gold-500/20 group/card shadow-lg saturate-[1.2]" id="interactive-planner-banner">
                <img
                  src={celestialCalendarHero}
                  alt="Celestial Astrolabe Calendar Planner"
                  className="w-full h-full object-cover opacity-100 transition-transform duration-1000 group-hover/card:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A0F0A] via-[#1A0F0A]/40 to-[#1A0F0A]/10"></div>
                <div className="absolute inset-0 bg-gold-500/10 mix-blend-color-dodge animate-pulse"></div>
                <div className="absolute top-4 left-5 right-5 flex justify-center">
                  <div className="bg-[#1A0F0A]/90 backdrop-blur-md px-4 py-1.5 rounded-full border border-gold-500/30 text-[10px] font-mono text-gold-400 flex items-center gap-2 shadow-md">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-gold-500"></span>
                    </span>
                    <span className="uppercase tracking-widest font-bold">
                      Current Cosmic Window: {AUSPICIOUS_DATES[toLocalDateKey(new Date())] ? "Favorable" : "Standard"}
                    </span>
                  </div>
                </div>
                <div className="absolute bottom-4 left-5 right-5 flex justify-between items-end">
                  <div>
                    <span className="text-[10px] font-mono text-gold-400 uppercase tracking-widest font-extrabold pb-0.5 inline-block">
                      COSMIC TIMING ENGINE
                    </span>
                    <h4 className="text-xl font-serif text-white font-semibold tracking-wide">
                      Auspicious Cosmic Planner
                    </h4>
                  </div>
                  <div className="bg-[#1A0F0A]/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-gold-500/20 text-[10px] font-mono text-gold-400 flex items-center gap-1.5 shadow-md">
                    <Star className="w-3 h-3 text-[#C5A880] fill-[#C5A880]/30 animate-pulse" />
                    <span>Cosmic Timing Sync</span>
                  </div>
                </div>
              </div>

              {/* Progress Indicator */}
              <div className="relative z-10 mb-8 bg-[#1A0F0A]/80 border border-gold-500/15 rounded-xl p-4 sm:p-5 backdrop-blur-md">
                <div className="flex justify-between items-end mb-4">
                  <div className="flex flex-col">
                    <span className="text-gold-400 font-bold text-[10px] sm:text-xs uppercase tracking-[0.2em] mb-1.5">
                      {!selectedDate ? "Step 1 of 3" : !selectedTime ? "Step 2 of 3" : "Step 3 of 3"}
                    </span>
                    <span className="text-white font-medium">
                      {!selectedDate ? "Select a Date" : !selectedTime ? "Choose a Time" : "Confirm Booking Details"}
                    </span>
                  </div>
                  <div className="text-[10px] sm:text-xs text-[#FFF6EC]/60 uppercase tracking-widest font-bold">
                    {!selectedDate ? "2 steps left" : !selectedTime ? "1 step left" : "Final step"}
                  </div>
                </div>
                
                <div className="h-2 bg-[#0D0705] w-full rounded-full overflow-hidden relative border border-gold-500/10">
                  <motion.div
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-amber-500 via-gold-500 to-gold-500 shadow-[0_0_15px_rgba(245,158,11,0.6)] rounded-full"
                    initial={{ width: "33.33%" }}
                    animate={{
                      width: !selectedDate
                        ? "33.33%"
                        : !selectedTime
                          ? "66.66%"
                          : "100%",
                    }}
                    transition={{ duration: 0.5, ease: "easeInOut" }}
                  />
                  
                  {/* Milestone Markers */}
                  <div className="absolute top-0 left-1/3 w-[1px] h-full bg-[#0D0705]/50 z-10" />
                  <div className="absolute top-0 left-2/3 w-[1px] h-full bg-[#0D0705]/50 z-10" />
                </div>
              </div>

              {/* Header */}
              <div className="relative z-10 flex items-center justify-between mb-8">
                <h3 className="text-xl font-serif text-[#FFB066] tracking-wide font-bold">
                  {monthNames[month]} {year}
                </h3>
                <div className="flex gap-2">
                  <button
                    onClick={prevMonth}
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-[#1A0F0A] border border-gold-500/20 text-[#FFF6EC]/65 hover:bg-gold-500/20 hover:text-white transition-colors active:scale-95 touch-manipulation"
                    aria-label="Previous Month"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={nextMonth}
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-[#1A0F0A] border border-gold-500/20 text-[#FFF6EC]/65 hover:bg-gold-500/20 hover:text-white transition-colors active:scale-95 touch-manipulation"
                    aria-label="Next Month"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Days Grid */}
              <div className="relative z-10 grid grid-cols-7 gap-y-4 mb-6">
                {dayNames.map((day) => (
                  <div
                    key={day}
                    className="text-center text-[10px] uppercase tracking-wider text-[#FFF6EC]/70 font-bold mb-2"
                  >
                    {day}
                  </div>
                ))}

                {days.map((day, idx) => {
                  if (day === null) {
                    return <div key={`empty-${idx}`} className="h-8 min-[390px]:h-10"></div>;
                  }

                  const past = isPast(day);
                  const selected = isSelected(day);
                  const dateString = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
                  const isAuspicious = AUSPICIOUS_DATES[dateString];

                  return (
                    <div
                      key={`day-${day}`}
                      className="flex justify-center flex-col items-center overflow-hidden"
                    >
                      <button
                        onClick={() => handleDateSelect(day)}
                        disabled={past}
                        aria-label={`${day} ${monthNames[month]} ${year}${past ? " (Past date, unavailable)" : ""}${selected ? " (Selected)" : ""}${isAuspicious && !past ? ` (Auspicious Date: ${isAuspicious.title})` : ""}`}
                        className={`w-8 h-8 min-[390px]:w-10 min-[390px]:h-10 rounded-full flex flex-col items-center justify-center text-sm transition-all focus:outline-none relative border active:scale-[0.98] touch-manipulation ${
                          past
                            ? "text-[#FFF6EC]/20 border-transparent cursor-not-allowed"
                            : selected
                              ? "bg-gradient-to-tr from-gold-500 via-amber-500 to-gold-500 text-white font-extrabold shadow-[0_0_20px_rgba(245,158,11,0.6)] scale-110 border-amber-300"
                              : isAuspicious
                                ? "bg-gold-500/10 border-gold-500/30 text-[#FFF6EC]/85 hover:bg-gold-500/20 hover:border-gold-400 shadow-[0_0_12px_rgba(197,168,128,0.2)]"
                                : "bg-[#1A0F0A]/80 border-gold-500/10 text-[#FFF6EC] hover:bg-gold-500/20 hover:text-gold-400 hover:border-gold-500/30"
                        }`}
                      >
                        <span className="relative z-10 flex items-center justify-center gap-0.5">
                          {isAuspicious && !past && (
                            <Star
                              className={`w-3 h-3 shrink-0 drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)] ${selected ? "text-white fill-white" : "text-amber-400 fill-amber-400"}`}
                            />
                          )}
                          {day}
                        </span>
                      </button>
                    </div>
                  );
                })}
              </div>

            {/* Time Slots */}
            <AnimatePresence mode="wait">
              {selectedDate && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="relative z-10 border-t border-gold-500/20 pt-6 overflow-hidden"
                >
                  {(() => {
                    const selDateString = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, "0")}-${String(selectedDate.getDate()).padStart(2, "0")}`;
                    const auspiciousDetails = AUSPICIOUS_DATES[selDateString];
                    return (
                      auspiciousDetails && (
                        <div className="mb-6 p-4 bg-[#1A0F0A]/80 border border-gold-500/25 rounded-xl relative overflow-hidden backdrop-blur-md">
                          <div className="absolute top-0 right-0 w-24 h-24 bg-gold-500/10 blur-[30px]"></div>
                          <div className="flex items-start gap-4 object-contain">
                            <div className="bg-gold-500/10 w-10 h-10 rounded-lg flex items-center justify-center text-gold-400 shrink-0">
                               <Star className="w-5 h-5 fill-gold-400/20" />
                            </div>
                            <div>
                              <div className="text-[10px] uppercase tracking-widest text-[#ffdd80] font-bold mb-1">
                                Auspicious Cosmic Window
                              </div>
                              <h4 className="text-xl font-serif text-white mb-2">
                                {auspiciousDetails.title}
                              </h4>
                              <p className="text-sm font-normal text-[#FFF6EC]/70 leading-relaxed">
                                {auspiciousDetails.desc}
                              </p>
                            </div>
                          </div>
                        </div>
                      )
                    );
                  })()}

                  <div className="flex items-center gap-2 mb-4 text-[#FFF6EC]/85">
                    <Clock className="w-4 h-4 text-gold-400" />
                    <span className="text-sm font-bold">Select Auspicious Hour</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`text-xs py-2.5 rounded font-bold tracking-wider transition-all border active:scale-95 touch-manipulation ${
                          selectedTime === time
                            ? "bg-gradient-to-r from-gold-500 to-gold-600 border-gold-500 text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]"
                            : "bg-[#1A0F0A]/60 border-gold-500/20 text-[#FFF6EC]/70 hover:border-gold-500/50 hover:text-gold-400"
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>

                  <AnimatePresence>
                    {selectedTime && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="flex flex-col gap-6"
                      >
                        <form
                          className="flex flex-col gap-4"
                          onSubmit={async (e) => {
                            e.preventDefault();
                            if (isSubmitting) return; // prevent double-submission
                            setIsSubmitting(true);
                            setSyncFailed(false);
                            
                            // Get form data
                            const formElement = e.target as HTMLFormElement;
                            const formData = new FormData(formElement);
                            const name = formData.get("name") as string;
                            const mobile = formData.get("mobile") as string;
                            const email = formData.get("email") as string;
                            const concern = formData.get("concern") as string;
                            const service = formData.get("service") as string;
                            const dateStr = `${selectedDate.toLocaleDateString()} at ${selectedTime}`;
                            
                            // Save to Google Sheets API and process checkout
                            try {
                              const res = await fetch(`${API_BASE_URL}/api/book-appointment`, {
                                method: "POST",
                                headers: {
                                  "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                  name,
                                  date: dateStr,
                                  mobile,
                                  email,
                                  concern: `[Svc: ${service}] [${meetingMode.toUpperCase()}] ${concern}`
                                })
                              });
                              
                              if (!res.ok) {
                                console.error("Failed to save booking:", await res.text());
                                setSyncFailed(true);
                              } else {
                                const data = await res.json();
                                if (data.checkoutUrl) {
                                  // Save pre-emptively as pending Stripe registration so we can track it when they return
                                  const pendingEntry = {
                                    id: Date.now().toString(),
                                    name,
                                    date: dateStr,
                                    mobile,
                                    email,
                                    concern: `[Svc: ${service}] [${meetingMode.toUpperCase()}] ${concern}`,
                                    timestamp: new Date().toISOString(),
                                    paymentStatus: "Pending Payment"
                                  };
                                  localStorage.setItem("pending_stripe_booking", JSON.stringify(pendingEntry));

                                  window.location.href = data.checkoutUrl;
                                  return; // Stop execution, user will be redirected
                                }
                              }
                            } catch (error) {
                              console.error("Error communicating with API:", error);
                              setSyncFailed(true);
                            }

                            // Save to local storage for Admin Panel
                            const newEntry = {
                              id: Date.now().toString(),
                              name,
                              date: dateStr,
                              mobile,
                              email,
                              concern: `[Svc: ${service}] [${meetingMode.toUpperCase()}] ${concern}`,
                              timestamp: new Date().toISOString()
                            };
                            
                            const existingData = JSON.parse(localStorage.getItem('appointment_leads') || '[]');
                            localStorage.setItem('appointment_leads', JSON.stringify([newEntry, ...existingData]));
                            
                            setIsSubmitting(false);
                            setShowSuccess(true);
                            
                            // Trigger confetti animation
                            confetti({
                              particleCount: 150,
                              spread: 70,
                              origin: { y: 0.6 },
                              colors: ['#FFB066', '#FF9933', '#CC7A29', '#ffffff']
                            });
                            
                            formElement.reset();  
                            setTimeout(() => {
                                setShowSuccess(false);
                                setPrePaymentServiceForModal(service);
                                setPrePaymentOpen(true);
                            }, 2000);
                          }}
                        >
                          <div className="mb-4">
                            <label className="text-xs text-[#FFF6EC]/80 mb-2 block font-bold uppercase tracking-widest">Meeting Mode</label>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              {[
                                { id: 'whatsapp', label: 'WhatsApp', icon: <MessageCircle className="w-4 h-4" /> },
                                { id: 'zoom', label: 'Zoom/Meet', icon: <Video className="w-4 h-4" /> },
                                { id: 'teams', label: 'Teams', icon: <Monitor className="w-4 h-4" /> },
                                { id: 'phone', label: 'Phone', icon: <Phone className="w-4 h-4" /> }
                              ].map(mode => (
                                <button
                                  key={mode.id}
                                  type="button"
                                  onClick={() => setMeetingMode(mode.id as any)}
                                  className={`flex items-center gap-2 px-3 py-2 text-xs rounded border transition-colors active:scale-95 touch-manipulation ${
                                    meetingMode === mode.id
                                      ? 'bg-gold-500/20 border-gold-500 text-[#FFF6EC]/65 shadow-[0_0_10px_-3px_rgba(197,168,128,0.3)]'
                                      : 'bg-[#1A0F0A] border-gold-500/20 text-[#FFF6EC]/70 hover:border-gold-500/50 hover:text-gold-400'
                                  }`}
                                >
                                  {mode.icon}
                                  {mode.label}
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <select
                              required
                              name="service"
                              value={selectedService}
                              onChange={(e) => setSelectedService(e.target.value)}
                              className="w-full bg-[#1A0F0A]/90 border border-gold-500/20 px-4 py-3 text-sm text-[#FFF6EC] focus:outline-none focus:border-gold-400/60 focus:ring-1 focus:ring-gold-400 transition-colors placeholder:text-[#FFF6EC]/30 appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23C5A880%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:12px_12px] bg-no-repeat bg-[position:right_1rem_center]"
                              aria-label="Select a Service"
                            >
                              <option value="" disabled className="bg-[#1A0F0A] text-[#FFF6EC]/50">Select a Service</option>
                              <option value="Business Strategy & Growth Consulting" className="bg-[#1A0F0A] text-[#FFF6EC]">Business Strategy & Growth Consulting</option>
                              <option value="Career & Professional Consulting" className="bg-[#1A0F0A] text-[#FFF6EC]">Career & Professional Consulting</option>
                              <option value="Personal Transformation Consulting" className="bg-[#1A0F0A] text-[#FFF6EC]">Personal Transformation Consulting</option>
                              <option value="Cosmic Astrology Consultation" className="bg-[#1A0F0A] text-[#FFF6EC]">Cosmic Astrology Consultation</option>
                            </select>
                          </div>
                          <div>
                            <input
                              required
                              type="text"
                              name="name"
                              placeholder="Your Name"
                              autoComplete="name"
                              className="w-full bg-[#1A0F0A]/90 border border-gold-500/20 px-4 py-3 text-sm text-[#FFF6EC] focus:outline-none focus:border-gold-400/60 focus:ring-1 focus:ring-gold-400 transition-colors placeholder:text-[#FFF6EC]/30"
                              aria-label="Your Full Name"
                            />
                          </div>
                          <div>
                            <input
                              required
                              type="tel"
                              name="mobile"
                              placeholder="Mobile Number"
                              autoComplete="tel"
                              className="w-full bg-[#1A0F0A]/90 border border-gold-500/20 px-4 py-3 text-sm text-[#FFF6EC] focus:outline-none focus:border-gold-400/60 focus:ring-1 focus:ring-gold-400 transition-colors placeholder:text-[#FFF6EC]/30"
                              aria-label="Mobile Number"
                            />
                          </div>
                          <div>
                            <input
                              type="email"
                              name="email"
                              placeholder="Email Address (Optional)"
                              autoComplete="email"
                              className="w-full bg-[#1A0F0A]/90 border border-gold-500/20 px-4 py-3 text-sm text-[#FFF6EC] focus:outline-none focus:border-gold-400/60 focus:ring-1 focus:ring-gold-400 transition-colors placeholder:text-[#FFF6EC]/30"
                              aria-label="Email Address (Optional)"
                            />
                          </div>
                          <div>
                            <textarea
                              name="concern"
                              placeholder="Your Concern / Purpose of Visit (Optional)"
                              rows={3}
                              className="w-full bg-[#1A0F0A]/90 border border-gold-500/20 px-4 py-3 text-sm text-[#FFF6EC] focus:outline-none focus:border-gold-400/60 focus:ring-1 focus:ring-gold-400 transition-colors placeholder:text-[#FFF6EC]/30 resize-none"
                              aria-label="Your Concern or Purpose of Visit (Optional)"
                            ></textarea>
                          </div>

                          <button type="button" className="w-full flex text-left items-center justify-between bg-gold-500/5 border border-gold-500/20 p-4 rounded-xl mt-2 cursor-pointer hover:bg-gold-500/10 transition-colors active:scale-[0.98] active:bg-gold-500/10 touch-manipulation" onClick={() => setShowChecklist(true)}>
                            <div className="flex items-center gap-3">
                              <Info className="w-5 h-5 text-gold-400" />
                              <div>
                                <p className="text-sm font-bold text-white">Preparation Checklist</p>
                                <p className="text-xs text-[#FFF6EC]/60">What to have ready for our meeting</p>
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-gold-400" />
                          </button>

                          <div className="flex items-center justify-between bg-[#1A0F0A]/90 border border-gold-500/20 p-4 rounded-xl mt-2">
                            <div>
                              <p className="text-sm font-bold text-white mb-1">
                                Automated Reminders
                              </p>
                              <p className="text-xs text-[#FFF6EC]/55">
                                Opt-in for timely SMS or email alerts.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setWantsReminders(!wantsReminders)}
                              className={`w-12 h-6 rounded-full p-1 transition-colors relative ${wantsReminders ? "bg-gold-500" : "bg-[#3D281C]"}`}
                              aria-pressed={wantsReminders}
                              aria-label="Toggle reminders"
                            >
                              <motion.div
                                className="w-4 h-4 bg-white rounded-full shadow-md"
                                animate={{ x: wantsReminders ? 24 : 0 }}
                                transition={{
                                  type: "spring",
                                  stiffness: 500,
                                  damping: 30,
                                }}
                              />
                            </button>
                          </div>                           <button
                            type="submit"
                            disabled={isSubmitting}
                            className={`w-full flex items-center justify-center py-4 text-white rounded-xl font-bold uppercase tracking-widest text-xs transition-all relative overflow-hidden mt-2 active:scale-[0.98] touch-manipulation disabled:opacity-70 disabled:cursor-not-allowed ${
                              paymentConfigured
                                ? "bg-gradient-to-r from-gold-500 via-amber-600 to-gold-600 hover:brightness-110 hover:shadow-[0_0_20px_-5px_rgba(212,175,55,0.4)]"
                                : "bg-[#25D366] hover:bg-[#20ba56] hover:shadow-[0_0_20px_-5px_rgba(37,211,102,0.4)]"
                            }`}
                          >
                            <AnimatePresence>
                              {showSuccess && (
                                <motion.div
                                  className={`absolute inset-0 flex items-center justify-center z-10 ${paymentConfigured ? "bg-gradient-to-r from-amber-600 to-gold-500" : "bg-[#1da851]"}`}
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  exit={{ opacity: 0 }}
                                >
                                  {Array.from({ length: 15 }).map((_, i) => (
                                    <motion.div
                                      key={i}
                                      className="absolute w-2 h-2 rounded-full"
                                      style={{
                                        backgroundColor: [
                                          "#FFFFFF",
                                          "#FFD700",
                                          paymentConfigured ? "#F59E0B" : "#25D366",
                                          "#000000",
                                        ][i % 4],
                                      }}
                                      initial={{
                                        opacity: 1,
                                        scale: 0,
                                        x: 0,
                                        y: 0,
                                      }}
                                      animate={{
                                        opacity: 0,
                                        scale: Math.random() * 1.5 + 0.5,
                                        x: (Math.random() - 0.5) * 200,
                                        y: (Math.random() - 0.5) * 150,
                                      }}
                                      transition={{
                                        duration: 1.5,
                                        ease: "easeOut",
                                      }}
                                    />
                                  ))}
                                  <motion.span
                                    initial={{ scale: 0.5, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    className="font-bold flex items-center gap-2 drop-shadow-md"
                                  >
                                    <svg
                                      viewBox="0 0 24 24"
                                      width="18"
                                      height="18"
                                      stroke="currentColor"
                                      strokeWidth="3"
                                      fill="none"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      className="mr-1"
                                    >
                                      <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg>
                                    SUCCESS!
                                  </motion.span>
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {isSubmitting ? (
                              <Loader2 className="mr-3 z-0 w-5 h-5 animate-spin" />
                            ) : paymentConfigured ? (
                              <svg
                                viewBox="0 0 24 24"
                                width="20"
                                height="20"
                                stroke="currentColor"
                                strokeWidth="2"
                                fill="none"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="mr-3 z-0"
                              >
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                              </svg>
                            ) : (
                              <svg
                                viewBox="0 0 24 24"
                                width="20"
                                height="20"
                                stroke="currentColor"
                                strokeWidth="2"
                                fill="none"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="mr-3 z-0"
                              >
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                              </svg>
                            )}
                            <span
                              className={`${showSuccess ? "opacity-0" : "opacity-1000"} transition-opacity z-0`}
                            >
                              {isSubmitting ? "Processing..." : paymentConfigured ? "Proceed to Payment" : "Confirm Booking"}
                            </span>
                          </button>

                          {syncFailed && (
                            <p
                              role="status"
                              className="text-xs text-gold-400 bg-gold-500/10 border border-gold-500/20 rounded-lg px-4 py-2.5 mt-1 leading-relaxed"
                            >
                              Your booking has been saved successfully. We couldn't sync it to our server right now — our team will still review your request.
                            </p>
                          )}

                          <a
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              const formEl = (e.currentTarget as HTMLElement).closest("form");
                              const nameInput = formEl?.querySelector<HTMLInputElement>('[name="name"]');
                              const typedName = nameInput?.value || undefined;
                              const dateTimeStr = selectedDate && selectedTime
                                ? `${selectedDate.toLocaleDateString()} at ${selectedTime}`
                                : undefined;
                              safeOpenLink(generateWhatsAppLink(typedName, selectedService || undefined, dateTimeStr));
                            }}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-full flex items-center justify-center py-4 bg-transparent border-2 border-[#25D366] text-[#25D366] rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-[#25D366] hover:text-white transition-all hover:shadow-[0_0_20px_-5px_rgba(37,211,102,0.4)] mt-2"
                          >
                             <svg
                              viewBox="0 0 24 24"
                              width="20"
                              height="20"
                              stroke="currentColor"
                              strokeWidth="2"
                              fill="none"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="mr-3"
                            >
                              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                            </svg>
                            <span>Chat on WhatsApp Business</span>
                          </a>
                        </form>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
          </div>
        </div>
      </div>

      {/* Preparation Checklist Modal */}
      <AnimatePresence>
        {showChecklist && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-brand-900/95 backdrop-blur-sm"
            onClick={() => setShowChecklist(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-brand-800 border border-gold-500/30 w-full max-w-md p-6 rounded shadow-2xl relative"
              role="dialog"
              aria-modal="true"
              aria-labelledby="checklist-modal-title"
            >
              <button
                onClick={() => setShowChecklist(false)}
                className="absolute top-4 right-4 text-text-main hover:text-gold-500 active:scale-95 transition-colors p-2 touch-manipulation"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gold-500/10 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-gold-500" />
                </div>
                <h3 id="checklist-modal-title" className="text-xl font-serif text-text-main font-bold">Preparation Checklist</h3>
              </div>
              
              <p className="text-sm text-text-main mb-6 leading-relaxed">
                To make the most of our consultation, please ensure you have the following prepared:
              </p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <div className="mt-0.5 w-1.5 h-1.5 bg-gold-500 rounded-full shrink-0" />
                  <span className="text-sm text-text-main">Clear objectives for your consultation.</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-0.5 w-1.5 h-1.5 bg-gold-500 rounded-full shrink-0" />
                  <span className="text-sm text-text-main">Any relevant documents, financial summaries, or portfolio details.</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-0.5 w-1.5 h-1.5 bg-gold-500 rounded-full shrink-0" />
                  <span className="text-sm text-text-main">Your specific questions written down in advance.</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="mt-0.5 w-1.5 h-1.5 bg-gold-500 rounded-full shrink-0" />
                  <span className="text-sm text-text-main">A quiet environment with a stable internet connection.</span>
                </li>
              </ul>
              
              <button
                onClick={() => setShowChecklist(false)}
                className="w-full bg-gold-500 text-brand-900 font-bold py-3 text-sm uppercase tracking-wider hover:bg-gold-400 active:bg-gold-600 active:scale-[0.98] transition-all touch-manipulation"
              >
                I Understand
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stripe Transaction Success Modal */}
      <AnimatePresence>
        {showStripeSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-brand-900/95 backdrop-blur-md"
            onClick={() => setShowStripeSuccess(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 30 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-brand-800 border-2 border-gold-500/50 w-full max-w-lg p-8 rounded-2xl shadow-2xl relative overflow-hidden text-center"
              role="dialog"
              aria-modal="true"
              aria-labelledby="stripe-success-modal-title"
            >
              {/* Background Glow */}
              <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-emerald-500/10 blur-[60px] rounded-full pointer-events-none"></div>
              <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-gold-500/10 blur-[60px] rounded-full pointer-events-none"></div>

              <button
                onClick={() => setShowStripeSuccess(false)}
                className="absolute top-5 right-5 text-text-main hover:text-gold-500 active:scale-95 transition-colors p-2 touch-manipulation z-10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex flex-col items-center mb-6">
                <div className="w-16 h-16 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-full flex items-center justify-center mb-4 relative shadow-[0_0_20px_rgba(16,185,129,0.2)]">
                  <span className="absolute inset-0 rounded-full bg-emerald-500/5 animate-ping"></span>
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 id="stripe-success-modal-title" className="text-2xl font-serif text-gold-400 font-bold mb-1 tracking-wide">
                  Payment Processed Successfully!
                </h3>
                <p className="text-sm text-text-main font-mono text-emerald-400 uppercase tracking-widest">
                  Secure Alignment Activated
                </p>
              </div>

              <p className="text-sm text-text-main/90 leading-relaxed mb-6">
                Your payment has been securely completed. I've registered your reservation and sent direct confirmation to your specified accounts.
              </p>

              {stripeBookingDetails && (
                <div className="bg-[#1A0F0A]/80 border border-gold-500/20 text-left p-5 rounded-xl mb-6 space-y-3 shadow-inner">
                  <div className="text-[10px] uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005]/80 px-2.5 py-1 rounded inline-block border border-gold-500/20">
                    Registration Blueprint
                  </div>
                  <div className="grid grid-cols-3 gap-y-2 text-xs">
                    <span className="text-[#FFF6EC]/55">Client Name:</span>
                    <span className="col-span-2 text-white font-semibold">{stripeBookingDetails.name}</span>
                    
                    <span className="text-[#FFF6EC]/55">Consultation:</span>
                    <span className="col-span-2 text-white font-semibold">{stripeBookingDetails.concern ? stripeBookingDetails.concern.split("] ").pop() : stripeBookingDetails.service || "Strategy Consultation"}</span>
                    
                    <span className="text-[#FFF6EC]/55">Auspicious Window:</span>
                    <span className="col-span-2 text-gold-400 font-bold font-mono">{stripeBookingDetails.date}</span>

                    <span className="text-[#FFF6EC]/55">Email Saved:</span>
                    <span className="col-span-2 text-white">{stripeBookingDetails.email}</span>

                    <span className="text-[#FFF6EC]/55">Payment Status:</span>
                    <span className="col-span-2 text-emerald-400 font-bold font-mono">Secured</span>
                  </div>
                </div>
              )}

              <p className="text-xs text-text-main opacity-85 leading-relaxed mb-8 italic">
                Note: A digital payment invoice receipt has been dispatched. I'll coordinate the Google Meet link and call details directly.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={generateWhatsAppLink(
                    stripeBookingDetails?.name,
                    stripeBookingDetails?.concern ? stripeBookingDetails.concern.split("] ").pop() : stripeBookingDetails?.service,
                    stripeBookingDetails?.date
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 w-full bg-[#25D366] text-white font-bold py-3 text-sm uppercase tracking-wider rounded-lg hover:bg-[#20ba56] transition-all flex items-center justify-center gap-2 active:scale-[0.98] shadow-lg"
                >
                  <svg
                    viewBox="0 0 24 24"
                    width="16"
                    height="16"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                  </svg>
                  <span>Chat on WhatsApp Business</span>
                </a>
                <button
                  onClick={() => setShowStripeSuccess(false)}
                  className="flex-1 w-full bg-gold-500 text-brand-900 font-bold py-3 text-sm uppercase tracking-wider rounded-lg hover:bg-gold-400 active:scale-[0.98] transition-all"
                >
                  Perfect, Thank You
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <PrePaymentModal
        isOpen={prePaymentOpen}
        onClose={() => setPrePaymentOpen(false)}
        serviceTitle={prePaymentServiceForModal}
      />
    </section>
  );
}
