import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Send, Sparkles, Loader2 } from "lucide-react";
import { API_BASE_URL } from "../config";
import { chatTopics, ChatTopic } from "../data/chatbotKnowledge";
import { PrePaymentModal } from "./PrePaymentModal";

type Message = { 
  text: string; 
  sender: "bot" | "user";
  isHtml?: boolean;
  disambiguationOptions?: { label: string; topicId: string }[];
};

type Language = "en" | "hi";

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [prePaymentOpen, setPrePaymentOpen] = useState(false);
  const [language, setLanguage] = useState<Language>("en");

  // Keyboard accessibility: Escape closes the chat dialog while it's open.
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsOpen(false);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen]);
  
  // Welcome messages based on language
  const welcomeMessageEn = "Namaste. 🙏 I'm the Ethos Assistant, infused with Jitin's 20+ years of corporate leadership and Vedic wisdom. Select a topic below or write any question - I converse fluently in both English and Hindi!";
  const welcomeMessageHi = "नमस्ते। 🙏 मैं ईथोस सहायक हूँ, जितिन के 20+ वर्षों के कॉर्पोरेट नेतृत्व और वैदिक ज्ञान से परिपूर्ण। नीचे दिए गए किसी विषय को चुनें या कोई भी प्रश्न लिखें - मैं अंग्रेजी और हिंदी दोनों भाषाओं में सहज बातचीत कर सकता हूँ!";

  const [messages, setMessages] = useState<Message[]>([
    {
      text: welcomeMessageEn,
      sender: "bot",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [aiChatEnabled, setAiChatEnabled] = useState(true); // assume true until we know otherwise, so we don't skip a genuinely working AI setup
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/chat-config`)
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.aiChatEnabled === "boolean") {
          setAiChatEnabled(data.aiChatEnabled);
        }
      })
      .catch(() => {
        // If the check itself fails, assume AI is unavailable and rely on the
        // instant WhatsApp fallback rather than attempting a doomed AI call.
        setAiChatEnabled(false);
      });
  }, []);


  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen, isLoading]);

  // Handle language changes and update initial greeting if it's the only message
  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    if (messages.length === 1) {
      setMessages([
        {
          text: lang === "en" ? welcomeMessageEn : welcomeMessageHi,
          sender: "bot"
        }
      ]);
    } else {
      // Append a helpful language switched indicator
      setMessages(prev => [
        ...prev,
        {
          text: lang === "en" ? "🔄 Switched to English conversation." : "🔄 हिन्दी बातचीत में स्विच किया गया।",
          sender: "bot"
        }
      ]);
    }
  };

  // Score every topic against the user's message. Longer, more specific keyword
  // phrases score higher than short generic words, which keeps single-topic
  // matches confident while surfacing genuine ambiguity when it exists.
  const matchTopics = (text: string): { topic: ChatTopic; score: number }[] => {
    const normal = text.toLowerCase();
    const scored = chatTopics
      .map((topic) => {
        let score = 0;
        for (const kw of topic.keywords) {
          if (normal.includes(kw.toLowerCase())) {
            score += kw.length; // longer/more specific phrase = stronger signal
          }
        }
        return { topic, score };
      })
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score);
    return scored;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    setInput("");
    
    // Add User Message to screen
    const newMessages: Message[] = [...messages, { text: userText, sender: "user" }];
    setMessages(newMessages);
    setIsLoading(true);

    // 1. First check our local knowledge base (instant, zero-latency, always available)
    const matches = matchTopics(userText);

    if (matches.length > 0) {
      const top = matches[0];
      const second = matches[1];
      // Genuine ambiguity: a second topic scores within 70% of the top one.
      // A single dominant match (or only one match at all) answers directly.
      const isAmbiguous = second && second.score >= top.score * 0.7;

      setTimeout(() => {
        if (isAmbiguous) {
          const topChoices = matches.slice(0, 3);
          const clarifyText = language === "en"
            ? "Just to make sure I give you the right answer — which of these is closest to what you mean?"
            : "सही जवाब देने के लिए — इनमें से कौन सा आपके सवाल से सबसे मिलता-जुलता है?";
          setMessages(prev => [...prev, {
            text: clarifyText,
            sender: "bot",
            disambiguationOptions: topChoices.map(m => ({ label: m.topic.label, topicId: m.topic.id })),
          }]);
        } else {
          const reply = language === "en" ? top.topic.replyEn : top.topic.replyHi;
          setMessages(prev => [...prev, { text: reply, sender: "bot", isHtml: true }]);
        }
        setIsLoading(false);
      }, 400);
      return;
    }

    // 2. Fallback to server-side Gemini AI in a fully bulletproof manner —
    // but skip the network round-trip entirely if we already know AI isn't configured,
    // so the WhatsApp fallback appears instantly instead of after a doomed fetch attempt.
    if (!aiChatEnabled) {
      const fallbackText = language === "en" 
        ? "For a detailed answer to that, let's connect directly on my WhatsApp at +91 8796578959. Choose any of our 4 key services below to get instant scheduling priority!"
        : "इसके विस्तृत उत्तर के लिए, कृपया मेरे व्हाट्सएप नंबर +91 8796578959 पर सीधे संपर्क करें। किसी भी सेवा के विषय में बात करने के लिए तत्पर हूँ!";
      setMessages(prev => [...prev, { text: fallbackText, sender: "bot" }]);
      setIsLoading(false);
      return;
    }

    try {
      const history = newMessages.slice(1).map(m => ({ role: m.sender === "user" ? "user" : "model", text: m.text }));
      
      const res = await fetch(`${API_BASE_URL}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText, history: history })
      });

      // Avoid JSON parsing crash if backend replies with raw HTML or error
      if (!res.ok) {
        throw new Error(`HTTP status ${res.status}`);
      }

      const contentType = res.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error("Server returned non-JSON response");
      }

      const data = await res.json();
      
      if (data.response) {
        setMessages(prev => [...prev, { text: data.response, sender: "bot" }]);
      } else {
        throw new Error(data.error || "Blank response");
      }
    } catch (err: any) {
      console.warn("AI Chat failed, routing user to curated fallback options safely.", err);
      
      // Beautiful custom response so it is ALWAYS error free and continues to help
      const fallbackText = language === "en" 
        ? "I am currently synthesizing custom strategy insights. To get a high-quality guaranteed immediate resolution, let's connect directly on my WhatsApp at +91 8796578959. Choose any of our 5 key services to get instant scheduling priority!"
        : "मैं अभी आपके लिए नए कॉस्मिक संरेखण संकलित कर रहा हूँ। तत्काल और शत-प्रतिशत सहायता के लिए, कृपया मेरे व्हाट्सएप नंबर +91 8796578959 पर सीधे संपर्क करें। किसी भी सेवा के विषय में बात करने के लिए तत्पर हूँ!";
      
      setMessages(prev => [...prev, { text: fallbackText, sender: "bot" }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChipClick = (topicName: string, queryText: string) => {
    // Inject prompt on behalf of user
    const newMessages: Message[] = [...messages, { text: topicName, sender: "user" }];
    setMessages(newMessages);
    setIsLoading(true);

    const matches = matchTopics(queryText);
    const topMatch = matches[0];
    setTimeout(() => {
      if (topMatch) {
        const reply = language === "en" ? topMatch.topic.replyEn : topMatch.topic.replyHi;
        setMessages(prev => [...prev, { text: reply, sender: "bot", isHtml: true }]);
      } else {
        const defaultSvcText = language === "en"
          ? `I'd love to assist you with ${topicName}. Let's discuss this directly on WhatsApp for immediate and personalized planning with Jitin.`
          : `मैं आपके साथ ${topicName} के बारे में चर्चा करने के लिए तैयार हूँ। त्वरित योजना और व्यक्तिगत परामर्श के लिए सीधे व्हाट्सएप पर जुड़ें।`;
        setMessages(prev => [...prev, { text: defaultSvcText, sender: "bot" }]);
      }
      setIsLoading(false);
    }, 450);
  };

  // When the user clicks a clarification option (after we asked "which do you mean?"),
  // add their choice as a user message, then reply with that specific topic's answer.
  const handleDisambiguationClick = (label: string, topicId: string) => {
    const newMessages: Message[] = [...messages, { text: label, sender: "user" }];
    setMessages(newMessages);
    setIsLoading(true);

    const topic = chatTopics.find(t => t.id === topicId);
    setTimeout(() => {
      if (topic) {
        const reply = language === "en" ? topic.replyEn : topic.replyHi;
        setMessages(prev => [...prev, { text: reply, sender: "bot", isHtml: true }]);
      }
      setIsLoading(false);
    }, 350);
  };

  const handleWhatsAppDirect = () => {
    setPrePaymentOpen(true);
  };

  // Predefined interactive chips/suggestions depending on selected language
  const chipsEn = [
    { label: "🧘 Get Vastu Tips", query: "vastu" },
    { label: "✨ Astrology Timing", query: "astrology" },
    { label: "🤝 Book Consulting", query: "book" },
    { label: "👤 Who is Jitin Goel?", query: "jitin" },
  ];

  const chipsHi = [
    { label: "🧘 वास्तु शास्त्र सुझाव", query: "vastu" },
    { label: "✨ ज्योतिष अनुकूल समय", query: "astrology" },
    { label: "🤝 कंसल्टिंग बुक करें", query: "book" },
    { label: "👤 जितिन गोयल कौन हैं?", query: "jitin" },
  ];

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 1.2, duration: 0.5 }}
            onClick={() => setIsOpen(true)}
            className="floating-control-widget chatbot-toggle-btn group"
            aria-label="Open AI Assistant Chat"
          >
            <Sparkles className="w-6 h-6 sm:w-7 sm:h-7 text-brand-900 animate-pulse" />
            <span className="absolute right-full top-1/2 -translate-y-1/2 mr-4 whitespace-nowrap bg-brand-900 text-gold-400 text-[10px] sm:text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-sm opacity-0 group-hover:opacity-1000 transition-opacity pointer-events-none border border-gold-500/20 shadow-xl hidden sm:block">
              Consult Ethos Bot
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Ethos Hybrid Assistant Chat"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-[60] w-[calc(100vw-2rem)] sm:w-[400px] bg-brand-900 border border-gold-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[620px] h-[85vh] sm:h-[580px]"
          >
            {/* Header */}
            <div className="bg-brand-800 p-4 flex justify-between items-center border-b border-gold-500/20 text-text-main relative overflow-hidden shrink-0">
              <div className="absolute inset-0 bg-gold-500/5 pointer-events-none"></div>
              <div className="flex items-center gap-3 relative z-10">
                <div className="w-8.5 h-8.5 rounded-full bg-gold-400 flex items-center justify-center text-brand-900 font-bold shadow-lg shadow-gold-500/20">
                  <Sparkles className="w-4.5 h-4.5 text-brand-900" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gold-500 tracking-wide flex items-center gap-1.5">
                    Ethos Assistant
                    <span className="text-[10px] bg-gold-500/10 text-gold-400 px-1.5 py-0.5 rounded border border-gold-500/20 font-mono font-medium">Dual Lang</span>
                  </h3>
                  <p className="text-[10px] uppercase tracking-wider text-text-main/70">
                    20+ Yrs Corporate & Vedic Expert
                  </p>
                </div>
              </div>

              {/* Language Switcher and Close Buttons */}
              <div className="flex items-center gap-2 relative z-10">
                <div className="flex bg-brand-900/80 border border-gold-500/20 rounded-full p-0.5 text-[10px]">
                  <button 
                    onClick={() => handleLanguageChange("en")}
                    className={`px-2 py-1 rounded-full transition-all font-bold ${language === "en" ? "bg-gold-500 text-brand-900" : "text-text-main/70 hover:text-white"}`}
                  >
                    EN
                  </button>
                  <button 
                    onClick={() => handleLanguageChange("hi")}
                    className={`px-2 py-1 rounded-full transition-all font-bold ${language === "hi" ? "bg-gold-500 text-brand-900" : "text-text-main/70 hover:text-white"}`}
                  >
                    हिन्द
                  </button>
                </div>
                
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 px-2 hover:bg-gold-500/10 rounded-md border border-gold-500/10 transition-colors"
                  aria-label="Close Chat"
                >
                  <X className="w-4.5 h-4.5 text-gold-400" />
                </button>
              </div>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-brand-900/60 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-800/20 via-brand-900 to-brand-900 scrollbar-thin">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-3 ${message.sender === "user" ? "flex-row-reverse" : "flex-row"}`}
                >
                  <div className={`w-8 h-8 shrink-0 rounded-full flex items-center justify-center mt-1 ${message.sender === "user" ? "hidden" : "bg-gold-500/10 text-gold-400 border border-gold-500/20"}`}>
                    {message.sender === "bot" && <Sparkles className="w-4 h-4 text-gold-400" />}
                  </div>
                  <div
                    className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed shadow-md ${
                      message.sender === "user"
                        ? "bg-gold-500 text-brand-900 rounded-tr-none font-medium"
                        : "bg-brand-800 text-text-main border border-gold-500/20 rounded-tl-none"
                    }`}
                  >
                    {message.isHtml ? (
                      <div dangerouslySetInnerHTML={{ __html: message.text }} className="space-y-1.5" />
                    ) : (
                      <p className="whitespace-pre-line">{message.text}</p>
                    )}
                    {message.disambiguationOptions && message.disambiguationOptions.length > 0 && (
                      <div className="flex flex-col gap-1.5 mt-2.5">
                        {message.disambiguationOptions.map((opt) => (
                          <button
                            key={opt.topicId}
                            onClick={() => handleDisambiguationClick(opt.label, opt.topicId)}
                            className="text-left text-xs bg-brand-900/60 hover:bg-gold-500 hover:text-brand-900 text-gold-500 border border-gold-500/25 px-3 py-2 rounded-lg transition-all cursor-pointer font-medium"
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {isLoading && (
                 <div className="flex gap-3">
                   <div className="w-8 h-8 shrink-0 rounded-full bg-gold-500/10 text-gold-400 border border-gold-500/20 flex items-center justify-center mt-1">
                     <Loader2 className="w-4 h-4 animate-spin text-gold-400" />
                   </div>
                   <div className="p-3.5 rounded-2xl bg-brand-800 border border-gold-500/15 text-text-main rounded-tl-none text-sm font-light">
                     {language === "en" ? "Consulting Jitin's strategy map..." : "वैदिक संरेखण की गणना की जा रही है..."}
                   </div>
                 </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Curated Predefined suggestions quick-tabs */}
            <div className="px-4 py-2 border-t border-gold-500/10 bg-brand-900 shrink-0">
              <span className="text-[10px] text-gold-400/60 uppercase tracking-widest font-mono block mb-1.5">
                {language === "en" ? "Suggested Topics:" : "सुझाए गए विषय:"}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {(language === "en" ? chipsEn : chipsHi).map((chip) => (
                  <button
                    key={chip.label}
                    onClick={() => handleChipClick(chip.label, chip.query)}
                    className="text-[11px] bg-brand-800/80 hover:bg-gold-500 hover:text-brand-900 text-text-main border border-gold-500/15 px-2.5 py-1 rounded-full transition-all cursor-pointer font-medium"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Input & WhatsApp Callout */}
            <div className="p-4 bg-brand-800 border-t border-gold-500/20 shrink-0">
              
              {/* WhatsApp Call to action bottom ribbon */}
              <div className="flex justify-between items-center mb-3 bg-brand-900/50 border border-gold-500/10 rounded-xl p-2.5 text-xs text-text-main/90">
                <span className="flex items-center gap-1.5 font-medium">
                  <span className="w-2 h-2 rounded-full referee-dot bg-green-500 inline-block animate-ping"></span>
                  {language === "en" ? "Instantly Book via WhatsApp" : "व्हाट्सएप से परामर्श बुक करें"}
                </span>
                <button 
                  onClick={handleWhatsAppDirect}
                  className="flex items-center gap-1 font-bold text-gold-400 hover:text-gold-500 transition-colors uppercase tracking-widest text-[10px]"
                >
                  {language === "en" ? "Chat on WhatsApp Business" : "WhatsApp Business पर चैट करें"} &rarr;
                </button>
              </div>

              <form onSubmit={handleSubmit} className="flex relative">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={language === "en" ? "Ask about strategy, Vastu, or Astrology..." : "रणनीति, वास्तु, या ज्योतिष के बारे में पूछें..."}
                  aria-label={language === "en" ? "Ask about strategy, Vastu, or Astrology" : "रणनीति, वास्तु, या ज्योतिष के बारे में पूछें"}
                  className="w-full bg-brand-900 border border-gold-500/30 text-text-main text-sm px-4 py-3 rounded-full focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500/50 pr-12 transition-all placeholder:text-text-main"
                  disabled={isLoading}
                  autoComplete="off"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gold-400 hover:bg-gold-500/10 rounded-full disabled:opacity-40 transition-colors flex items-center justify-center"
                  aria-label="Send message"
                >
                  <Send className="w-4 h-4 text-gold-400" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <PrePaymentModal
        isOpen={prePaymentOpen}
        onClose={() => setPrePaymentOpen(false)}
      />
    </>
  );
}
