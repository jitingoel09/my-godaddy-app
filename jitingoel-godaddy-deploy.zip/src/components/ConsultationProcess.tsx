import { motion } from "motion/react";
import { Search, Layers, Target } from "lucide-react";
import processImg from "../assets/images/pen_writing_process.webp";

const steps = [
  {
    num: "01",
    icon: Search,
    title: "Understand the Complete Picture",
    desc: "I start by understanding the business, professional, personal, or decision context relevant to you.",
  },
  {
    num: "02",
    icon: Layers,
    title: "Analyse Strategy, Patterns & Timing",
    desc: "I examine the practical circumstances, recurring patterns, available choices, and — where relevant — Vedic timing.",
  },
  {
    num: "03",
    icon: Target,
    title: "Define a Clear Direction",
    desc: "Findings are organised into clearer priorities, decision considerations, and a structured next step.",
  },
];

export function ConsultationProcess() {
  return (
    <section id="consultation-process" className="process-step-indicator py-16 bg-page-bg-800 relative border-t border-gold-500/20 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.07] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${processImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-800 via-transparent to-page-bg-800 pointer-events-none"></div>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
            The Process
          </h2>
          <h3 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight">
            What Happens in a Consultation?
          </h3>
        </div>

        <div className="grid sm:grid-cols-3 gap-6 relative">
          <div className="hidden sm:block absolute top-9 left-[16.5%] right-[16.5%] h-px bg-gradient-to-r from-gold-500/10 via-gold-500/40 to-gold-500/10"></div>
          {steps.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative text-center"
            >
              <div className="w-[72px] h-[72px] rounded-full bg-[#8B3005] border border-gold-500/30 flex items-center justify-center mx-auto mb-4 relative z-10">
                <s.icon className="w-6 h-6 text-gold-400" />
              </div>
              <span className="text-[10px] uppercase tracking-widest font-mono text-gold-500/70 font-bold">Step {s.num}</span>
              <h4 className="text-base font-serif font-semibold text-text-main mt-1 mb-2">{s.title}</h4>
              <p className="text-xs text-text-main/70 leading-relaxed px-2">{s.desc}</p>
            </motion.div>
          ))}
        </div>

        <p className="text-center text-xs text-text-main/50 mt-10 max-w-xl mx-auto italic">
          Every consultation begins with the area that matters most to you — not every session covers all four dimensions.
        </p>
      </div>
    </section>
  );
}
