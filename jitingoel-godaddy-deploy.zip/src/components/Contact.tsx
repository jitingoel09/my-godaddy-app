import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Phone, ChevronDown, CheckCircle2, Sparkles, Calendar, Copy, Check } from "lucide-react";
import { contactImage } from "../utils/imageRegistry";
import contactFallbackImg from "../assets/images/boardroom_chairs_authority.webp";
import { PrePaymentModal } from "./PrePaymentModal";

export function Contact() {
  const [isOpen, setIsOpen] = useState(false);
  const [prePaymentOpen, setPrePaymentOpen] = useState(false);
  const [prePaymentService, setPrePaymentService] = useState("");
  const [emailCopied, setEmailCopied] = useState(false);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText("jitin09@jitingoel.com");
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 2000);
    } catch {
      // Clipboard API can fail in some contexts (e.g. non-HTTPS); fail silently,
      // the mailto link itself still works as the primary path.
    }
  };

  const sessionTypes = [
    "Business Strategy & Growth Consulting",
    "Career & Professional Consulting",
    "Cosmic Astrology Consultation",
    "Personal Transformation Consulting"
  ];

  const handleSelect = (type: string) => {
    setPrePaymentService(type);
    setPrePaymentOpen(true);
    setIsOpen(false);
  };

  // Keyboard accessibility: Escape closes the open service-selector dropdown.
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsOpen(false);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen]);

  return (
    <section
      id="contact"
      className="py-14 relative border-t border-gold-500/20 bg-page-bg-900 overflow-hidden"
    >
      {/* Cosmic Universe Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-page-bg-800 to-page-bg-700"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold-500/10 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-[100px]"></div>
        {/* Simple stars effect */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjUpIi8+CjxjaXJjbGUgY3g9IjcwIiBjeT0iMTUiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIxMTAiIGN5PSI1NSIgcj0iMS4yIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNCkiLz4KPGNpcmNsZSBjeD0iMTUwIiBjeT0iMjAiIHI9IjAuNiIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjE4MCIgY3k9IjcwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNDUpIi8+CjxjaXJjbGUgY3g9IjQwIiBjeT0iOTAiIHI9IjAuOCIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjkwIiBjeT0iMTEwIiByPSIxLjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8Y2lyY2xlIGN4PSIxNDAiIGN5PSIxMzAiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIyMCIgY3k9IjE1MCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjQpIi8+CjxjaXJjbGUgY3g9IjE3MCIgY3k9IjE2MCIgcj0iMC45IiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuMzUpIi8+CjxjaXJjbGUgY3g9IjYwIiBjeT0iMTgwIiByPSIwLjYiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC4zKSIvPgo8Y2lyY2xlIGN4PSIxMjAiIGN5PSIxODUiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8L3N2Zz4=')] opacity-80"></div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-5xl mx-auto">
          {/* Contact Header */}
          <div className="text-center max-w-3xl mx-auto mb-16 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 sm:py-10 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm">
            <h3 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
              Secure Your Guidance
            </h3>
            <h2 className="text-3xl sm:text-4xl font-serif text-[#FFB066] mb-4 font-bold" style={{textShadow: '0px 2px 4px rgba(0,0,0,0.3)'}}>
              See the Complete Picture Before Your Next Decision
            </h2>
            <p className="text-base text-[#FFF5EB]/90 leading-relaxed font-normal mb-3">
              Whether the question is business, professional, personal, or timing-related, the consultation begins by understanding the complete context.
            </p>
            <p className="text-sm text-[#FFF5EB]/70 leading-relaxed font-normal italic mb-5">
              You may begin with one specific area, or explore the wider interconnected picture — every consultation starts with what matters most to you.
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {["Confidential Consultation", "Practical Experience", "Vedic Wisdom"].map((tag) => (
                <span key={tag} className="text-[10px] uppercase tracking-wider font-mono font-bold text-gold-400/90 bg-brand-950/50 border border-gold-500/20 px-3 py-1.5 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch"
          >
            {/* Left Column: Pictorial Presentation Card */}
            <div className="lg:col-span-5 relative rounded-2xl overflow-hidden border border-gold-500/15 bg-brand-950/40 flex flex-col justify-end p-6 sm:p-8 min-h-[300px] lg:min-h-full group">
              <div className="absolute inset-0">
                <img 
                  src={contactImage} 
                  alt="Professional strategic consultation session" 
                  className="w-full h-full object-cover opacity-100 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  onError={(e) => { (e.target as HTMLImageElement).src = contactFallbackImg; }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#6F2604] via-[#6F2604]/40 to-transparent"></div>
              </div>
              
              <div className="relative z-10 space-y-3">
                <div className="inline-flex items-center gap-1.5 bg-[#8B3005] border border-[#FFF6EC]/50 px-2.5 py-1 rounded-md text-[10px] text-[#FFF6EC] font-bold uppercase tracking-wider font-mono">
                  <Sparkles className="w-3 h-3 text-[#FFF6EC]" /> Executive Guidance
                </div>
                <h4 className="text-xl sm:text-2xl font-serif text-text-main">
                  Let's Align Your Success Timeline
                </h4>
                <p className="text-xs text-text-main font-normal leading-relaxed">
                  Business decisions and career moves, evaluated alongside your birth chart timing — for added clarity, not guaranteed outcomes.
                </p>
              </div>
            </div>

            {/* Right Column: Contact Action details */}
            <div className="lg:col-span-7 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] backdrop-blur-xl border border-gold-500/20 p-8 sm:p-10 rounded-2xl shadow-2xl flex flex-col justify-between">
              <div className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  
                  {/* Phone Details */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-green-500 shrink-0 shadow-[0_0_15px_rgba(34,197,94,0.3)]">
                      <Phone className="w-5 h-5 fill-green-500/20" />
                    </div>
                    <div>
                      <p className="text-[9px] uppercase tracking-widest text-[#FFF6EC] mb-1 font-mono">
                        Direct Line
                      </p>
                      <a
                        href="tel:+918796578959"
                        className="text-base sm:text-lg font-serif text-[#FFF6EC] hover:text-gold-500 transition-colors block"
                      >
                        +91 8796578959
                      </a>
                    </div>
                  </div>

                  {/* Email Details */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-red-500 shrink-0 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                      <Mail className="w-5 h-5 fill-red-500/20" />
                    </div>
                    <div>
                      <p className="text-[9px] uppercase tracking-widest text-[#FFF6EC] mb-1 font-mono">
                        Email Inquiry
                      </p>
                      <div className="flex items-center gap-2">
                        <a
                          href="mailto:jitin09@jitingoel.com"
                          className="text-base sm:text-lg font-serif text-[#FFF6EC] hover:text-gold-500 transition-colors break-all"
                        >
                          jitin09@jitingoel.com
                        </a>
                        <button
                          type="button"
                          onClick={handleCopyEmail}
                          aria-label="Copy email address"
                          title="Copy email address"
                          className="shrink-0 p-1.5 rounded-full text-text-main/60 hover:text-gold-500 hover:bg-white/5 transition-colors"
                        >
                          {emailCopied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                      {emailCopied && (
                        <p className="text-xs text-green-400 mt-1">Copied to clipboard!</p>
                      )}
                    </div>
                  </div>

                </div>

                {/* LinkedIn and WhatsApp Selection */}
                <div className="border-t border-gold-500/10 pt-8 grid grid-cols-1 sm:grid-cols-2 gap-8 items-center">
                  
                  <div className="pt-2 sm:pt-0">
                    <button
                      onClick={() => {
                        document.getElementById("book")?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="w-full flex items-center justify-center h-12 px-5 bg-gold-500 text-brand-900 rounded-full text-[10px] font-bold uppercase tracking-wider hover:bg-gold-400 active:scale-95 transition-all hover:shadow-[0_0_20px_-5px_rgba(212,175,55,0.4)] cursor-pointer"
                    >
                      <Calendar className="mr-2 w-4 h-4 text-brand-900 shrink-0" />
                      Let's Get Started
                    </button>
                  </div>

                  <div className="relative pt-2 sm:pt-0">
                    <button
                      onClick={() => setIsOpen(!isOpen)}
                      className="w-full flex items-center justify-center h-12 px-5 bg-[#25D366] border-2 border-[#25D366] text-white rounded-full text-[10px] font-bold uppercase tracking-wider hover:bg-[#128C7E] hover:border-[#128C7E] active:scale-95 transition-all hover:shadow-[0_0_20px_-5px_rgba(37,211,102,0.4)]"
                      aria-expanded={isOpen}
                      aria-haspopup="listbox"
                      aria-label="Toggle WhatsApp consultation selection list"
                    >
                      <svg
                        viewBox="0 0 24 24"
                        width="18"
                        height="18"
                        stroke="currentColor"
                        strokeWidth="2"
                        fill="none"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-2 shrink-0"
                      >
                        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                      </svg>
                      {isOpen ? 'Select Service' : 'Chat on WhatsApp Business'}
                      <ChevronDown className={`ml-1.5 w-3.5 h-3.5 transition-transform shrink-0 ${isOpen ? "rotate-180" : ""}`} />
                    </button>

                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute z-[100] w-full bottom-full mb-2 bg-brand-800 border border-gold-500/20 rounded-lg shadow-xl overflow-hidden"
                          role="listbox"
                          aria-label="Consultation type"
                        >
                          {sessionTypes.map((type, index) => (
                            <button
                              key={index}
                              onClick={() => handleSelect(type)}
                              role="option"
                              aria-selected={prePaymentService === type}
                              className="w-full text-left px-4 py-2.5 text-xs text-text-main hover:bg-brand-700 hover:text-gold-500 transition-colors flex items-center justify-between group border-b border-white/5 last:border-b-0"
                            >
                              <span>{type}</span>
                              <CheckCircle2 className="w-3.5 h-3.5 opacity-0 group-hover:opacity-1000 text-[#25D366] transition-opacity shrink-0" />
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <PrePaymentModal
        isOpen={prePaymentOpen}
        onClose={() => setPrePaymentOpen(false)}
        serviceTitle={prePaymentService}
      />
    </section>
  );
}
