import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import vastuBlueprintImg from "../assets/images/vastu_blueprint.webp";
import numerologyCrystalsImg from "../assets/images/numerology_crystals.webp";
import { 
  Sparkles, 
  Compass, 
  Calendar, 
  User, 
  ShieldCheck, 
  CheckCircle, 
  AlertCircle, 
  Settings, 
  Activity, 
  ExternalLink
} from "lucide-react";
import confetti from "canvas-confetti";
import cosmicBanner from "../assets/images/cosmic_alignment_calculator_1781330713441.webp";
import cosmicToolsBg from "../assets/images/cosmic_tools_bg_1781331114602.webp";

// Chaldean letter values for Namank (Name Number)
const CHALDEAN_VALUES: Record<string, number> = {
  a: 1, i: 1, j: 1, q: 1, y: 1,
  b: 2, k: 2, r: 2,
  c: 3, g: 3, l: 3, s: 3,
  d: 4, m: 4, t: 4,
  e: 5, h: 5, n: 5, x: 5,
  u: 6, v: 6, w: 6,
  o: 7, z: 7,
  f: 8, p: 8
};

// Map single digits 1-9 to their ruling planetary archetypes and custom corporate strategy advice
const ARCHETYPES: Record<number, {
  name: string;
  ruler: string;
  positive: string[];
  growth: string;
  strategy: string;
  strategicAdvice: string;
  color: string;
  bgGrad: string;
}> = {
  1: {
    name: "The Pioneering Executive",
    ruler: "Surya (Sun) - Pure Leadership",
    positive: ["Visionary", "Self-Determined", "Active Organizer", "Pioneering"],
    growth: "Managing professional ego and pacing individual drive to match the team's velocity.",
    strategy: "Perfect for venture scaling, founding new operations, or setting high-level corporate direction. Aim for early market entry and absolute division of labor.",
    strategicAdvice: "Your natural baseline is independent sovereignty. When stepping into high-stakes environments, proactively mentor and sponsor others as a strategic advisor to turn followers into co-creators.",
    color: "text-amber-500 border-amber-500/30",
    bgGrad: "from-amber-500/10 to-transparent"
  },
  2: {
    name: "The High-Value Diplomat",
    ruler: "Chandra (Moon) - High Intuition",
    positive: ["Empathetic", "Harmonious", "Strategic Partner", "Detail-Oriented"],
    growth: "Over-analyzing decisions based on collective consensus or emotional noise.",
    strategy: "Thrives in dual-leadership setups, commercial partnerships, client advisory, and high-stakes negotiation where delicate harmony secures the margin.",
    strategicAdvice: "Do not mistake your natural desire for harmony as a limitation. Rely heavily on structured data checkpoints to anchor your intuitive strategic leaps.",
    color: "text-slate-300 border-slate-300/30",
    bgGrad: "from-slate-300/10 to-transparent"
  },
  3: {
    name: "The Scale Visionary",
    ruler: "Guru (Jupiter) - Wise Expansion",
    positive: ["Expansive", "Intellectual", "Natural Teacher", "Growth-Driver"],
    growth: "Avoiding over-commitment or attempting to tackle too many parallel strategic channels.",
    strategy: "Excels in global expansion plans, educational systems, professional consulting programs, and fundraising roadshows. Your presence breeds continuous trust.",
    strategicAdvice: "Your strength lies in conceptual architecture. Force yourself to establish operational playbooks and assign rigorous PMOs to guard your expansive ideas.",
    color: "text-yellow-400 border-yellow-400/30",
    bgGrad: "from-yellow-500/10 to-transparent"
  },
  4: {
    name: "The Systems Architect",
    ruler: "Rahu (Shadow Node) - Innovative Disruption",
    positive: ["Disruptive", "Highly Structured", "Analytical", "Out-of-the-box Checker"],
    growth: "Accepting conventional limits easily or getting caught in micro-operational rigidity.",
    strategy: "Critical for corporate turnaround situations, restructuring, rapid tech scale-up structures, and finding invisible growth leaks in existing PnL lines.",
    strategicAdvice: "You see patterns others overlook entirely. Frame your disruptive ideas as logical incremental improvements to avoid immediate organizational resistance.",
    color: "text-teal-400 border-teal-400/30",
    bgGrad: "from-teal-500/10 to-transparent"
  },
  5: {
    name: "The Velocity Merchant",
    ruler: "Budha (Mercury) - Rapid Communication",
    positive: ["Highly Adaptive", "Negotiation Master", "Agile", "Network Amplifier"],
    growth: "Focusing on quick transactional wins at the expense of multi-year enterprise relationship building.",
    strategy: "Ideal for fast-growth startups, rapid-go-to-market validation, sales pipeline restructuring, and building immediate media and marketing presence.",
    strategicAdvice: "Your cognitive processing is lightning-fast. In leadership, remember to decelerate and verify that your executive team has fully integrated the core strategy.",
    color: "text-emerald-400 border-emerald-400/30",
    bgGrad: "from-emerald-500/10 to-transparent"
  },
  6: {
    name: "The Brand Ambassador",
    ruler: "Shukra (Venus) - Aesthetic Harmony",
    positive: ["Consensus Builder", "Aesthetic Master", "Deep Relationship Manager", "Diplomatic"],
    growth: "Delaying difficult personnel separations or strategic terminations to maintain surface-level peace.",
    strategy: "Outstanding for high-end luxury marketing, elite human resources, cultural transformations of teams, and corporate narrative design.",
    strategicAdvice: "Your capacity to attract deep loyalty is a super-lever. Keep your business metrics highly objective to balance your affinity for human relations.",
    color: "text-pink-400 border-pink-400/30",
    bgGrad: "from-pink-500/10 to-transparent"
  },
  7: {
    name: "The Scientific Specialist",
    ruler: "Ketu (Shadow Node) - Deep Insight",
    positive: ["Metaphysical Logic", "Metaphorical Thinker", "Skeptic", "Intellectual Pioneer"],
    growth: "Isolating yourself from team execution pipelines or overthinking simple market opportunities.",
    strategy: "Masterful at complex R&D cycles, risk analysis, patent checking, deep technical diligence, and long-range system modeling.",
    strategicAdvice: "You harbor natural detachment. Ground your strategic conclusions by focusing heavily on immediate, quarterly cashflow impacts and client validation.",
    color: "text-purple-400 border-purple-400/30",
    bgGrad: "from-purple-500/10 to-transparent"
  },
  8: {
    name: "The Legacy Builder",
    ruler: "Shani (Saturn) - Institutional Structure",
    positive: ["Unshakeable", "Process-Governed", "Industrial Strategist", "Accountable"],
    growth: "Expecting identical extreme discipline or work-centric lifestyles from all organizational nodes.",
    strategy: "Perfect for asset consolidation, heavy operations, institutional real estate, high-volume supply chains, and setting long-range foundational structures.",
    strategicAdvice: "Saturn demands deep integrity and trial. Embrace the slow compounding of structured processes, and lead with deep, steady empathy rather than sheer dominance.",
    color: "text-indigo-400 border-indigo-400/30",
    bgGrad: "from-indigo-500/10 to-transparent"
  },
  9: {
    name: "The Crisis Commander",
    ruler: "Mangal (Mars) - High Execution Force",
    positive: ["Courageous", "Urgency Driver", "Direct Executor", "Crisis Manager"],
    growth: "Friction built through overly aggressive strategic posturing or direct confrontational style.",
    strategy: "Excellent for taking over stagnant operations, heading highly urgent projects under tight margins, and executing bold market expansions.",
    strategicAdvice: "Your operational engine runs on high-octane drive. Balance your natural force with tactical patience, giving your projects time to breath and settle.",
    color: "text-red-400 border-red-400/30",
    bgGrad: "from-red-500/10 to-transparent"
  }
};

// Direct reduction to single digit
function getSingleDigit(num: number): number {
  while (num > 9) {
    num = num.toString().split("").reduce((sum, d) => sum + parseInt(d, 10), 0);
  }
  return num;
}

export function CosmicTools() {
  const [activeTab, setActiveTab] = useState<"numerology" | "vastu">("numerology");

  // Numerology states
  const [nameInput, setNameInput] = useState("");
  const [dobInput, setDobInput] = useState("");
  const [numerologyResult, setNumerologyResult] = useState<{
    rulingNum: number;
    destinyNum: number;
    nameNum: number;
    harmonyScore: number;
    harmonyText: string;
    rulingDetails: typeof ARCHETYPES[1];
    destinyDetails: typeof ARCHETYPES[1];
    nameDetails: typeof ARCHETYPES[1];
  } | null>(null);

  // Vastu states
  const [vastuSetup, setVastuSetup] = useState({
    entrance: "East",
    ceoOffice: "Southwest",
    accounts: "North",
    servers: "Southeast"
  });
  const [vastuScore, setVastuScore] = useState<number | null>(null);
  const [vastuRemedies, setVastuRemedies] = useState<string[]>([]);
  const [vastuEvaluations, setVastuEvaluations] = useState<{zone: string; score: number; text: string}[]>([]);

  // Execute Numerology Blueprint
  const handleNumerologyCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dobInput || !nameInput) return;

    // 1. Calculate Ruling Number (Mulank) from life Day of birth
    // E.g. date: 1985-06-12 -> day is 12 -> 1 + 2 = 3
    const dobParts = dobInput.split("-");
    const day = parseInt(dobParts[2], 10);
    const rulingNum = getSingleDigit(day);

    // 2. Calculate Destiny Number (Bhagyank) from full date sum
    const fullDateSum = dobParts.join("").split("").reduce((sum, d) => sum + parseInt(d, 10), 0);
    const destinyNum = getSingleDigit(fullDateSum);

    // 3. Calculate Name Number (Namank) using Chaldean method
    const cleanedName = nameInput.toLowerCase().replace(/[^a-z]/g, "");
    let nameSum = 0;
    for (const char of cleanedName) {
      if (CHALDEAN_VALUES[char]) {
        nameSum += CHALDEAN_VALUES[char];
      }
    }
    const nameNum = nameSum > 0 ? getSingleDigit(nameSum) : 1;

    // 4. Calculate Name Harmony Score (Compatibility of Name-Number with Ruling and Destiny Numbers)
    // In numerology Name-Number is best if aligned with Ruling or Destiny, or friendly planet relationships
    let harmonyScore = 100;
    let harmonyText = "Optimally Balanced Resonance! Your physical name frequency acts as a perfect strategic accelerator for your natural born blueprint. Exceptional for personal visibility and corporate success.";

    const deltaRuling = Math.abs(nameNum - rulingNum);
    const deltaDestiny = Math.abs(nameNum - destinyNum);

    if (deltaRuling !== 0 && deltaDestiny !== 0) {
      if (deltaRuling > 3 && deltaDestiny > 3) {
        harmonyScore = 65;
        harmonyText = "Minor Frequency Friction Detected. Your name number points to different behavioral drives than your core date traits. A localized business name alignment adjustment or spelling refinement by Jitin could easily bridge this gap to reduce hidden operational friction.";
      } else {
        harmonyScore = 85;
        harmonyText = "Aequitas Harmony. Your name aligns smoothly with your cosmic identity. High level of integration, suitable for collaborative business dealings and strategic consulting roles.";
      }
    }

    setNumerologyResult({
      rulingNum,
      destinyNum,
      nameNum,
      harmonyScore,
      harmonyText,
      rulingDetails: ARCHETYPES[rulingNum] || ARCHETYPES[1],
      destinyDetails: ARCHETYPES[destinyNum] || ARCHETYPES[1],
      nameDetails: ARCHETYPES[nameNum] || ARCHETYPES[1],
    });

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.8 },
      colors: ["#FF9933", "#FFB066", "#FFD700", "#FFF5EB"]
    });
  };

  // Run Vastu Audit & Remedial Analysis
  const handleVastuAudit = () => {
    let score = 0;
    const items: {zone: string; score: number; text: string}[] = [];
    const remedies: string[] = [];

    // Evaluate Entrance
    if (["North", "East", "Northeast"].includes(vastuSetup.entrance)) {
      score += 25;
      items.push({ zone: "Primary Entrance Direction", score: 100, text: "Excellent! Invites pristine solar magnetic currents and career opportunities directly into your venture space." });
    } else if (["Northwest", "West"].includes(vastuSetup.entrance)) {
      score += 15;
      items.push({ zone: "Primary Entrance Direction", score: 60, text: "Moderate. Governed by wind element. Can result in fast staff turnover or volatile sales pipelines." });
      remedies.push("Install a heavy brass door-sill protector and ensure entrance is illuminated with soft white or silver-colored lighting representing the moon element.");
    } else {
      score += 5;
      items.push({ zone: "Primary Entrance Direction", score: 20, text: "Vulnerable Alignment. Entrance in South/Southwest allows energetic leaks, creating persistent financial blocks." });
      remedies.push("Hang a heavy lead or Vastu metallic strip on the inner frame of the main entrance door to anchor and filter arriving energy flow.");
    }

    // Evaluate CEO / Leadership Desk seating
    if (vastuSetup.ceoOffice === "Southwest") {
      score += 25;
      items.push({ zone: "CEO & Leadership Desk Location", score: 100, text: "Impeccable! Southwest quadrant is governed by the Earth element, establishing absolute leadership weight, authority, and decisive clarity." });
    } else if (["South", "West"].includes(vastuSetup.ceoOffice)) {
      score += 18;
      items.push({ zone: "CEO & Leadership Desk Location", score: 70, text: "Strong positioning, but susceptible to extreme corporate pressure or sudden exhaustion of resources." });
      remedies.push("Ensure the CEO's chair sits directly higher than visitor seats, backed by a solid wall with zero open windows behind of them.");
    } else {
      score += 8;
      items.push({ zone: "CEO & Leadership Desk Location", score: 30, text: "Highly Destabilized. Seating in Northeast or North causes severe focus dilution, making the leader too emotional or scattered." });
      remedies.push("Place a natural lead-weighted crystal paperweight or solid brass sphere on the southwest corner of the current desk to anchor authority temporarily.");
    }

    // Evaluate Accounts & Cash flow zone
    if (["North", "Northeast"].includes(vastuSetup.accounts)) {
      score += 25;
      items.push({ zone: "Financial Ledger & Safe Placement", score: 100, text: "Perfect placement! Governed by Kubera (Wealth). Directs consistent cash liquid asset flow and client retention." });
    } else if (["East", "Northwest"].includes(vastuSetup.accounts)) {
      score += 15;
      items.push({ zone: "Financial Ledger & Safe Placement", score: 60, text: "Average alignment. Cash flow remains highly fluid but experiences heavy, unexpected capital expenditure cycles." });
      remedies.push("Place a micro green plant in an elegant, solid metal vase near the financial server drawer to trigger continuous growth.");
    } else {
      score += 5;
      items.push({ zone: "Financial Ledger & Safe Placement", score: 20, text: "Leak Zone. Financial data in Southwest or Southeast burns cash pools quickly on overheads or penalty charges." });
      remedies.push("Shift all digital financial folders and secondary master books strictly to high cabinets facing East, and avoid storing empty boxes in this zone.");
    }

    // Evaluate Servers & Operational fire element
    if (vastuSetup.servers === "Southeast") {
      score += 25;
      items.push({ zone: "Operations, Servers & Fire Element", score: 100, text: "Flawless. Southeast is Agni (Fire). Elevates technology uptime, data processing speed, and marketing drive." });
    } else if (["East", "Northwest"].includes(vastuSetup.servers)) {
      score += 15;
      items.push({ zone: "Operations, Servers & Fire Element", score: 60, text: "Balanced. Moderate tech operational friction. Team might face communication delays." });
      remedies.push("Embed a minor copper Vastu plate behind the server rack to ground dynamic electrical power cycles beautifully.");
    } else {
      score += 5;
      items.push({ zone: "Operations, Servers & Fire Element", score: 20, text: "Severe Elemental Drag. Fire energy placed in Northeast or Southwest dampens either corporate luck or core authority." });
      remedies.push("Cover Southwest server setups in solid wood frame panels or introduce steady, warm yellow down-lighting around their immediate vicinity.");
    }

    setVastuScore(score);
    setVastuEvaluations(items);
    setVastuRemedies(remedies);

    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0 },
      colors: ["#eab308", "#ca8a04", "#27272a"]
    });
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1 },
      colors: ["#eab308", "#ca8a04", "#27272a"]
    });
  };

  return (
    <section id="interactive-tools" className="py-14 relative overflow-hidden bg-page-bg-900 border-t border-b border-gold-500/10">
      {/* Immersive Cosmic Background Image */}
      <div className="absolute inset-0 z-0 opacity-15 pointer-events-none select-none">
        <img 
          src={cosmicToolsBg} 
          alt="" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          loading="lazy"
        />
        {/* Radial vignette fade overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-brand-950 via-transparent to-brand-950 opacity-90"></div>
        <div className="absolute inset-0 bg-brand-950/40"></div>
      </div>
      <div className="absolute inset-0 bg-radial-gradient from-gold-500/5 via-transparent to-transparent opacity-40 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center max-w-5xl mx-auto mb-16 px-4">
          <div className="lg:col-span-7 text-center lg:text-left bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-8 py-8 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm h-full flex flex-col justify-center">
            <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
              Free Tools
            </h2>
            <h3 className="section-title text-3xl md:text-4xl lg:text-5xl font-serif font-semibold tracking-tight mb-6">
              Astrology &amp; <span className="bg-gradient-to-r from-gold-400 via-gold-500 to-gold-600 bg-clip-text text-transparent block sm:inline lg:block">Numerology Calculators</span>
            </h3>
            <p className="text-sm sm:text-base text-text-main/90 font-sans leading-relaxed">
              Quick calculators for numerology, Vastu, and cosmic timing — practical tools to guide your next decision.
            </p>
            <p className="text-xs text-gold-400/70 italic font-sans leading-relaxed mt-3 max-w-xl">
              Vedic insight does not replace practical strategy — it adds a timing and pattern perspective to the decision-making process.
            </p>
          </div>
          
          <div className="lg:col-span-5 relative group">
            {/* Glowing Aura backdrops */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-gold-600 to-[#8B3005] rounded-2xl blur opacity-30 group-hover:opacity-50 transition duration-1000 group-hover:duration-205"></div>
            <div className="relative bg-brand-950 border border-gold-500/30 p-2 rounded-2xl shadow-2xl shadow-black/90 overflow-hidden">
              <motion.div 
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="relative overflow-hidden rounded-xl aspect-[4/3] w-full"
              >
                <img 
                  src={cosmicBanner} 
                  alt="Vedic astrology and numerology calculator tools" 
                  className="object-cover w-full h-full transform scale-102 hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#4D1A03] via-transparent to-transparent opacity-80"></div>
                {/* Floating details to emphasize authentic sacred calculations */}
                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center bg-brand-950/80 backdrop-blur-md px-3 py-2 rounded border border-gold-500/20">
                  <span className="text-[10px] font-mono text-gold-400 uppercase tracking-widest font-black">Vedic Calculators</span>
                  <span className="text-[9px] font-mono text-text-main/70 uppercase">Free to Use</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex justify-center mb-12">
          <div className="bg-brand-800/40 backdrop-blur-md p-1.5 rounded-xl border border-gold-500/20 shadow-xl inline-flex gap-2">
            <button
              onClick={() => setActiveTab("numerology")}
              className={`flex items-center gap-2.5 px-4 sm:px-6 py-2.5 rounded-lg text-sm font-medium transition-all focus:outline-none ${
                activeTab === "numerology"
                  ? "bg-gold-500 text-brand-900 shadow-lg font-semibold"
                  : "text-text-main/70 hover:text-text-main hover:bg-gold-500/10"
              }`}
            >
              <Calendar className="w-4 h-4" />
              Vedic Numerology & Harmony
            </button>
            <button
              onClick={() => setActiveTab("vastu")}
              className={`flex items-center gap-2.5 px-4 sm:px-6 py-2.5 rounded-lg text-sm font-medium transition-all focus:outline-none ${
                activeTab === "vastu"
                  ? "bg-gold-500 text-brand-900 shadow-lg font-semibold"
                  : "text-text-main/70 hover:text-text-main hover:bg-gold-500/10"
              }`}
            >
              <Compass className="w-4 h-4" />
              Scientific Vastu Audit
            </button>
          </div>
        </div>

        {/* Tab Panels */}
        <div className="max-w-5xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === "numerology" ? (
              <motion.div
                key="numerology-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center opacity-[0.04] pointer-events-none z-0"
                  style={{ backgroundImage: `url(${numerologyCrystalsImg})` }}
                ></div>
                {/* Inputs Card */}
                <div className="lg:col-span-5 bg-brand-800/20 backdrop-blur-md p-6 sm:p-8 rounded-3xl border border-gold-500/10 shadow-2xl space-y-6">
                  <div className="flex items-center gap-3 border-b border-gold-500/10 pb-4">
                    <div className="p-2 rounded-lg bg-gold-500/10 text-gold-500">
                      <Settings className="w-5 h-5 animate-spin-slow" />
                    </div>
                    <div>
                      <h3 className="font-serif font-semibold text-lg text-text-main">Your Details</h3>
                      <p className="text-xs text-text-main/50">Enter your birth details to see your natural strengths — no generic horoscope talk</p>
                    </div>
                  </div>

                  <form onSubmit={handleNumerologyCalculate} className="space-y-5">
                    <div className="space-y-2">
                      <label htmlFor="numerology-name-input" className="block text-xs font-semibold text-gold-400 uppercase tracking-widest flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5" />
                        Full Legal Name
                      </label>
                      <input
                        id="numerology-name-input"
                        type="text"
                        required
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        placeholder="e.g., Jitin Goel"
                        autoComplete="name"
                        className="w-full px-4 py-3 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main placeholder-text-main/30 text-sm focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500/30 transition-all"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="numerology-dob-input" className="block text-xs font-semibold text-gold-400 uppercase tracking-widest flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" />
                        Date of Birth
                      </label>
                      <input
                        id="numerology-dob-input"
                        type="date"
                        required
                        value={dobInput}
                        onChange={(e) => setDobInput(e.target.value)}
                        autoComplete="bday"
                        className="w-full px-4 py-3 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main placeholder-text-main/30 text-sm focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500/30 transition-all [color-scheme:dark]"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-brand-900 font-semibold text-sm transition-all shadow-lg hover:shadow-gold-500/10 hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" />
                      Get My Free Insights
                    </button>
                  </form>
                </div>

                {/* Outputs Panel */}
                <div className="lg:col-span-7">
                  <AnimatePresence mode="wait">
                    {numerologyResult ? (
                      <motion.div
                        key="results"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        className="space-y-6"
                      >
                        {/* Summary Meters Row */}
                        <div className="grid grid-cols-3 gap-3">
                          {/* Ruling */}
                          <div className="bg-brand-800/40 p-4 rounded-2xl border border-gold-500/15 text-center flex flex-col justify-between h-36">
                            <span className="text-[10px] text-text-main/50 uppercase tracking-widest font-semibold">Ruling (Mulank)</span>
                            <div className="text-4xl font-serif font-bold text-gold-500 my-1">{numerologyResult.rulingNum}</div>
                            <span className="text-xs font-medium text-text-main/80 truncate px-1">{numerologyResult.rulingDetails.ruler.split(" - ")[0]}</span>
                          </div>
                          
                          {/* Destiny */}
                          <div className="bg-brand-800/40 p-4 rounded-2xl border border-gold-500/15 text-center flex flex-col justify-between h-36">
                            <span className="text-[10px] text-text-main/50 uppercase tracking-widest font-semibold">Destiny (Bhagyank)</span>
                            <div className="text-4xl font-serif font-bold text-gold-500 my-1">{numerologyResult.destinyNum}</div>
                            <span className="text-xs font-medium text-text-main/80 truncate px-1">{numerologyResult.destinyDetails.ruler.split(" - ")[0]}</span>
                          </div>

                          {/* Name */}
                          <div className="bg-brand-800/40 p-4 rounded-2xl border border-gold-500/15 text-center flex flex-col justify-between h-36">
                            <span className="text-[10px] text-text-main/50 uppercase tracking-widest font-semibold">Name (Namank)</span>
                            <div className="text-4xl font-serif font-bold text-gold-500 my-1">{numerologyResult.nameNum}</div>
                            <span className="text-xs font-medium text-text-main/80 truncate px-1">{numerologyResult.nameDetails.ruler.split(" - ")[0]}</span>
                          </div>
                        </div>

                        {/* Name Harmony Bar */}
                        <div className="bg-brand-800/20 backdrop-blur-md p-5 rounded-2xl border border-gold-500/15 space-y-3">
                          <div className="flex justify-between items-center">
                            <h4 className="text-sm font-semibold uppercase tracking-wider text-gold-400 flex items-center gap-1.5">
                              <ShieldCheck className="w-4 h-4 text-emerald-400" />
                              Name Harmony Score: {numerologyResult.harmonyScore}%
                            </h4>
                          </div>
                          <div className="w-full bg-brand-950/80 rounded-full h-2.5 overflow-hidden border border-white/5">
                            <motion.div 
                              className="bg-gradient-to-r from-red-500 via-yellow-500 to-emerald-400 h-2.5 rounded-full"
                              initial={{ width: 0 }}
                              animate={{ width: `${numerologyResult.harmonyScore}%` }}
                              transition={{ duration: 0.8, ease: "easeOut" }}
                            />
                          </div>
                          <p className="text-xs text-text-main/70 leading-relaxed font-sans mt-2 italic">
                            &ldquo;{numerologyResult.harmonyText}&rdquo;
                          </p>
                        </div>

                        {/* Complete Profiles */}
                        <div className="bg-brand-800/20 backdrop-blur-md p-6 rounded-3xl border border-gold-500/15 space-y-6">
                          {/* Ruling Character */}
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <span className="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase tracking-widest font-semibold">Your Essence</span>
                              <h4 className="text-lg font-serif font-semibold text-text-main">{numerologyResult.rulingDetails.name}</h4>
                            </div>
                            <p className="text-xs text-text-main/60 mb-2">Governing Planet: <strong className="text-gold-400">{numerologyResult.rulingDetails.ruler}</strong></p>
                            <div className="flex flex-wrap gap-1.5 mb-3">
                              {numerologyResult.rulingDetails.positive.map((tag, idx) => (
                                <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-gold-500/5 text-gold-400 border border-gold-500/10">{tag}</span>
                              ))}
                            </div>
                            <p className="text-sm text-text-main/80 font-sans leading-relaxed">{numerologyResult.rulingDetails.strategicAdvice}</p>
                          </div>

                          <div className="border-t border-gold-500/10 pt-5">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-widest font-semibold">Business Leverage</span>
                              <h4 className="text-lg font-serif font-semibold text-text-main">{numerologyResult.destinyDetails.name}</h4>
                            </div>
                            <p className="text-sm text-text-main/80 font-sans leading-relaxed">{numerologyResult.destinyDetails.strategy}</p>
                          </div>

                          <div className="border-t border-gold-500/10 pt-5 space-y-2">
                            <h5 className="text-xs uppercase tracking-widest text-gold-400 font-semibold">Executive Growth Impediment</h5>
                            <p className="text-xs text-text-main/70 italic leading-relaxed">
                              Focus Area: {numerologyResult.rulingDetails.growth}
                            </p>
                          </div>

                          {/* CTA Prompt */}
                          <div className="bg-gold-500/10 p-4 rounded-xl border border-gold-500/20 text-center font-sans space-y-2">
                            <p className="text-xs text-text-main/90 font-medium">
                              Want Jitin to analyze your full, comprehensive Vedic Chart and matching Name/Prasthara grids?
                            </p>
                            <a 
                              href="#book"
                              className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-400 hover:text-gold-500 hover:underline transition-all"
                            >
                              Secure Your Custom Metaphysical Consulting Map <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="h-full min-h-[350px] bg-brand-800/10 backdrop-blur-md rounded-3xl border border-gold-500/5 flex flex-col justify-center items-center text-center p-8 space-y-4">
                        <div className="p-4 rounded-full bg-gold-500/5 text-gold-500 border border-gold-500/10">
                          <Activity className="w-8 h-8 animate-pulse" />
                        </div>
                        <h4 className="font-serif font-medium text-lg text-text-main">Your Results Will Appear Here</h4>
                        <p className="text-sm text-text-main/55 max-w-sm">
                          Fill in your details on the left to instantly see your natural professional strengths.
                        </p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="vastu-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center opacity-[0.04] pointer-events-none z-0"
                  style={{ backgroundImage: `url(${vastuBlueprintImg})` }}
                ></div>
                {/* Vastu Parameters Checklist */}
                <div className="lg:col-span-5 bg-brand-800/20 backdrop-blur-md p-6 sm:p-8 rounded-3xl border border-gold-500/10 shadow-2xl space-y-6">
                  <div className="flex items-center gap-3 border-b border-gold-500/10 pb-4">
                    <div className="p-2 rounded-lg bg-gold-500/10 text-gold-500">
                      <Compass className="w-5 h-5 animate-spin-slow" />
                    </div>
                    <div>
                      <h3 className="font-serif font-semibold text-lg text-text-main">Corporate Vastu Plan</h3>
                      <p className="text-xs text-text-main/50">Identify layout cardinal placements</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {/* Entrance */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-gold-400 uppercase tracking-wider">Main Workspace Entrance</label>
                      <select
                        value={vastuSetup.entrance}
                        onChange={(e) => setVastuSetup({...vastuSetup, entrance: e.target.value})}
                        className="w-full px-3 py-2 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main text-sm focus:outline-none focus:border-gold-500 cursor-pointer"
                      >
                        <option value="North" className="bg-brand-900">North (Wealth/Fluidity)</option>
                        <option value="East" className="bg-brand-900">East (Solar Growth/Connections)</option>
                        <option value="Northeast" className="bg-brand-900">Northeast (Water element)</option>
                        <option value="South" className="bg-brand-900">South (Reputation/Load)</option>
                        <option value="Southeast" className="bg-brand-900">Southeast (Fire Element)</option>
                        <option value="Southwest" className="bg-brand-900">Southwest (Earth Element)</option>
                        <option value="West" className="bg-brand-900">West (Gains Element)</option>
                        <option value="Northwest" className="bg-brand-900">Northwest (Wind/Flows)</option>
                      </select>
                    </div>

                    {/* CEO seating */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-gold-400 uppercase tracking-wider">CEO Desk Seating Quadrant</label>
                      <select
                        value={vastuSetup.ceoOffice}
                        onChange={(e) => setVastuSetup({...vastuSetup, ceoOffice: e.target.value})}
                        className="w-full px-3 py-2 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main text-sm focus:outline-none focus:border-gold-500 cursor-pointer"
                      >
                        <option value="Southwest" className="bg-brand-900 font-sans">Southwest (Earth - Perfect Command)</option>
                        <option value="South" className="bg-brand-900">South (Dynamic Focus)</option>
                        <option value="West" className="bg-brand-900">West (Execution Gains)</option>
                        <option value="North" className="bg-brand-900">North (Unstable Command)</option>
                        <option value="Northeast" className="bg-brand-900">Northeast (Scattered/Deep Thought)</option>
                        <option value="East" className="bg-brand-900">East (Moderate Outreach)</option>
                        <option value="Southeast" className="bg-brand-900">Southeast (Too Aggressive)</option>
                        <option value="Northwest" className="bg-brand-900">Northwest (Highly Active/Travel)</option>
                      </select>
                    </div>

                    {/* Financial Ledger */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-gold-400 uppercase tracking-wider">Financial Safe & Accounting Files</label>
                      <select
                        value={vastuSetup.accounts}
                        onChange={(e) => setVastuSetup({...vastuSetup, accounts: e.target.value})}
                        className="w-full px-3 py-2 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main text-sm focus:outline-none focus:border-gold-500 cursor-pointer"
                      >
                        <option value="North" className="bg-brand-900">North (Pure Kubera Capital Flow)</option>
                        <option value="Northeast" className="bg-brand-900">Northeast (Clean Growth)</option>
                        <option value="East" className="bg-brand-900">East (Stable Gains)</option>
                        <option value="Southeast" className="bg-brand-900">Southeast (Cash Burns/Friction)</option>
                        <option value="Southwest" className="bg-brand-900">Southwest (Accumulation delays)</option>
                        <option value="West" className="bg-brand-900">West (Moderate Balance)</option>
                        <option value="Northwest" className="bg-brand-900">Northwest (Fluctuating Accounts)</option>
                      </select>
                    </div>

                    {/* Server rooms */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-gold-400 uppercase tracking-wider">Operations, Tech Servers & Pantry</label>
                      <select
                        value={vastuSetup.servers}
                        onChange={(e) => setVastuSetup({...vastuSetup, servers: e.target.value})}
                        className="w-full px-3 py-2 bg-brand-900/50 rounded-xl border border-gold-500/20 text-text-main text-sm focus:outline-none focus:border-gold-500 cursor-pointer"
                      >
                        <option value="Southeast" className="bg-brand-900">Southeast (Agni/Fire Element - Flawless)</option>
                        <option value="East" className="bg-brand-900">East (Stable Operations)</option>
                        <option value="Northwest" className="bg-brand-900">Northwest (Agile Tech Exchanges)</option>
                        <option value="West" className="bg-brand-900">West (Ordinary Processing)</option>
                        <option value="Northeast" className="bg-brand-900">Northeast (Clashes water/fire)</option>
                        <option value="Southwest" className="bg-brand-900">Southwest (Saps Leadership Strength)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    onClick={handleVastuAudit}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-brand-900 font-semibold text-sm transition-all shadow-lg hover:shadow-gold-500/10 hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <Compass className="w-4 h-4 animate-spin-slow" />
                    Determine Energy Integrity Score
                  </button>
                </div>

                {/* Vastu Audit Report */}
                <div className="lg:col-span-7">
                  <AnimatePresence mode="wait">
                    {vastuScore !== null ? (
                      <motion.div
                        key="vastu-report"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        className="space-y-6"
                      >
                        {/* Master Score Dial */}
                        <div className="bg-brand-800/40 p-6 rounded-2xl border border-gold-500/15 flex flex-col sm:flex-row items-center gap-6">
                          <div className="relative flex items-center justify-center flex-shrink-0">
                            {/* Simple beautiful SVG concentric circle gauge */}
                            <svg className="w-28 h-28 transform -rotate-90">
                              <circle cx="56" cy="56" r="48" strokeWidth="6" stroke="rgba(255, 153, 51, 0.05)" fill="transparent" />
                              <motion.circle 
                                cx="56" 
                                cy="56" 
                                r="48" 
                                strokeWidth="8" 
                                stroke={vastuScore > 75 ? "#10b981" : vastuScore > 45 ? "#eab308" : "#f43f5e"} 
                                fill="transparent" 
                                strokeDasharray={2 * Math.PI * 48}
                                initial={{ strokeDashoffset: 2 * Math.PI * 48 }}
                                animate={{ strokeDashoffset: 2 * Math.PI * 48 * (1 - vastuScore / 100) }}
                                transition={{ duration: 1, ease: "easeOut" }}
                                strokeLinecap="round"
                              />
                            </svg>
                            <span className="absolute text-2xl font-serif font-bold text-text-main">{vastuScore}%</span>
                          </div>
                          <div className="space-y-2 text-center sm:text-left">
                            <span className="text-[10px] text-text-main/50 uppercase tracking-widest font-semibold px-2 py-0.5 rounded bg-white/5 border border-white/5">Energy Index</span>
                            <h4 className="text-xl font-serif font-semibold text-text-main">
                              {vastuScore > 75 ? "Highly Harmonized Structure" : vastuScore > 45 ? "Compromised Spatial Integrity" : "Heavy Elemental Structural Clashing"}
                            </h4>
                            <p className="text-xs text-text-main/70 leading-relaxed font-sans">
                              {vastuScore > 75 
                                ? "Your layout channels natural magnetic, solar, and gravity forces seamlessly to support administrative authority and expansion."
                                : "Minor directional and elemental frictions are dampening the mental capacity of executives and bleeding liquidity. Implementing corrections is advised."}
                            </p>
                          </div>
                        </div>

                        {/* Zone Breakdown */}
                        <div className="bg-brand-800/20 backdrop-blur-md p-6 rounded-3xl border border-gold-500/15 space-y-4">
                          <h4 className="text-sm font-semibold uppercase tracking-wider text-gold-400 flex items-center gap-2 pb-3 border-b border-white/5">
                            <Activity className="w-4 h-4 text-gold-400" />
                            Directional Soundness Breakdown
                          </h4>
                          
                          <div className="space-y-4">
                            {vastuEvaluations.map((val, idx) => (
                              <div key={idx} className="space-y-1">
                                <div className="flex justify-between items-center text-xs">
                                  <span className="font-medium text-text-main/90">{val.zone}</span>
                                  <span className={`font-semibold ${val.score === 100 ? "text-emerald-400" : val.score >= 60 ? "text-yellow-400" : "text-red-400"}`}>{val.score === 100 ? "Optimal" : val.score >= 60 ? "Partial" : "Critical Friction"}</span>
                                </div>
                                <div className="w-full bg-brand-950/40 rounded-full h-1.5 overflow-hidden">
                                  <div 
                                    className={`h-1.5 rounded-full ${val.score === 100 ? "bg-emerald-400" : val.score >= 60 ? "bg-yellow-400" : "bg-red-500"}`}
                                    style={{ width: `${val.score}%` }}
                                  />
                                </div>
                                <p className="text-[11px] text-text-main/60 italic leading-relaxed">{val.text}</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Remedies Card */}
                        {vastuRemedies.length > 0 && (
                          <div className="bg-red-950/20 backdrop-blur-md p-6 rounded-3xl border border-red-500/20 space-y-3">
                            <h4 className="text-sm font-semibold uppercase tracking-wider text-red-400 flex items-center gap-2">
                              <AlertCircle className="w-4 h-4 text-red-400" />
                              Immediate Micro-Remedies and Corrections Needed
                            </h4>
                            <p className="text-xs text-text-main/60">
                              Implement these energetic adjustments to bypass structural constraints without doing complex physical demolitions:
                            </p>
                            <ul className="space-y-2.5 pt-2">
                              {vastuRemedies.map((rem, idx) => (
                                <li key={idx} className="flex gap-2.5 items-start text-xs text-text-main/80 font-sans">
                                  <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                                  <span>{rem}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* CTA Prompt */}
                        <div className="bg-gold-500/10 p-5 rounded-2xl border border-gold-500/20 text-center font-sans space-y-3">
                          <p className="text-xs text-text-main/90 font-medium leading-relaxed">
                            A workspace acts as a physical three-dimensional manifestation of your destiny chart. Jitin Goel provides premium, bespoke layouts and scientific corrections to completely align premises with operational target goals.
                          </p>
                          <a 
                            href="#book"
                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-400 hover:text-gold-500 hover:underline transition-all"
                          >
                            Schedule a Scientific Vastu Audit for Your Premises <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="h-full min-h-[350px] bg-brand-800/10 backdrop-blur-md rounded-3xl border border-gold-500/5 flex flex-col justify-center items-center text-center p-8 space-y-4">
                        <div className="p-4 rounded-full bg-gold-500/5 text-gold-500 border border-gold-500/10">
                          <Compass className="w-8 h-8 animate-pulse" />
                        </div>
                        <h4 className="font-serif font-medium text-lg text-text-main">Your Results Will Appear Here</h4>
                        <p className="text-sm text-text-main/55 max-w-sm">
                          Set the directions of your workspace on the left, then check your score.
                        </p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
