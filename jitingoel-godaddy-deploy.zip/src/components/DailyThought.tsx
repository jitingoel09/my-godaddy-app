import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, X, Clock, MessageCircle, Linkedin } from "lucide-react";
import { LazyImage } from "./LazyImage";
import moonImg from "../assets/images/moon_vedic_wisdom.webp";
import dailyTimingHeaderImg from "../assets/images/daily_timing_header.webp";

import suryaImg from "../assets/images/surya_dev_1780747735205.webp";
import shivaImg from "../assets/images/lord_shiva_1780747749589.webp";
import hanumanImg from "../assets/images/lord_hanuman_devotion_1783329128754.webp";
import ganeshaImg from "../assets/images/lord_ganesha_1780747781641.webp";
import vishnuImg from "../assets/images/lord_vishnu_1780747797084.webp";
import lakshmiImg from "../assets/images/goddess_lakshmi_1780747813869.webp";
import shaniImg from "../assets/images/lord_shani_1780747828507.webp";

const thoughts = [
  {
    day: "Sunday",
    planet: "Surya (Sun) - Surya Dev",
    image: suryaImg,
    text: "The Sun illuminates leadership. Step into your authentic power today. Lead your life and business with unwavering clarity, purpose, and visibility.",
    color: "text-orange-500",
    bg: "bg-orange-500/10",
  },
  {
    day: "Monday",
    planet: "Chandra (Moon) - Lord Shiva",
    image: shivaImg,
    text: "The Moon reflects our inner shifts. Honor your intuition in decision-making today. Emotional intelligence is your greatest asset in high-stakes environments.",
    color: "text-slate-300",
    bg: "bg-slate-300/10",
  },
  {
    day: "Tuesday",
    planet: "Mangal (Mars) - Lord Hanuman",
    image: hanumanImg,
    text: "Mars commands courage and execution. Break inertia. Channel your drive into bold, decisive actions that propel your career or business forward.",
    color: "text-orange-600",
    bg: "bg-orange-600/10",
  },
  {
    day: "Wednesday",
    planet: "Budha (Mercury) - Lord Ganesha",
    image: ganeshaImg,
    text: "Mercury governs intellect and exchange. Optimize your communication flow. Clear, strategic dialogue builds the strongest professional networks.",
    color: "text-green-500",
    bg: "bg-green-500/10",
  },
  {
    day: "Thursday",
    planet: "Guru (Jupiter) - Lord Vishnu",
    image: vishnuImg,
    text: "Jupiter expands wisdom and scale. Look at the bigger picture today. Abundance follows when you align your corporate goals with continuous learning and ethics.",
    color: "text-yellow-500",
    bg: "bg-yellow-500/10",
  },
  {
    day: "Friday",
    planet: "Shukra (Venus) - Goddess Lakshmi",
    image: lakshmiImg,
    text: "Venus brings harmony and attraction. Evaluate the aesthetics of your brand and the diplomacy in your partnerships. True success always feels aligned.",
    color: "text-gold-400",
    bg: "bg-gold-400/10",
  },
  {
    day: "Saturday",
    planet: "Shani (Saturn) - Lord Shani Dev",
    image: shaniImg,
    text: "Saturn demands structure and patience. Real legacy takes time to build. Trust the process, refine your operations, and stay steadfast in your commitments.",
    color: "text-gold-400",
    bg: "bg-gold-400/10",
  },
];

export function DailyThought() {
  const [currentDay, setCurrentDay] = useState(() => {
    const cachedDay = localStorage.getItem('dailyThoughtCurrentDay');
    if (cachedDay !== null) {
      const parsedDay = parseInt(cachedDay, 10);
      if (parsedDay === new Date().getDay()) {
         return parsedDay;
      }
    }
    return new Date().getDay();
  });
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('dailyThoughtCurrentDay', currentDay.toString());
  }, [currentDay]);

  useEffect(() => {
    // Preload images into browser cache to reduce redundant network requests on navigation
    thoughts.forEach(thought => {
      const img = new Image();
      img.src = thought.image;
    });
    
    // Cache the thought texts in localStorage as a fallback/strategy
    const cachedThoughts = localStorage.getItem('dailyThoughtsData');
    if (!cachedThoughts) {
      localStorage.setItem('dailyThoughtsData', JSON.stringify(
        thoughts.map(t => ({ day: t.day, text: t.text, planet: t.planet }))
      ));
    }
  }, []);

  // Allow users to see other days by clicking
  const todayThought = thoughts[currentDay];

  // Organize past thoughts starting from yesterday backwards for the last 7 days
  const pastThoughts = [];
  const today = new Date().getDay();
  for (let i = 1; i <= 6; i++) {
    const idx = (today - i + 7) % 7;
    pastThoughts.push(thoughts[idx]);
  }
  // Let's add today at the end just so all 7 are available if we want
  pastThoughts.push(thoughts[today]);

  return (
    <section className="py-14 px-6 sm:px-12 bg-page-bg-900 border-t border-gold-500/10 relative overflow-hidden">
      {/* Cosmic star-field texture */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjUpIi8+CjxjaXJjbGUgY3g9IjcwIiBjeT0iMTUiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIxMTAiIGN5PSI1NSIgcj0iMS4yIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNCkiLz4KPGNpcmNsZSBjeD0iMTUwIiBjeT0iMjAiIHI9IjAuNiIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjE4MCIgY3k9IjcwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNDUpIi8+CjxjaXJjbGUgY3g9IjQwIiBjeT0iOTAiIHI9IjAuOCIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjkwIiBjeT0iMTEwIiByPSIxLjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8Y2lyY2xlIGN4PSIxNDAiIGN5PSIxMzAiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIyMCIgY3k9IjE1MCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjQpIi8+CjxjaXJjbGUgY3g9IjE3MCIgY3k9IjE2MCIgcj0iMC45IiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuMzUpIi8+CjxjaXJjbGUgY3g9IjYwIiBjeT0iMTgwIiByPSIwLjYiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC4zKSIvPgo8Y2lyY2xlIGN4PSIxMjAiIGN5PSIxODUiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8L3N2Zz4=')] opacity-60 pointer-events-none"></div>
      {/* Background Elements */}
      <div
        className="vedic-wisdom-panel-img absolute inset-0 opacity-[0.10] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${moonImg})` }}
      ></div>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gold-500/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-10 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm"
        >
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
            Cosmic Guidance
          </h2>
          <h3 className="text-3xl md:text-4xl font-serif text-gold-400 flex items-center justify-center gap-3 font-bold">
            <Sparkles className="w-5 h-5 text-gold-500" />
            Daily Vedic Wisdom
            <Sparkles className="w-5 h-5 text-gold-500" />
          </h3>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-brand-800 border border-gold-500/20 p-8 md:p-12 rounded-2xl relative overflow-hidden"
        >
          {/* Decorative Corner Elements */}
          <div className="absolute top-0 left-0 w-16 h-16 border-t border-l border-gold-500/30 rounded-tl-2xl"></div>
          <div className="absolute bottom-0 right-0 w-16 h-16 border-b border-r border-gold-500/30 rounded-br-2xl"></div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentDay}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col items-center min-h-[200px]"
            >
              <div
                className={`w-28 h-28 md:w-32 md:h-32 rounded-full overflow-hidden flex items-center justify-center mb-6 border-2 border-gold-500/50 shadow-[0_0_20px_rgba(197,160,89,0.3)] bg-brand-950`}
              >
                <LazyImage
                  src={todayThought.image}
                  alt={todayThought.planet}
                  className="w-full h-full object-cover scale-110"
                  containerClassName="w-full h-full"
                />
              </div>

              <h3 className="text-xl md:text-2xl font-serif text-gold-500 mb-2 font-bold">
                {todayThought.day}'s Energy
              </h3>
              <p className="text-xs uppercase tracking-[0.2em] text-text-main mb-8 pb-4 border-b border-gold-500/20 max-w-sm mx-auto px-4">
                {todayThought.planet}
              </p>

              <blockquote className="text-lg md:text-xl text-text-main italic leading-relaxed max-w-2xl mx-auto font-serif">
                "{todayThought.text}"
              </blockquote>

              <div className="flex items-center gap-3 mt-6">
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(`"${todayThought.text}" — Jitin Goel Consulting\n\nhttps://jitingoel.com`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share this wisdom on WhatsApp"
                  className="w-9 h-9 rounded-full bg-brand-950/50 border border-gold-500/20 flex items-center justify-center text-gold-400 hover:bg-[#25D366]/20 hover:border-[#25D366]/40 hover:text-[#25D366] transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
                <a
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent("https://jitingoel.com")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share this wisdom on LinkedIn"
                  className="w-9 h-9 rounded-full bg-brand-950/50 border border-gold-500/20 flex items-center justify-center text-gold-400 hover:bg-[#0A66C2]/20 hover:border-[#0A66C2]/40 hover:text-[#0A66C2] transition-all"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          </AnimatePresence>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-wrap justify-center gap-2 mt-8"
        >
          {thoughts.map((t, i) => (
            <button
              key={i}
              onClick={() => setCurrentDay(i)}
              className={`text-[10px] uppercase tracking-wider px-3 py-1.5 rounded transition-all ${
                currentDay === i 
                  ? 'bg-gold-500 text-brand-900 font-bold' 
                  : 'text-text-main hover:text-gold-500 border border-gold-500/20 hover:border-gold-500/50'
              }`}
            >
              {t.day.slice(0, 3)}
            </button>
          ))}
        </motion.div>

        <motion.div
           initial={{ opacity: 0 }}
           whileInView={{ opacity: 1 }}
           viewport={{ once: true }}
           transition={{ duration: 0.8, delay: 0.8 }}
           className="mt-12 flex justify-center"
        >
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-6 py-3 border border-gold-500/30 text-gold-500 text-xs font-bold uppercase tracking-widest rounded-full hover:bg-gold-500 hover:text-brand-900 transition-all hover:shadow-[0_0_15px_rgba(223,170,82,0.4)] relative group"
          >
            <Clock className="w-4 h-4" />
            <span>View Past Wisdom</span>
            <div className="absolute inset-0 bg-gold-500 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity -z-10"></div>
          </button>
        </motion.div>
      </div>

      {/* Past Wisdom Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4 py-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-3xl bg-brand-900 border border-gold-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
            >
              <div className="relative flex items-center justify-between px-6 py-5 border-b border-gold-500/10 bg-brand-950 sticky top-0 z-10 shrink-0 overflow-hidden">
                <div
                  className="absolute inset-0 bg-cover bg-center opacity-[0.08] pointer-events-none"
                  style={{ backgroundImage: `url(${dailyTimingHeaderImg})` }}
                ></div>
                <div className="relative flex items-center gap-3 z-10">
                  <Clock className="w-5 h-5 text-gold-500" />
                  <h3 className="font-serif text-xl sm:text-2xl text-gold-500 font-bold">
                    Past 7 Days of Wisdom
                  </h3>
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="relative text-text-main hover:text-gold-500 transition-colors p-2 z-10"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="overflow-y-auto p-6 overflow-x-hidden space-y-6 shrink h-full scrollbar-thin scrollbar-thumb-gold-500/20 scrollbar-track-transparent">
                {pastThoughts.map((item, idx) => (
                  <motion.div 
                    key={item.day}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex flex-col sm:flex-row gap-6 p-6 rounded-xl border border-gold-500/10 bg-brand-800/50 hover:bg-brand-800 transition-colors"
                  >
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden flex items-center justify-center shrink-0 border border-gold-500/30 shadow-[0_0_15px_rgba(197,160,89,0.1)] bg-brand-950 mx-auto sm:mx-0">
                      <LazyImage
                        src={item.image}
                        alt={item.planet}
                        className="w-full h-full object-cover scale-110"
                        containerClassName="w-full h-full"
                      />
                    </div>
                    
                    <div className="flex-1 text-center sm:text-left">
                      <span className="text-gold-500 font-bold tracking-widest text-[10px] sm:text-xs uppercase border border-gold-500/20 px-3 py-1 rounded-full mb-3 inline-block">
                        {item.day}
                      </span>
                      <h4 className="text-lg font-serif text-text-main mb-2">
                        {item.planet}
                      </h4>
                      <p className="text-sm sm:text-base text-text-main font-serif italic leading-relaxed">
                        "{item.text}"
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
