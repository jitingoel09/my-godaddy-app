import { motion } from "motion/react";

const options = [
  {
    label: "My business strategy is rock-solid, but the revenue growth feels completely blocked.",
    tag: "Strategic Stagnation",
    targetId: "business-strategy-growth-consulting",
  },
  {
    label: "I have outgrown my current corporate role, but my personal brand isn't pulling boardroom opportunities.",
    tag: "Positioning Gap",
    targetId: "career-professional-consulting",
  },
  {
    label: "Outwardly successful, but running on autopilot. Looking for deeper clarity and alignment.",
    tag: "Core Misalignment",
    targetId: "personal-transformation-consulting",
  },
  {
    label: "Every metric says 'Go', but my gut or my timing feels off for this next big move.",
    tag: "Timing Friction",
    targetId: "cosmic-astrology-consultation",
  },
];

export function DecisionDriftQuiz() {
  const handleSelect = (targetId: string) => {
    const el = document.getElementById(targetId);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.add("gold-flash-highlight");
    setTimeout(() => el.classList.remove("gold-flash-highlight"), 1800);
  };

  return (
    <section id="decision-drift" className="py-14 bg-page-bg-800 relative border-t border-b border-gold-500/10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
          Quick Self-Check
        </h2>
        <h3 className="section-title text-2xl sm:text-3xl md:text-4xl font-serif font-bold tracking-tight mb-3">
          Where Is Your Momentum Leaking?
        </h3>
        <p className="text-sm sm:text-base text-text-main/70 mb-10">
          Select the statement that matches your current professional reality:
        </p>

        <div className="grid sm:grid-cols-2 gap-4">
          {options.map((opt, i) => (
            <motion.button
              key={opt.tag}
              onClick={() => handleSelect(opt.targetId)}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              /* Framer Motion's whileHover/whileFocus are used instead of CSS
                 :hover — motion.* components manage their own pointer/animation
                 state internally, which intercepts and blocks native CSS :hover
                 from ever matching (confirmed via direct testing, including
                 forcing the pseudo-state through Chrome DevTools Protocol). */
              whileHover={{
                y: -2,
                backgroundColor: "#1A0F0A",
                borderColor: "rgba(197, 168, 128, 0.55)",
                boxShadow:
                  "0 0 0 1px rgba(197, 168, 128, 0.25), 0 0 24px -6px rgba(197, 168, 128, 0.35)",
              }}
              whileFocus={{
                y: -2,
                backgroundColor: "#1A0F0A",
                borderColor: "rgba(197, 168, 128, 0.55)",
                boxShadow:
                  "0 0 0 1px rgba(197, 168, 128, 0.25), 0 0 24px -6px rgba(197, 168, 128, 0.35)",
              }}
              transition={{ duration: 0.45, delay: i * 0.07 }}
              className="quick-self-check-option text-left bg-brand-900/50 border border-gold-500/15 rounded-none px-5 py-5 cursor-pointer group"
            >
              <span className="text-[10px] uppercase tracking-widest font-mono font-bold text-gold-500/70 group-hover:text-gold-400 transition-colors">
                {opt.tag}
              </span>
              <p className="text-sm text-text-main/90 mt-2 leading-relaxed">{opt.label}</p>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}
