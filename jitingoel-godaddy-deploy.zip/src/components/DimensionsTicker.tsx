import { Star } from "lucide-react";

const DIMENSIONS = [
  "Business Strategy",
  "Market Momentum",
  "Career Direction",
  "Boardroom Positioning",
  "Personal Transformation",
  "Inner Clarity",
  "Vedic Timing",
  "Strategic Alignment",
];

export function DimensionsTicker() {
  return (
    <div className="premium-marquee-container">
      <div className="premium-marquee-content">
        {[...Array(2)].map((_, dup) => (
          <div key={dup} className="flex items-center shrink-0">
            {DIMENSIONS.map((label) => (
              <span key={label} className="flex items-center shrink-0">
                <span className="marquee-text-item">{label}</span>
                <span className="flex items-center gap-2 text-[#FFF6EC] shrink-0" aria-hidden="true">
                  <span>—</span>
                  <Star className="w-3 h-3 fill-current" />
                  <span>—</span>
                </span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
