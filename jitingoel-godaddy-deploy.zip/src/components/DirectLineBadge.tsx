import { motion } from "motion/react";
import signatureImg from "../assets/images/signature_jitin_goel.png";
import trustBarsImg from "../assets/images/trust_metric_bars.webp";

export function DirectLineBadge() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5 }}
      className="relative max-w-xl mx-auto bg-brand-900/60 border border-gold-500/25 rounded-2xl px-6 sm:px-8 py-7 text-center shadow-[0_0_40px_-15px_rgba(255,153,51,0.35)] overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center opacity-[0.05] pointer-events-none"
        style={{ backgroundImage: `url(${trustBarsImg})` }}
      ></div>
      <h3 className="relative text-lg sm:text-xl font-serif font-bold text-gold-400 mb-3">
        The Direct Engagement Guarantee
      </h3>
      <p className="relative text-sm text-text-main/80 leading-relaxed">
        I don't use junior consultants, sub-contractors, or automated playbook templates. From the initial chart calibration to the final execution roadmap, every single session is handled 100% directly by me. Your data, strategy, and timeline remain strictly confidential.
      </p>
      <motion.div
        className="relative flex justify-center mt-4"
        initial={{ clipPath: "inset(0 100% 0 0)" }}
        whileInView={{ clipPath: "inset(0 0% 0 0)" }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 1.2, ease: "easeInOut", delay: 0.3 }}
      >
        <span
          role="img"
          aria-label="Jitin Goel signature"
          className="h-8 sm:h-9 w-auto inline-block"
          style={{
            backgroundColor: "#A24B26",
            WebkitMaskImage: `url(${signatureImg})`,
            maskImage: `url(${signatureImg})`,
            WebkitMaskSize: "contain",
            maskSize: "contain",
            WebkitMaskRepeat: "no-repeat",
            maskRepeat: "no-repeat",
            WebkitMaskPosition: "center",
            maskPosition: "center",
            aspectRatio: "478 / 125",
          }}
        />
      </motion.div>
    </motion.div>
  );
}
