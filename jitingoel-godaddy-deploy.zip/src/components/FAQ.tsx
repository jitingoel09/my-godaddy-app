import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown } from "lucide-react";
import { faqImage } from "../utils/imageRegistry";
import faqFallbackImg from "../assets/images/pen_writing_process.webp";

const faqs = [
  {
    question: "How does the consulting process work?",
    answer:
      "I start with a discovery session to understand your challenges, then build a customized roadmap. Regular sessions keep you accountable and moving toward real progress.",
  },
  {
    question: "What should I expect from an astrology consultation?",
    answer:
      "I analyze your birth chart to uncover your strengths, challenges, and direction — giving you a clear lens for career, relationship, and personal decisions.",
  },
  {
    question: "How do you integrate business strategy with Vedic wisdom?",
    answer:
      "They're not separate tracks. A business decision affects your career; career pressure affects personal clarity; timing affects all three. I examine the complete picture, then add Vedic timing as one more layer of decision support.",
  },
  {
    question:
      "Are the strategy sessions suitable for startups or established businesses?",
    answer:
      "Both. Startups get help building a strong foundation and market fit. Established businesses get support scaling operations and navigating strategic pivots.",
  },
  {
    question: "How often should we meet for consulting sessions?",
    answer:
      "It depends on your goals — most clients meet bi-weekly or monthly to maintain momentum. We'll set the right cadence together in your first session.",
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section
      id="faq"
      className="py-14 bg-page-bg-800 relative border-t border-gold-500/20"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 sm:py-10 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
          >
            <h3 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
              Common Questions
            </h3>
            <h2 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif mb-6 font-bold">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-text-main/90 leading-relaxed font-normal">
              Find answers to commonly asked questions about my business,
              professional, personal, and astrology consulting services to
              help you make an informed decision.
            </p>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-12 gap-10 items-start">
          {/* Image side — placed on the right on desktop for alternating rhythm with adjacent sections */}
          <div className="lg:col-span-4 flex flex-col gap-6 lg:order-2">
            <div className="relative rounded-2xl overflow-hidden border border-gold-500/15 group h-[260px] lg:h-[400px] shadow-2xl bg-brand-900/50">
              <img 
                src={faqImage} 
                alt="Clarity and guidance for frequently asked consulting questions" 
                className="w-full h-full object-cover opacity-100 group-hover:opacity-1000 transition-all duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
                onError={(e) => { (e.target as HTMLImageElement).src = faqFallbackImg; }}
                loading="lazy"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#4D1A03] via-[#4D1A03]/40 to-transparent p-6 h-1/2 flex flex-col justify-end">
                <span className="text-[9px] uppercase font-bold text-gold-500 tracking-widest block mb-1">Inquiry & Wisdom</span>
                <p className="text-text-main font-serif text-md leading-normal">
                  The correct answers lie in finding the correct alignment.
                </p>
              </div>
            </div>
          </div>

          {/* Accordion list — placed on the left on desktop */}
          <div className="lg:col-span-8 space-y-4 lg:order-1">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: index * 0.12 }}
                className="border border-gold-500/20 bg-brand-900/50 rounded-xl overflow-hidden shadow-sm"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full px-6 py-5 flex justify-between items-center text-left focus:outline-none group hover:bg-brand-900/80 transition-colors"
                  aria-expanded={openIndex === index}
                >
                  <span className="font-serif text-base sm:text-lg text-text-main pr-4 group-hover:text-gold-500 transition-colors">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-gold-500 transition-transform duration-300 flex-shrink-0 ${openIndex === index ? "rotate-180" : ""}`}
                  />
                </button>

                <AnimatePresence>
                  {openIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="faq-answer-text px-6 pb-6 opacity-100 bg-brand-900/10 text-sm">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
