import React, { useState } from 'react';
import {
  Mail,
  Phone,
  Linkedin,
  Globe,
  ExternalLink,
  Copy,
  Check,
  Lock,
} from "lucide-react";
import { LegalModals, LegalDocType } from './LegalModals';
import { DirectLineBadge } from './DirectLineBadge';
import footerImg from "../assets/images/leather_journal_footer.webp";
import footerCrestImg from "../assets/images/footer_crest_texture.webp";

export function Footer() {
  const [clickCount, setClickCount] = useState(0);
  const [activeDoc, setActiveDoc] = useState<LegalDocType | null>(null);
  const [emailCopied, setEmailCopied] = useState(false);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText("jitin09@jitingoel.com");
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 2000);
    } catch {
      // Clipboard API can fail in some contexts; mailto link is still the primary path.
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAdminTrigger = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);
    if (newCount >= 5) {
      setClickCount(0);
      window.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'A',
        ctrlKey: true,
        shiftKey: true
      }));
    }
  };

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    href: string,
  ) => {
    e.preventDefault();
    const targetId = href.replace("#", "");

    const scrollToTarget = () => {
      const element = document.getElementById(targetId);
      if (element) {
        const top = element.getBoundingClientRect().top + window.scrollY - 100; // Account for navbar height
        window.scrollTo({
          top,
          behavior: "smooth",
        });
      }
    };

    if (targetId === "book" && !document.getElementById("book")) {
      // The booking calendar is conditionally rendered behind an onboarding
      // step in Services.tsx, so it doesn't exist in the DOM until that step
      // is dismissed. Dispatch the same signal Navbar.tsx uses, then poll
      // briefly for the element to actually appear before scrolling.
      window.dispatchEvent(new CustomEvent("jg:show-booking-calendar"));
      const maxAttempts = 40; // 40 * 100ms = 4s safety-net ceiling
      let attempts = 0;
      const poll = () => {
        attempts += 1;
        if (document.getElementById("book")) {
          scrollToTarget();
        } else if (attempts < maxAttempts) {
          setTimeout(poll, 100);
        }
      };
      poll();
    } else {
      scrollToTarget();
    }
  };

  return (
    <footer className="bg-page-bg-900 px-4 sm:px-12 pt-16 pb-24 sm:pb-12 border-t border-gold-500/10 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.06] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${footerImg})` }}
      ></div>
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-12">
          <DirectLineBadge />
          <div className="max-w-xl mx-auto mt-4 flex items-center justify-center gap-2 text-[11px] text-text-main/50">
            <Lock className="w-3 h-3 text-gold-500/60 shrink-0" />
            <span>All consultations are treated as strictly confidential and NDA-compliant. Your information is never shared, sold, or disclosed to any third party.</span>
          </div>
        </div>
        {/* Top Segment: Multi-Column Premium Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12 border-b border-gold-500/10 pb-12">
          
          {/* Brand Column */}
          <div className="relative">
            <div
              className="absolute -inset-2 bg-cover bg-center opacity-[0.05] pointer-events-none"
              style={{ backgroundImage: `url(${footerCrestImg})` }}
            ></div>
            <h3 className="relative text-lg font-serif text-text-main mb-1 font-semibold tracking-wide">
              Jitin Goel Consulting
            </h3>
            <p className="relative text-[11px] uppercase tracking-widest text-gold-500/80 mb-3 font-mono font-bold">
              Precision Strategy. Perfect Timing.
            </p>
            <p className="relative text-xs sm:text-sm text-text-main/80 leading-relaxed">
              I help businesses and individuals identify the real problem, build a practical strategy, and move forward with confidence.
            </p>
          </div>

          {/* My Services Column */}
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gold-500 mb-4 font-mono font-bold">
              My Services
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, "#services")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Business Strategy & Growth Consulting
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, "#services")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Career & Professional Consulting
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, "#services")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Personal Transformation Consulting
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, "#services")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Cosmic Astrology Consultation
                </a>
              </li>
            </ul>
          </div>

          {/* Quick Links Column */}
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gold-500 mb-4 font-mono font-bold">
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <a
                  href="#home"
                  onClick={(e) => handleNavClick(e, "#home")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#about"
                  onClick={(e) => handleNavClick(e, "#about")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  About Me
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, "#services")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Services
                </a>
              </li>
              <li>
                <a
                  href="#book"
                  onClick={(e) => handleNavClick(e, "#book")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Consultation Planner
                </a>
              </li>
              <li>
                <a
                  href="#interactive-tools"
                  onClick={(e) => handleNavClick(e, "#interactive-tools")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Astro Calculators
                </a>
              </li>
              <li>
                <a
                  href="#blog"
                  onClick={(e) => handleNavClick(e, "#blog")}
                  className="text-text-main/70 hover:text-gold-500 transition-colors duration-200 block"
                >
                  Blog
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gold-500 mb-4 font-mono font-bold">
              Contact Information
            </h3>
            <ul className="space-y-3 text-xs sm:text-sm text-text-main/80 mb-6">
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-gold-500/80 shrink-0" />
                <a href="tel:+918796578959" className="hover:text-gold-500 transition-colors">
                  +91 8796578959
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-gold-500/80 shrink-0" />
                <a href="mailto:jitin09@jitingoel.com" className="hover:text-gold-500 transition-colors break-all">
                  jitin09@jitingoel.com
                </a>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  aria-label="Copy email address"
                  title="Copy email address"
                  className="shrink-0 p-1 rounded-full text-text-main/50 hover:text-gold-500 hover:bg-white/5 active:scale-90 transition-colors"
                >
                  {emailCopied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </li>
              <li className="flex items-center gap-2.5">
                <Globe className="w-4 h-4 text-gold-500/80 shrink-0" />
                <a href="https://jitingoel.com" target="_blank" rel="noopener noreferrer" className="hover:text-gold-500 transition-colors inline-flex items-center gap-1">
                  jitingoel.com <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
            </ul>

            <h3 className="text-xs uppercase tracking-widest text-gold-500 mb-3 font-mono font-bold">
              Follow Us
            </h3>
            <div className="flex gap-3">
              <a
                href="https://www.linkedin.com/in/jitin-goel-43825822a"
                target="_blank"
                rel="noopener noreferrer"
                className="text-text-main hover:text-gold-500 transition-colors flex items-center justify-center bg-brand-900 border border-gold-500/20 hover:border-gold-500/50 rounded-lg p-2.5 shadow-md shadow-black/30 transition-all duration-300"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-4 h-4" aria-hidden="true" />
                <span className="text-xs font-medium ml-2">LinkedIn</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Segment */}
        <div className="flex flex-col lg:flex-row justify-between items-center gap-6 pt-4">
          <div className="flex flex-col md:flex-row gap-6 md:gap-4 lg:gap-6 text-[9px] uppercase tracking-widest opacity-100 text-text-main text-center md:text-left align-middle items-center flex-wrap justify-center">
            <span>Based in India</span>
            <span className="hidden md:inline text-gold-500/50">•</span>
            <span>Global Strategic Advisory</span>
            <span className="hidden md:inline text-gold-500/50">•</span>
            <span 
              className="relative cursor-default select-none"
              onClick={handleAdminTrigger}
            >
              © {new Date().getFullYear()} Jitin Goel Consulting
            </span>
            <span className="hidden lg:inline text-gold-500/50">•</span>
            <div className="flex flex-wrap gap-4 items-center mt-2 md:mt-0 border-t md:border-t-0 border-gold-500/20 pt-4 md:pt-0 w-full md:w-auto justify-center">
              <button 
                onClick={() => setActiveDoc('privacy')} 
                className="hover:text-gold-500 active:text-gold-600 transition-colors cursor-pointer bg-transparent border-none p-0 inline-block text-[9px] uppercase tracking-widest text-text-main"
              >
                Privacy Policy
              </button>
              <span className="text-gold-500/50">•</span>
              <button 
                onClick={() => setActiveDoc('cookie')} 
                className="hover:text-gold-500 active:text-gold-600 transition-colors cursor-pointer bg-transparent border-none p-0 inline-block text-[9px] uppercase tracking-widest text-text-main"
              >
                Cookies
              </button>
              <span className="text-gold-500/50">•</span>
              <button 
                onClick={() => setActiveDoc('legal')} 
                className="hover:text-gold-500 active:text-gold-600 transition-colors cursor-pointer bg-transparent border-none p-0 inline-block text-[9px] uppercase tracking-widest text-text-main"
              >
                Legal Terms
              </button>
              <span className="text-gold-500/50">•</span>
              <button 
                onClick={() => setActiveDoc('refund')} 
                className="hover:text-gold-500 active:text-gold-600 transition-colors cursor-pointer bg-transparent border-none p-0 inline-block text-[9px] uppercase tracking-widest text-text-main"
              >
                Refund &amp; Cancellation
              </button>
            </div>
          </div>
          
          <div className="flex gap-6 items-center">
            <button
              onClick={scrollToTop}
              className="flex gap-4 items-center cursor-pointer group rounded p-1 active:scale-95 transition-transform"
              aria-label="Scroll to top of page"
            >
              <div className="h-1 w-12 bg-gold-500/30 rounded-full transition-all group-hover:bg-gold-500/50"></div>
              <div className="h-1 w-4 bg-gold-500 rounded-full"></div>
            </button>
          </div>
        </div>
      </div>

      <LegalModals 
        isOpen={activeDoc !== null}
        docType={activeDoc}
        onClose={() => setActiveDoc(null)}
      />
    </footer>
  );
}

