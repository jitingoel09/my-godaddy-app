import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, X, ChevronRight, FileText, Briefcase, HelpCircle } from "lucide-react";
import { blogPosts } from "../data/blogPosts";

const searchableItems = [
  ...blogPosts.map((post) => ({
    id: `blog-${post.id}`,
    title: post.title,
    description: post.excerpt,
    category: "Insights",
    type: "blog",
    icon: FileText,
    href: "#blog",
  })),
  {
    id: "service-1",
    title: "Business Strategy & Growth Consulting",
    description: "Practical, strategic guidance for organizations to scale revenue and build market presence.",
    category: "Services",
    type: "service",
    icon: Briefcase,
    href: "#services",
  },
  {
    id: "service-2",
    title: "Career & Professional Consulting",
    description: "Consulting for professionals at every stage, from career transitions to leading through complex challenges and driving team performance.",
    category: "Services",
    type: "service",
    icon: Briefcase,
    href: "#services",
  },
  {
    id: "service-3",
    title: "Personal Transformation Consulting",
    description: "Structured reflection and decision clarity for high-performers navigating change.",
    category: "Services",
    type: "service",
    icon: Briefcase,
    href: "#services",
  },
  {
    id: "service-4",
    title: "Cosmic Astrology Consultation",
    description: "Insightful readings of your birth chart to uncover strengths, challenges, and life purpose.",
    category: "Services",
    type: "service",
    icon: Briefcase,
    href: "#services",
  },
  {
    id: "faq-1",
    title: "How does the consulting process work?",
    description: "My consulting process begins with an in-depth discovery session to understand your current challenges.",
    category: "FAQ",
    type: "faq",
    icon: HelpCircle,
    href: "#faq",
  },
  {
    id: "faq-2",
    title: "What should I expect from an astrology consultation?",
    description: "An astrology consultation is not just about prediction; it's a tool for profound self-understanding.",
    category: "FAQ",
    type: "faq",
    icon: HelpCircle,
    href: "#faq",
  },
  {
    id: "faq-3",
    title: "How do you integrate business strategy with Vedic wisdom?",
    description: "I bridge practical, modern business frameworks with the timeless principles of Vedic wisdom.",
    category: "FAQ",
    type: "faq",
    icon: HelpCircle,
    href: "#faq",
  },
  {
    id: "faq-4",
    title: "Are the strategy sessions suitable for startups or established businesses?",
    description: "The sessions are beneficial for both. For startups, we focus on establishing a strong foundation.",
    category: "FAQ",
    type: "faq",
    icon: HelpCircle,
    href: "#faq",
  },
  {
    id: "faq-5",
    title: "How often should we meet for consulting sessions?",
    description: "The frequency depends on your specific goals and the package you choose.",
    category: "FAQ",
    type: "faq",
    icon: HelpCircle,
    href: "#faq",
  },
];

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GlobalSearch({ isOpen, onClose }: GlobalSearchProps) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
      setQuery("");
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  const filteredItems = query
    ? searchableItems.filter(
        (item) =>
          item.title.toLowerCase().includes(query.toLowerCase()) ||
          item.description.toLowerCase().includes(query.toLowerCase()) ||
          item.category.toLowerCase().includes(query.toLowerCase()),
      )
    : [];

  const handleResultClick = (item: typeof searchableItems[0]) => {
    onClose();
    if (item.type === "blog") {
      const postId = item.id.replace("blog-", "");
      
      // Update URL query params without full page reload
      const url = new URL(window.location.href);
      url.searchParams.set("post", postId);
      window.history.pushState({}, "", url.toString());

      // Scroll to the blog section
      setTimeout(() => {
        const element = document.getElementById("blog");
        if (element) {
          const top = element.getBoundingClientRect().top + window.scrollY - 100;
          window.scrollTo({
            top,
            behavior: "smooth",
          });
        }
        // Dispatch custom event to notify Blog component to open the article modal immediately
        window.dispatchEvent(
          new CustomEvent("open-blog-post", { detail: { postId: parseInt(postId, 10) } })
        );
      }, 150);
    } else {
      setTimeout(() => {
        const targetId = item.href.replace("#", "");
        const element = document.getElementById(targetId);
        if (element) {
          const top = element.getBoundingClientRect().top + window.scrollY - 100;
          window.scrollTo({
            top,
            behavior: "smooth",
          });
        }
      }, 150);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-brand-900/80 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-[10%] -translate-x-1/2 w-full max-w-2xl px-4 z-[101]"
            role="dialog"
            aria-modal="true"
            aria-label="Global Search Box"
          >
            <div className="bg-brand-800 border border-gold-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
              {/* Search Input Area */}
              <div className="flex items-center px-4 py-4 border-b border-gold-500/20">
                <Search className="w-5 h-5 text-gold-500 shrink-0" aria-hidden="true" />
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Search services, insights, or FAQs..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="flex-1 bg-transparent border-none text-text-main placeholder-text-main/40 focus:ring-0 text-lg px-4 focus:outline-none"
                  aria-label="Search site content"
                />
                <button
                  onClick={onClose}
                  className="p-1 rounded-md hover:bg-gold-500/10 text-text-main hover:text-text-main transition-colors shrink-0"
                  aria-label="Close search"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Results */}
              <div className="overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gold-500/20 scrollbar-track-transparent flex-1">
                {query === "" ? (
                  <div className="px-6 py-12 text-center text-text-main text-sm font-normal">
                    Start typing to search for specific topics, consulting services, or frequently asked questions.
                  </div>
                ) : filteredItems.length === 0 ? (
                  <div className="px-6 py-12 text-center text-text-main text-sm font-normal">
                    No results found for "{query}".
                  </div>
                ) : (
                  <div className="space-y-1">
                    {filteredItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleResultClick(item)}
                        className="w-full text-left flex items-start gap-4 p-4 rounded-xl hover:bg-gold-500/5 transition-colors group"
                      >
                        <div className="p-2 rounded-lg bg-brand-900 border border-gold-500/20 group-hover:border-gold-500/50 shrink-0 transition-colors">
                          <item.icon className="w-5 h-5 text-gold-500/80" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs uppercase tracking-wider text-gold-500/80 font-medium">
                              {item.category}
                            </span>
                          </div>
                          <h3 className="text-base text-text-main font-medium group-hover:text-gold-400 transition-colors">
                            {item.title}
                          </h3>
                          <p className="text-sm text-text-main mt-1 line-clamp-1 font-normal">
                            {item.description}
                          </p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-text-main group-hover:text-gold-500 flex-shrink-0 self-center transition-colors transform group-hover:translate-x-1" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Footer */}
              <div className="px-4 py-3 border-t border-gold-500/20 bg-brand-900/50 text-xs text-text-main flex justify-between items-center">
                <span><kbd className="bg-brand-900 border border-gold-500/30 rounded px-1.5 py-0.5 font-sans">esc</kbd> to close</span>
                <span>{filteredItems.length} result{filteredItems.length !== 1 ? 's' : ''}</span>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
