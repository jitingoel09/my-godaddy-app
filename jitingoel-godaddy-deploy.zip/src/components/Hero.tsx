import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import portraitImg from "../assets/images/jitin_hero_portrait.webp";
import hanumanImg from "../assets/images/lord_hanuman_devotion_1783329128754.webp";
import logoImg from "../assets/images/jg_medallion_logo.webp";
import heroFabricTexture from "../assets/images/hero_fabric_texture.webp";
import signatureImg from "../assets/images/signature_jitin_goel.png";
import { LazyImage } from "./LazyImage";
import { TrendingUp, Briefcase, Star, Compass, X, Calendar, ChevronRight } from "lucide-react";
import { PrePaymentModal } from "./PrePaymentModal";


import { useRenderCountDev } from "../dev/perfInstrumentation";

export function Hero() {
  useRenderCountDev("Hero");
  const [greeting, setGreeting] = useState("");
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [prePaymentOpen, setPrePaymentOpen] = useState(false);
  const [prePaymentService, setPrePaymentService] = useState("");

  const servicesToBook = [
    {
      name: "Business Strategy & Growth Consulting",
      description: "Find the real bottleneck, then build a practical roadmap for growth.",
      icon: TrendingUp,
    },
    {
      name: "Career & Professional Consulting",
      description: "Rebuild your positioning so the right opportunities notice you.",
      icon: Briefcase,
    },
    {
      name: "Personal Transformation Consulting",
      description: "Structured reflection to rebuild clarity in your decisions.",
      icon: Compass,
    },
    {
      name: "Cosmic Astrology Consultation",
      description: "Decode birth charts, timing metrics, and planetary alignments.",
      icon: Star,
    },
  ];

  const handleDirectWhatsAppBook = (serviceName: string) => {
    setPrePaymentService(serviceName);
    setPrePaymentOpen(true);
    setIsBookingModalOpen(false);
  };

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good Morning");
    else if (hour < 18) setGreeting("Good Afternoon");
    else setGreeting("Good Evening");
  }, []);

  // Keyboard accessibility: Escape closes the booking modal while it's open.
  useEffect(() => {
    if (!isBookingModalOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsBookingModalOpen(false);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isBookingModalOpen]);

  return (
    <section
      id="home"
      className="hero-section-background relative w-full flex flex-col justify-center bg-page-bg-900 overflow-hidden pt-[110px] pb-10 lg:pt-[120px] lg:pb-8 min-h-[95svh] lg:min-h-[85svh]"
    >
      {/* Background aesthetic touches */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none" aria-hidden="true">
        {/* Subtle fabric texture — adds depth without shifting the base
            #1A0F0A canvas tone (kept low-opacity to preserve section-to-section
            color harmony established earlier) */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-[0.06] mix-blend-overlay"
          style={{ backgroundImage: `url(${heroFabricTexture})` }}
        ></div>
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMTk3LCAxNjAsODksIDAuMSkiLz48L3N2Zz4=')] opacity-100 mix-blend-overlay"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex-grow flex flex-col justify-center items-center">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="flex justify-center mb-6 sm:mb-8 w-full relative z-20 mt-4 sm:mt-0"
        >
          <div className="flex flex-col items-center justify-center gap-4 group">
            <div className="flex flex-col items-center justify-center text-center">
              <div
                className="relative w-16 h-16 sm:w-20 sm:h-20 mb-5 group flex justify-center items-center"
                aria-hidden="true"
              >
                {/* Modern Aura Glow */}
                <div className="absolute -inset-2 bg-gradient-to-tr from-gold-500/40 via-orange-500/20 to-amber-500/30 rounded-full blur-xl group-hover:blur-2xl transition-all duration-700 opacity-100 group-hover:opacity-1000 animate-pulse"></div>
                
                {/* Sleek Glassmorphic Container */}
                <div className="relative w-full h-full rounded-[1.25rem] sm:rounded-3xl flex items-center justify-center bg-brand-900/60 backdrop-blur-xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.4)] overflow-hidden transition-all duration-500 group-hover:scale-[1.03] group-hover:border-orange-400/50">
                  {/* Subtle light leak effects */}
                  <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent"></div>
                  <div className="absolute w-[200%] h-[200%] bg-gradient-to-bl from-white/5 via-transparent to-transparent -top-1/2 -right-1/2 rotate-12 pointer-events-none"></div>

                  {/* Brand logo mark */}
                  <img
                    src={logoImg}
                    alt="Jitin Goel Consulting"
                    className="w-[78%] h-[78%] object-contain relative z-10"
                    loading="eager"
                    fetchPriority="high"
                  />
                </div>
              </div>
              <h2 className="group text-2xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-[4.5rem] font-serif font-extrabold uppercase tracking-[0.1em] sm:tracking-[0.15em] md:tracking-[0.12em] leading-[1.15] mb-3 focus:outline-none drop-shadow-[0_3px_10px_rgba(0,0,0,0.28)] relative z-10 px-2 py-1 cursor-default">
                <span className="relative inline-block">
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#FFF5EB] via-[#FFB066] to-[#CC7A29] drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)] pr-1">
                    JITIN GOEL CONSULTING
                  </span>
                  <span className="absolute left-0 -bottom-1 w-full h-[3px] bg-gradient-to-r from-[#FFB066] to-transparent transform origin-left scale-x-0 transition-transform duration-700 ease-out group-hover:scale-x-100 shadow-[0_0_10px_rgba(255,176,102,0.5)] rounded-full"></span>
                </span>
              </h2>
              <span 
                className="text-xs sm:text-sm md:text-base tracking-[0.22em] md:tracking-[0.3em] block leading-none hero-sub-title"
              >
                Strategy & Wisdom
              </span>
            </div>

            <div className="relative mt-2">
              <div className="absolute -inset-4 bg-gold-600/10 rounded-full blur-2xl group-hover:opacity-1000 opacity-100 transition-opacity duration-1000 animate-pulse"></div>
              <div className="absolute -inset-2 border-2 border-orange-500/20 rounded-full z-0"></div>
              <div className="w-20 h-20 md:w-28 md:h-28 rounded-full overflow-hidden border-[4px] border-orange-400/90 flex items-center justify-center bg-brand-950 shadow-[0_0_50px_rgba(255,153,51,0.6)] relative z-10 shrink-0 mx-auto">
                <img
                  src={hanumanImg}
                  alt="Lord Hanuman"
                  className="w-full h-full object-cover scale-110 group-hover:scale-125 transition-transform duration-1000"
                  loading="eager"
                  fetchPriority="high"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3 mt-3">
               <span className="w-8 h-px bg-gradient-to-r from-transparent to-gold-400/70"></span>
               <span 
                 className="font-serif italic tracking-[0.15em] text-base md:text-lg greeting-capsule-text"
               >
                 Jai Shree Ram
               </span>
               <span className="w-8 h-px bg-gradient-to-l from-transparent to-gold-400/70"></span>
            </div>
          </div>
        </motion.div>

        <div className="flex flex-col items-center justify-center gap-6 w-full max-w-4xl mx-auto text-center">
          <div className="w-full flex flex-col items-center text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="w-full"
            >
              <div className="mb-4 flex flex-col items-center text-center">
                <span 
                  className="tracking-widest uppercase text-sm sm:text-base block mb-1 greeting-capsule-text"
                >
                  {greeting && `${greeting}`}
                </span>
              </div>
              <h1 className="hero-main-title text-[2.5rem] sm:text-5xl md:text-6xl lg:text-7xl xl:text-[5rem] leading-[1.1] mb-6 flex flex-col items-center text-center">
                <span>20+ Years in the Boardroom.</span>
                <span className="mt-2 text-gold-400">26 Years Reading the Cycles.</span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl font-normal opacity-95 premium-body-text mx-auto mb-8 text-text-main/90">
                I built my career on real P&L accountability, not theory. I bring that same rigor to your business, career, and personal decisions — with Vedic timing as the layer most advisors skip.
              </p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.7 }}
                className="mt-8 lg:mt-10 flex flex-col items-center gap-4 w-full"
              >
                <div className="flex flex-wrap justify-center gap-4 w-full">
                  <button
                    onClick={() => setIsBookingModalOpen(true)}
                    className="px-8 py-3.5 rounded-full border border-gold-500 bg-gold-500 text-brand-900 text-sm font-bold uppercase tracking-widest shadow-lg hover:bg-gold-400 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                  >
                    Get My Strategy
                  </button>
                  <button
                    onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
                    className="px-8 py-3.5 rounded-full border border-gold-500/50 bg-brand-800/80 text-gold-400 text-sm font-bold uppercase tracking-widest shadow-sm hover:border-gold-500 hover:text-gold-500 hover:bg-brand-800 active:scale-95 transition-all cursor-pointer backdrop-blur-sm"
                  >
                    See How I Can Help
                  </button>
                </div>
              </motion.div>
            </motion.div>
          </div>
 
          <div className="w-full mt-12 pb-8 -mx-4 sm:mx-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, x: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hero-profile-avatar leadership-experience-block w-full max-w-none sm:max-w-[456px] lg:max-w-[480px] xl:max-w-[528px] relative sm:mx-auto"
            >
              <div className="absolute inset-0 bg-gold-500/10 rounded-[2rem] blur-2xl transform rotate-3 scale-105 -z-10 transition-transform duration-700 hover:rotate-6 hover:scale-110"></div>
              <div className="relative w-full aspect-[4/5] sm:aspect-[3/4] lg:aspect-[4/5] rounded-[2rem] overflow-hidden shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5)] border border-gold-500/30 group bg-brand-800">
                <div className="absolute inset-0 bg-gradient-to-t from-[#4D1A03]/95 from-15% via-[#4D1A03]/75 via-45% to-transparent z-10 transition-opacity duration-300 group-hover:from-[#4D1A03]/90 pointer-events-none"></div>
                <LazyImage
                  src={portraitImg}
                  alt="Jitin Goel"
                  className="w-full h-full object-cover object-[center_15%] transform group-hover:scale-105 transition-transform duration-1000 ease-out"
                  containerClassName="w-full h-full"
                  loading="eager"
                  fetchPriority="high"
                />
 
                <div className="absolute bottom-0 left-0 right-0 p-8 z-20 flex flex-col items-center text-center">
                  <div className="mb-8 flex flex-col items-center transform group-hover:-translate-y-2 transition-transform duration-500">
                    <span className="block text-4xl sm:text-5xl font-serif text-white mb-3 drop-shadow-lg">
                      20+ Years
                    </span>
                    <span className="text-[10px] sm:text-xs uppercase tracking-[0.2em] text-gold-400 font-bold bg-brand-950/80 backdrop-blur-sm px-5 py-2 rounded-full border border-gold-500/40 shadow-lg group-hover:bg-brand-950 transition-colors">
                      Leadership Experience
                    </span>
                  </div>
                </div>
              </div>
              <div className="executive-signature-panel">
                <p className="executive-tagline">"Success often leaves you with fewer people to talk to. Let's find your clarity here."</p>
                <div className="signature-wrapper">
                  <span
                    role="img"
                    aria-label="Jitin Goel signature"
                    className="h-8 sm:h-9 w-auto inline-block"
                    style={{
                      backgroundColor: "#A24B26",
                      WebkitMaskImage: `url(${signatureImg})`,
                      maskImage: `url(${signatureImg})`,
                      WebkitMaskSize: "contain",
                      maskSize: "contain",
                      WebkitMaskRepeat: "no-repeat",
                      maskRepeat: "no-repeat",
                      WebkitMaskPosition: "center",
                      maskPosition: "center",
                      aspectRatio: "478 / 125",
                    }}
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Modern, high-conversion direct WhatsApp booking modal */}
      <AnimatePresence>
        {isBookingModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:pt-32">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsBookingModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="relative bg-brand-900 border border-gold-500/30 rounded-2xl w-full max-w-xl shadow-2xl z-10 overflow-hidden max-h-[85dvh] sm:max-h-[calc(100dvh-9rem)] flex flex-col"
              role="dialog"
              aria-modal="true"
              aria-labelledby="hero-booking-modal-title"
            >
              <div className="absolute top-0 right-0 left-0 h-[2px] bg-gradient-to-r from-transparent via-gold-500/50 to-transparent z-20"></div>
              
              {/* Header — sticky so the close button is always reachable, even on short mobile viewports */}
              <div className="flex justify-between items-start p-6 sm:p-8 pb-6 shrink-0 sticky top-0 bg-brand-900 z-20 border-b border-gold-500/10">
                <div>
                  <h3 id="hero-booking-modal-title" className="text-xl sm:text-2xl font-serif font-bold text-gold-500">
                    Direct WhatsApp Consultation
                  </h3>
                  <p className="text-xs text-text-main/70 mt-1 max-w-[90%]">
                    Choose one of my premium services and go directly to WhatsApp to finalize your fast booking with Jitin Goel.
                  </p>
                </div>
                <button
                  onClick={() => setIsBookingModalOpen(false)}
                  className="p-1 px-2 border border-gold-500/20 rounded-md hover:bg-gold-500/10 text-gold-400 hover:text-gold-500 transition-colors focus:outline-none"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Service List Options */}
              <div className="flex-1 min-h-0 overflow-y-auto space-y-3 px-6 sm:px-8 pb-6 sm:pb-8 pt-4 scrollbar-thin">
                {servicesToBook.map((svc) => {
                  const IconComp = svc.icon;
                  return (
                    <button
                      key={svc.name}
                      onClick={() => handleDirectWhatsAppBook(svc.name)}
                      className="w-full flex items-center gap-4 p-4 text-left rounded-xl bg-brand-800/60 border border-gold-500/10 hover:border-gold-500/40 hover:bg-brand-800 transition-all group duration-300 relative overflow-hidden active:scale-[0.99]"
                    >
                      <div className="absolute inset-0 bg-gold-500/0 group-hover:bg-gold-500/5 transition-colors"></div>
                      <div className="w-10 h-10 rounded-lg bg-gold-500/10 flex items-center justify-center text-gold-400 group-hover:bg-gold-500 group-hover:text-brand-900 transition-all shrink-0">
                        <IconComp className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-white group-hover:text-gold-400 transition-colors">
                          {svc.name}
                        </h4>
                        <p className="text-xs text-text-main/70 mt-0.5 line-clamp-1 group-hover:text-text-main transition-colors">
                          {svc.description}
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gold-500/40 group-hover:text-gold-400 transition-colors group-hover:translate-x-1 duration-300 shrink-0" />
                    </button>
                  );
                })}
              </div>

              {/* Bottom Path for Calendar */}
              <div className="mt-6 pt-4 border-t border-gold-500/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs shrink-0 bg-brand-900">
                <span className="text-text-main/60 font-medium">Prefer offline or custom scheduling?</span>
                <button
                  onClick={() => {
                    setIsBookingModalOpen(false);
                    setTimeout(() => {
                      document.getElementById("book")?.scrollIntoView({ behavior: "smooth" });
                    }, 350);
                  }}
                  className="flex items-center gap-1.5 text-gold-400 hover:text-gold-500 font-bold uppercase tracking-widest hover:underline transition-colors focus:outline-none"
                >
                  <Calendar className="w-4 h-4" />
                  Schedule on Calendar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <PrePaymentModal
        isOpen={prePaymentOpen}
        onClose={() => setPrePaymentOpen(false)}
        serviceTitle={prePaymentService}
      />
    </section>
  );
}
