import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import localFallbackImg from '../assets/images/compass_strategy_timing.webp';

interface LazyImageProps {
  containerClassName?: string;
  blurColor?: string;
  src?: string | any;
  alt?: string;
  className?: string;
  [x: string]: any;
}

export function LazyImage({ 
  src, 
  alt, 
  className = "", 
  containerClassName = "", 
  blurColor = 'bg-brand-800', // default fallback color
  ...props 
}: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    // Reset state when the src changes
    setIsLoaded(false);
    setError(false);

    // If already in browser cache, complete will be true immediately
    if (imgRef.current && imgRef.current.complete) {
      setIsLoaded(true);
    }
  }, [src]);

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      <motion.div
        initial={false}
        animate={{ opacity: isLoaded ? 0 : 1 }}
        transition={{ duration: 0.3 }}
        className={`absolute inset-0 z-10 ${blurColor}`}
        style={{
           backdropFilter: 'blur(20px)',
           WebkitBackdropFilter: 'blur(20px)'
         }}
      >
         <div className="w-full h-full animate-pulse bg-white/10" />
      </motion.div>
      {src && (
        <motion.img
          ref={imgRef}
          initial={false}
          animate={{ opacity: isLoaded ? 1 : 0 }}
          transition={{ duration: 0.3 }}
          src={error ? localFallbackImg : src}
          alt={alt}
          className={`w-full h-full ${className}`}
          loading="lazy"
          referrerPolicy="no-referrer"
          onLoad={() => setIsLoaded(true)}
          onError={() => {
            console.warn(`LazyImage failed to load: ${src}. Falling back.`);
            setError(true);
          }}
          {...props}
        />
      )}
    </div>
  );
}
