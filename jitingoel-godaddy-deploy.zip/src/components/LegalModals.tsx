import React, { useEffect } from "react";
import { X, Shield, Eye, Scale, Download, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export type LegalDocType = "privacy" | "cookie" | "legal" | "refund";

interface LegalModalsProps {
  isOpen: boolean;
  docType: LegalDocType | null;
  onClose: () => void;
}

export function LegalModals({ isOpen, docType, onClose }: LegalModalsProps) {
  // Prevent background scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  // Keyboard accessibility: Escape closes the modal.
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen || !docType) return null;

  const handleDownload = (title: string, content: string) => {
    const element = document.createElement("a");
    const file = new Blob([content], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${title.toLowerCase().replace(/\s+/g, "_")}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const getDocContent = () => {
    switch (docType) {
      case "privacy":
        return {
          title: "Privacy Policy",
          icon: <Shield className="w-6 h-6 text-gold-500" />,
          subtitle: "Last Updated: June 2026",
          rawText: `PRIVACY POLICY - JITIN GOEL CONSULTING
Last Updated: June 2026

At Jitin Goel Consulting, we respect your privacy and are committed to protecting your personal data. This Privacy Policy details how we handle the information collected from your interactions with our strategic advisory services, contact forms, and digital platforms.

1. DATA WE COLLECT
We collect personal identification information including, but not limited to:
- Contact Information (Name, email address, phone number).
- Business Information (Company name, industry sector, corporate challenges, scale of operations).
- Consultation Details (Information shared in strategic interest forms or inquiry submissions).

2. HOW WE USE YOUR DATA
Your information is strictly used to:
- Prepare bespoke corporate alignment mappings and Vedic advisories.
- Respond to direct consulting inquiries and handle custom requests.
- Securely track global interest via our platform's secure, non-identifying database engine.
- Deliver requested newsletters, insights, and advisory updates.

3. DATA RETENTION AND SECURITY
We do not sell, lease, or distribute your private information to third-party brokers. All client communications, strategy documents, and contact details are stored securely. Our platform utilizes industry-compliant cloud technology (Firebase Firestore) with customized security rules to prevent unauthorized access.

4. YOUR RIGHTS UNDER GDPR / CCPA
Depending on your region, you hold specific rights:
- The right to access your stored records.
- The right to correct or update inaccurate information.
- The right to request the complete deletion of your records.

5. CONTACT US
For privacy questions, data requests, or formal inquiries:
Email: jitin09@jitingoel.com`,
          sections: [
            {
              heading: "1. Data We Collect",
              text: "We collect personal identification details (such as your name, corporate email address, and phone number) alongside any business context or strategic challenges you share through our consultation forms. This allows us to tailor our approach to your unique professional goals."
            },
            {
              heading: "2. How We Use Your Data",
              text: "Your data is strictly utilized to process strategic inquiries, prepare bespoke leadership blueprints, provide astrological timing recommendations, and issue updates. We never share, sell, or rent your data to marketing agencies or third parties."
            },
            {
              heading: "3. Retention & Security",
              text: "We apply rigorous administrative, technical, and architectural defenses to safeguard your records. Our software framework is integrated with secure Firebase databases, utilizing high-grade server-side constraints and encryption-in-transit."
            },
            {
              heading: "4. Your Control & Rights",
              text: "You can request access to your data, opt-out of newsletter lists, or obtain complete deletion of any stored contact data at any time by emailing our data compliance desk at jitin09@jitingoel.com."
            }
          ]
        };

      case "cookie":
        return {
          title: "Cookies",
          icon: <Eye className="w-6 h-6 text-gold-500" />,
          subtitle: "Last Updated: June 2026",
          rawText: `COOKIES - JITIN GOEL CONSULTING
Last Updated: June 2026

Our platform uses standard client-side technologies to deliver a secure, fast, and high-quality web experience. This section explains what cookies are, how we use them, and how you can manage them.

1. WHAT ARE COOKIES?
Cookies are small text files downloaded by your web browser when visiting our site. They enable our system to remember basic local configurations (such as dark-mode visual preferences) and facilitate navigation.

2. WHAT COOKIES DO WE USE?
- Essential Functional Cookies: Required to execute core interactions, maintain security layers, and retain preferred visual settings.
- Performance & Visitor Analytics: Our platform features an isolated, real-time Visitor Counter. We use safe, privacy-respecting client cookies to ensure unique, non-identifying visitor tracking, eliminating the need for intrusive third-party analytical scripts.

3. CONTROLLING COOKIES
You have the complete freedom to accept or decline cookies. Most web browsers allow you to modify cookie preferences or purge downloaded history in their settings tabs. Disabling functional cookies may slightly alter the visual loading times of certain premium interactive elements.`,
          sections: [
            {
              heading: "1. What are Cookies?",
              text: "Cookies are safe, lightweight text files placed on your device to help analyze traffic patterns, memorize visual settings, or sustain dynamic interactive displays during your session."
            },
            {
              heading: "2. Dynamic Visitor Intelligence",
              text: "We feature an elite real-time visitor tracking engine designed to tally global site interactions. This tracker processes a temporary non-identifying cookie to guard counters against repeated fake hits, preserving server efficiency while strictly respecting consumer anonymity."
            },
            {
              heading: "3. Direct Cookie Control",
              text: "You may adjust your web browser settings to block or wipe out cookies globally. If you disable cookies, our main portal will remain fully readable, though some minor interactive state persistence may be reset."
            }
          ]
        };

      case "legal":
        return {
          title: "Legal Terms",
          icon: <Scale className="w-6 h-6 text-gold-500" />,
          subtitle: "Last Updated: June 2026",
          rawText: `LEGAL TERMS AND PRINCIPLED ADVISORY DISCLAIMER
Last Updated: June 2026

Welcome to Jitin Goel Consulting. By accessing our website, you agree to comply with and be bound by the following Legal Terms and Professional Disclaimers.

1. ADVISORY AGREEMENT & SCOPE
All leadership briefings, astrological indicators, corporate forecasts, and consultations and guidance are provided for high-level strategic planning, foresight alignment, and transformation modeling. Decisions made as a consequence of these insights are the sole responsibility of the client. Consultations do not replace clinical mental health, licensed financial, or formal legal counsel.

2. INTELLECTUAL PROPERTY RIGHTS
The proprietary methodologies, visual animations, textual blueprints, logo designations, and custom codebase representing Jitin Goel Consulting are the exclusive intellectual property of the founder. Unsanctioned copying, commercial replication, or extraction of strategic frameworks is legally prohibited.

3. LIMITATION OF LIABILITY
In no event shall Jitin Goel Consulting or its affiliates be held liable for indirect, incidental, or operational outcomes resulting from the implementation of advised systems. All strategic recommendations are provided on an 'as-is' basis, rooted in the optimal convergence of business metrics and Vedic principles.

4. SEVERABILITY AND GOVERNING LAW
If any paragraph of these terms is deemed unlawful or unenforceable by legal authorities, the remaining passages shall continue to hold full validity. All provisions are governed strictly under the laws of India, under the direct jurisdiction of its commercial tribunals.`,
          sections: [
            {
              heading: "1. Scope of Consultations",
              text: "All strategic forecasts, numerology grids, and corporate advice represent elite qualitative planning aids. Jitin Goel Consulting advises business leaders globally but emphasizes that all strategic executive moves, commercial risks, and investments remain the exclusive accountability of the receiving organization."
            },
            {
              heading: "2. Intellectual Property",
              text: "The combination of modern corporate formulas and Vedic guidance representing Jitin Goel Consulting, including the design, logo marks, code scripts, and strategic publications, is guarded by copyright and intellectual property laws."
            },
            {
              heading: "3. Disclaimer of Guarantee",
              text: "While our tracking histories highlight significant real-world client successes, past performance is highly context-dependent. No specific financial yields or rigid timelines are legally guaranteed; consultative guidance is offered as a dynamic personal/professional growth catalyst."
            },
            {
              heading: "4. Governing Jurisdiction",
              text: "These terms and all virtual consulting arrangements are managed in accordance with Indian commercial regulations, under the local courts' exclusive jurisdiction."
            }
          ]
        };
      case "refund":
        return {
          title: "Refund & Cancellation Policy",
          icon: <RotateCcw className="w-6 h-6 text-gold-500" />,
          subtitle: "Last Updated: June 2026",
          rawText: `REFUND & CANCELLATION POLICY - JITIN GOEL CONSULTING
Last Updated: June 2026

Because our consulting and advisory engagements are priced individually based on scope and duration rather than a fixed package fee, this policy explains how cancellations, rescheduling, and refunds are handled for every booking, regardless of the agreed price.

1. BEFORE YOU PAY
No payment is collected until you have received and agreed to a specific quote for your session or engagement. Please review the scope, date, and price carefully before completing payment.

2. RESCHEDULING
You may request to reschedule your session at no extra cost if you notify us at least 24 hours before the scheduled time, via email or WhatsApp. Requests made less than 24 hours before the session will be accommodated on a best-effort basis, subject to availability.

3. CANCELLATIONS AND REFUNDS
More than 48 hours before the session: full refund of the amount paid. Between 24-48 hours before the session: 50% refund, or a free reschedule at your choice. Less than 24 hours before the session, or no-show: no refund, as the time slot was reserved specifically for you. Once a session has taken place, the engagement is considered delivered and is non-refundable.

4. EXCEPTIONAL CIRCUMSTANCES
We understand that genuine emergencies happen. If you are unable to attend due to a medical emergency or similarly serious, unforeseen circumstance, please contact us as soon as possible. We review such requests individually and in good faith, even outside the standard windows above.

5. REFUND PROCESSING TIME
Approved refunds are processed back to your original payment method. Depending on your bank or card issuer, this may take up to 5-7 business days to reflect in your account after approval.`,
          sections: [
            {
              heading: "1. Case-by-Case Pricing",
              text: "Consultation fees are quoted individually based on scope and duration. No payment is requested until you have agreed to a specific quote."
            },
            {
              heading: "2. Rescheduling",
              text: "Free rescheduling is available with at least 24 hours' notice via email or WhatsApp. Later requests are accommodated on a best-effort basis."
            },
            {
              heading: "3. Cancellation Windows",
              text: "Full refund if cancelled more than 48 hours before the session; 50% refund between 24-48 hours; no refund inside 24 hours or for no-shows. Completed sessions are non-refundable."
            },
            {
              heading: "4. Exceptional Circumstances",
              text: "Genuine emergencies are reviewed individually and in good faith, even outside the standard cancellation windows."
            },
            {
              heading: "5. Processing Time",
              text: "Approved refunds are returned to your original payment method and may take 5-7 business days to appear, depending on your bank or card issuer."
            }
          ]
        };
    }
  };

  const doc = getDocContent();

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-brand-950/80 backdrop-blur-md"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: "spring", duration: 0.5 }}
          className="relative w-full max-w-2xl bg-brand-900 border border-gold-500/20 rounded-xl shadow-2xl p-6 md:p-8 max-h-[85vh] flex flex-col z-10 font-sans"
          role="dialog"
          aria-modal="true"
          aria-labelledby="legal-modal-title"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-gold-500/10 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gold-500/10 rounded-lg">
                {doc.icon}
              </div>
              <div>
                <h3 id="legal-modal-title" className="text-xl font-serif text-text-main font-bold tracking-wide">
                  {doc.title}
                </h3>
                <p className="text-xs text-gold-500/60 font-mono">
                  {doc.subtitle}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDownload(doc.title, doc.rawText)}
                className="p-2 text-text-main hover:text-gold-500 transition-colors bg-brand-950/40 hover:bg-gold-500/10 rounded-lg border border-gold-500/10"
                title="Download text file copy"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 text-text-main hover:text-gold-500 transition-colors bg-brand-950/40 hover:bg-gold-500/10 rounded-lg border border-gold-500/10"
                aria-label="Close dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scrollable Content Pane */}
          <div className="flex-1 overflow-y-auto pr-2 space-y-6 text-sm text-text-main/80 leading-relaxed scrollbar-thin scrollbar-thumb-gold-500/20 scrollbar-track-transparent">
            {doc.sections.map((sec, index) => (
              <div key={index} className="space-y-2">
                <h4 className="text-sm font-serif font-bold text-gold-500 tracking-wide">
                  {sec.heading}
                </h4>
                <p className="pl-1 border-l border-gold-500/10 text-text-main/70">
                  {sec.text}
                </p>
              </div>
            ))}
          </div>

          {/* Footer of modal */}
          <div className="border-t border-gold-500/10 pt-4 mt-4 flex justify-between items-center text-xs text-text-main/50">
            <span>© {new Date().getFullYear()} Jitin Goel Consulting</span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gold-500 text-brand-950 hover:bg-gold-400 font-semibold tracking-wider uppercase rounded text-[10px] transition-all hover:shadow-[0_0_15px_rgba(212,175,55,0.3)] shadow-none"
            >
              Acknowledge & Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
