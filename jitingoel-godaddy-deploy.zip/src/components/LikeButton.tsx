import React, { useState } from "react";
import { motion } from "motion/react";
import { Heart } from "lucide-react";

export function LikeButton() {
  const [liked, setLiked] = useState(false);

  const toggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLiked(!liked);
  };

  return (
    <motion.button
      type="button"
      onClick={toggleLike}
      whileTap={{ scale: 0.9 }}
      className={`flex items-center gap-2 text-xs uppercase tracking-widest transition-colors ${
        liked ? "text-red-500" : "text-text-main hover:text-red-400"
      }`}
      aria-label={liked ? "Unlike" : "Like"}
    >
      <motion.div
        animate={liked ? { scale: [1, 1.3, 1] } : { scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Heart className={`w-4 h-4 ${liked ? "fill-current" : ""}`} />
      </motion.div>
      <span className="font-semibold">{liked ? "Liked" : "Like"}</span>
    </motion.button>
  );
}
