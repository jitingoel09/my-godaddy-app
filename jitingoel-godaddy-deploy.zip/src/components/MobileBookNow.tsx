import { useState, useEffect } from "react";
import { Calendar, X, ArrowRight, TrendingUp, Briefcase, Star, Compass } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";


import { PrePaymentModal } from "./PrePaymentModal";

export function MobileBookNow() {
  const [isOpen, setIsOpen] = useState(false);
  const [prePaymentOpen, setPrePaymentOpen] = useState(false);
  const [prePaymentService, setPrePaymentService] = useState("");

  const sessionTypes = [
    { name: "Business Strategy & Growth Consulting", icon: TrendingUp },
    { name: "Career & Professional Consulting", icon: Briefcase },
    { name: "Cosmic Astrology Consultation", icon: Star },
    { name: "Personal Transformation Consulting", icon: Compass }
  ];

  const handleSelect = (type: string) => {
    setPrePaymentService(type);
    setPrePaymentOpen(true);
    setIsOpen(false);
  };

  // Keyboard accessibility: Escape closes the sheet.
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsOpen(false);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen]);

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 z-40 p-3.5 bg-brand-950/90 backdrop-blur-lg border-t border-gold-500/20 sm:hidden">
        <button
          onClick={() => setIsOpen(true)}
          className="w-full bg-gold-500 text-brand-900 py-3 rounded-full font-bold uppercase tracking-wider text-xs flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,153,51,0.3)] hover:bg-gold-400 active:scale-[0.98] active:bg-gold-600 transition-all touch-manipulation"
        >
          <Calendar className="w-4 h-4" />
          Talk to Jitin
        </button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 sm:hidden"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-brand-900 border-t border-gold-500/20 rounded-t-3xl sm:hidden flex flex-col max-h-[85vh]"
              role="dialog"
              aria-modal="true"
              aria-labelledby="mobile-book-sheet-title"
            >
              <div className="p-4 border-b border-white/5 flex justify-between items-center sticky top-0 bg-brand-900 rounded-t-3xl z-10 shrink-0">
                <h3 id="mobile-book-sheet-title" className="text-gold-400 font-bold uppercase tracking-widest text-sm flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Select Session Type
                </h3>
                <button
                  onClick={() => setIsOpen(false)}
                  aria-label="Close"
                  className="p-2 bg-brand-800 rounded-full text-text-main hover:text-gold-500 active:scale-95 active:bg-brand-700 transition-colors touch-manipulation"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-4 overflow-y-auto overscroll-contain">
                <div className="flex flex-col gap-3 pb-8">
                  {sessionTypes.map((session, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelect(session.name)}
                      className="flex items-center justify-between w-full p-4 bg-brand-800/50 hover:bg-brand-800 border border-gold-500/10 hover:border-gold-500/40 active:scale-[0.98] active:bg-brand-700 rounded-xl transition-all text-left group touch-manipulation"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-brand-950 border border-gold-500/20 flex items-center justify-center text-gold-400 group-hover:scale-110 group-hover:bg-gold-500/10 transition-all shrink-0">
                          <session.icon className="w-4 h-4" />
                        </div>
                        <span className="text-text-main text-sm font-medium pr-2">
                          {session.name}
                        </span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gold-500 opacity-100 group-hover:opacity-1000 group-hover:translate-x-1 transition-all shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      <PrePaymentModal
        isOpen={prePaymentOpen}
        onClose={() => setPrePaymentOpen(false)}
        serviceTitle={prePaymentService}
      />
    </>
  );
}
