import React, { useState, useEffect } from "react";
import { Menu, X, Search } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { GlobalSearch } from "./GlobalSearch";

// Lightweight custom scroll engine (Desktop/Laptop only — see scrollToTarget
// below). Native `scrollTo({behavior:"smooth"})` typically eases in slowly,
// which reads as a perceptible pause before any visible movement. This uses
// an ease-out curve instead, so movement is already visible on the very
// first frame, while still landing precisely on the target and decelerating
// smoothly into place.
let desktopScrollAnimationId: number | null = null;

function desktopSmoothScrollTo(targetY: number, duration = 650) {
  if (desktopScrollAnimationId !== null) {
    cancelAnimationFrame(desktopScrollAnimationId);
    desktopScrollAnimationId = null;
  }
  const startY = window.scrollY;
  const distance = targetY - startY;
  if (distance === 0) return;
  const startTime = performance.now();
  const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

  const step = (now: number) => {
    const elapsed = now - startTime;
    const t = Math.min(elapsed / duration, 1);
    window.scrollTo(0, startY + distance * easeOutCubic(t));

    if (t < 1) {
      desktopScrollAnimationId = requestAnimationFrame(step);
    } else {
      desktopScrollAnimationId = null;
    }
  };
  desktopScrollAnimationId = requestAnimationFrame(step);
}

// True single source of truth for "is the Desktop Navbar currently active":
// query the actual rendered state of the desktop-nav element itself (the
// same element gated by the Navbar's own min-[1366px] breakpoint), rather
// than maintaining a second, independent numeric threshold that could
// silently drift out of sync with that CSS breakpoint.
function isDesktopNavActive(): boolean {
  const desktopNav = document.querySelector(".navbar-menu-container");
  return !!desktopNav && getComputedStyle(desktopNav).display !== "none";
}

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Services", href: "#services" },
  { name: "Book Consultation", href: "#book" },
  { name: "Astro Calculators", href: "#interactive-tools" },
  { name: "Insights", href: "#blog" },
];

import { useRenderCountDev } from "../dev/perfInstrumentation";

export function Navbar() {
  useRenderCountDev("Navbar");
  const [isOpen, setIsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  // Lightweight active-section tracking, scoped only to nav-link highlighting
  // (the sticky navbar's white active-indicator). Uses the same section IDs
  // referenced by navLinks below; does not affect any other part of the page.
  useEffect(() => {
    const sectionIds = navLinks.map((link) => link.href.replace("#", ""));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );

    const observeSections = () => {
      sectionIds.forEach((id) => {
        const el = document.getElementById(id);
        if (el) observer.observe(el);
      });
    };
    observeSections();

    // Previously this had its own separate MutationObserver watching
    // document.body — duplicating the one already in App.tsx. Now it
    // reacts to that single, existing observer's notification instead,
    // via the same lightweight custom-event pattern already used
    // elsewhere in this file (e.g. "jg:show-booking-calendar).
    window.addEventListener("jg:sections-mutated", observeSections);

    return () => {
      observer.disconnect();
      window.removeEventListener("jg:sections-mutated", observeSections);
    };
  }, []);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    href: string,
  ) => {
    e.preventDefault();
    const targetId = href.replace("#", "");

    const scrollToTarget = () => {
      const element = document.getElementById(targetId);
      if (element) {
        const top = element.getBoundingClientRect().top + window.scrollY - 100; // Account for navbar height
        if (isDesktopNavActive()) {
          desktopSmoothScrollTo(top);
        } else {
          window.scrollTo({
            top,
            behavior: "smooth",
          });
        }
      }
    };

    // #book lives on an always-present wrapper in Services.tsx (not inside
    // the conditionally-mounted BookingCalendar), so it exists from first
    // paint — no need to wait for anything before scrolling. Still notify
    // Services.tsx to auto-dismiss its onboarding step in the background.
    if (targetId === "book") {
      window.dispatchEvent(new CustomEvent("jg:show-booking-calendar"));
    }
    scrollToTarget();
    setIsOpen(false);
    // Synchronously clear the mobile-drawer's scroll-lock right now, rather
    // than waiting for the isOpen-effect to catch up after paint — that
    // async gap was racing the rAF-scheduled scroll above, so the very
    // first tap's scroll silently no-op'd against a still-locked body.
    document.body.style.overflow = "";
  };

  return (
    <nav
      className={`fixed w-full z-[60] transition-all duration-500 flex justify-center px-2.5 sm:px-4 ${scrolled ? "py-2 sm:py-4" : "py-3 sm:py-8"}`}
    >
      <div
        className={`navbar-main-floating-capsule relative z-20 flex w-full max-w-7xl justify-between items-center gap-x-5 transition-all duration-500 ${scrolled ? "nav-sticky py-2.5 sm:py-3 px-3 sm:px-6 rounded-2xl md:rounded-full shadow-md" : "bg-transparent px-3 sm:px-6 py-2.5 sm:py-0"}`}
      >
        {/* Desktop Menu */}
        <div className="hidden min-[1366px]:flex navbar-menu-container items-center bg-brand-800/40 backdrop-blur-md px-1.5 py-1.5 rounded-full border border-gold-500/10 relative z-30 shrink">
          {navLinks.map((link) => {
            const isActive = activeSection === link.href.replace("#", "");
            return (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                aria-label={`Go to ${link.name} section`}
                aria-current={isActive ? "page" : undefined}
                className={`navbar-menu-link nav-link-item group relative px-0.5 py-2 transition-all rounded-full hover:bg-gold-500/10 ${scrolled ? "opacity-1000" : "opacity-100"} ${isActive ? "nav-link-active" : ""}`}
              >
                <span className="nav-dot inline-block w-1.5 h-1.5 rounded-full bg-gold-400 mr-1.5 opacity-0 group-hover:opacity-100 transition-opacity align-middle"></span>
                {link.name}
              </a>
            );
          })}
        </div>

        <div className="hidden min-[1366px]:flex items-center gap-3 relative z-30 shrink-0">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="text-gold-500 hover:text-gold-400 transition-colors flex items-center gap-2 bg-brand-800/40 backdrop-blur-md px-2.5 py-1.5 rounded-full border border-gold-500/20 shadow-sm"
            aria-label="Search"
            title="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          <a
            href="#book"
            onClick={(e) => handleNavClick(e, "#book")}
            aria-label="Book Consultation"
            className="start-conversation-btn text-xs xl:text-sm uppercase tracking-widest font-bold hover:bg-gold-400 hover:text-brand-900 px-5 py-2.5 rounded-full transition-all hover:shadow-[0_0_20px_-5px_rgba(251,191,36,0.5)] whitespace-nowrap shrink-0"
            style={{ backgroundColor: "rgba(214,163,96,0.8)", color: "#8B3A1D", border: "1px solid #8B3A1D" }}
          >
            Start the Conversation
          </a>
        </div>

        {/* Mobile/Tablet menu button — shown below min-[1366px] */}
        <div className="min-[1366px]:hidden flex items-center justify-end gap-1.5 sm:gap-2 relative z-30 shrink-0">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="p-1 min-[380px]:p-1.5 rounded-md text-gold-500 hover:bg-gold-500/10 active:scale-95 transition-colors touch-manipulation"
            aria-label="Search"
            title="Search"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-1 min-[380px]:p-1.5 rounded-md text-gold-500 active:scale-95 transition-all touch-manipulation ml-0.5"
            aria-expanded={isOpen}
            aria-label="Toggle navigation menu"
          >
            {isOpen ? (
              <X className="h-4 w-4 min-[380px]:h-5 min-[380px]:w-5 sm:h-6 sm:w-6" aria-hidden="true" />
            ) : (
              <Menu className="h-4 w-4 min-[380px]:h-5 min-[380px]:w-5 sm:h-6 sm:w-6" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="min-[1366px]:hidden fixed inset-0 bg-brand-950/80 backdrop-blur-sm z-[70] h-screen w-screen"
              style={{ top: 0, left: 0 }}
            />
            {/* Slide-out Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="min-[1366px]:hidden fixed top-0 right-0 h-dvh w-[85vw] max-w-[320px] bg-brand-900 border-l border-gold-500/20 shadow-2xl z-[80] flex flex-col"
            >
              <div className="flex justify-between items-center p-5 border-b border-gold-500/10 shrink-0">
                <span className="text-gold-400 font-serif text-lg tracking-widest uppercase">Menu</span>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 text-gold-500 hover:bg-brand-800 hover:text-gold-400 rounded-full transition-colors"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-6 px-4 space-y-2 min-h-0">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    aria-label={`Go to ${link.name} section`}
                    className="navbar-menu-link block px-4 py-4 hover:bg-brand-800 active:scale-[0.98] transition-all rounded-lg touch-manipulation"
                  >
                    {link.name}
                  </a>
                ))}
              </div>

              <div
                className="p-5 border-t border-gold-500/10 bg-brand-950/50 shrink-0"
                style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}
              >
                <a
                  href="#book"
                  onClick={(e) => handleNavClick(e, "#book")}
                  aria-label="Book Consultation"
                  className="block w-full text-center px-4 py-4 text-xs font-bold uppercase tracking-[0.2em] rounded-full text-brand-900 bg-gold-400 hover:bg-gold-500 active:scale-[0.98] shadow-lg shadow-gold-500/20 transition-all touch-manipulation"
                >
                  Start the Conversation
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <GlobalSearch isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </nav>
  );
}
