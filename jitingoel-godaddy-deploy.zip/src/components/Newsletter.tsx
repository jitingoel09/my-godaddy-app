import { motion } from "motion/react";
import { Mail, ArrowUpRight } from "lucide-react";

export function Newsletter() {
  return (
    <section id="newsletter" className="py-14 bg-page-bg-800 border-t border-gold-500/10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-between gap-5 bg-brand-900/50 border border-gold-500/15 rounded-2xl px-6 sm:px-8 py-6"
        >
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-11 h-11 rounded-full bg-[#8B3005] border border-gold-500/30 flex items-center justify-center shrink-0 hidden sm:flex">
              <Mail className="w-5 h-5 text-gold-400" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-serif font-semibold text-text-main mb-1">
                Strategic Insights on Business, Professional Direction &amp; Vedic Timing
              </h3>
              <p className="text-xs text-text-main/60">Occasional notes, direct from Jitin — no spam.</p>
            </div>
          </div>
          <a
            href="https://jitin.beehiiv.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 bg-gold-500 text-brand-900 text-xs font-bold uppercase tracking-wider px-6 py-3 rounded-full hover:bg-gold-400 transition-all whitespace-nowrap"
          >
            Subscribe
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
