import { useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, MessageCircle, Mail } from "lucide-react";
import { safeOpenLink } from "../utils/navigation";

interface PrePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceTitle?: string;
}

export function PrePaymentModal({ isOpen, onClose, serviceTitle }: PrePaymentModalProps) {
  // Keyboard accessibility: Escape closes the modal.
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen, onClose]);

  const handleWhatsApp = () => {
    const message = "Hello Jitin, I would like to schedule a private alignment session for my roadmap.";
    safeOpenLink(`https://wa.me/918796578959?text=${encodeURIComponent(message)}`);
    onClose();
  };

  const handleEmail = () => {
    const subject = encodeURIComponent(`NDA & Proposal Request${serviceTitle ? ` — ${serviceTitle}` : ""}`);
    const body = encodeURIComponent("Hello Jitin,\n\nI would like to request an NDA and a proposal for a private consultation.\n\nRegards,");
    safeOpenLink(`mailto:jitin09@jitingoel.com?subject=${subject}&body=${body}`);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.4, ease: [0.25, 1, 0.5, 1] }}
            className="relative bg-[#23120A] border border-gold-500/25 rounded-2xl max-w-md w-full p-7 sm:p-8 shadow-2xl"
            role="dialog"
            aria-modal="true"
            aria-labelledby="prepayment-modal-title"
          >
            <button
              onClick={onClose}
              aria-label="Close"
              className="absolute top-4 right-4 text-[#FFF5EB]/50 hover:text-[#FFF5EB] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 id="prepayment-modal-title" className="text-xl sm:text-2xl font-serif font-bold text-gold-400 mb-4 pr-6">
              Initiating Private Calibration
            </h3>
            <p className="text-sm text-[#FFF5EB]/80 leading-relaxed mb-7">
              To maintain strict confidentiality and bespoke formatting, we are currently scheduling all high-ticket engagements manually through the Founder's desk. No immediate payment is required online today.
            </p>

            <div className="space-y-3">
              <button
                onClick={handleWhatsApp}
                className="w-full flex items-center justify-center gap-2 bg-gold-500 text-brand-900 text-xs sm:text-sm uppercase tracking-widest font-bold px-6 py-3.5 rounded-full hover:bg-gold-400 transition-all duration-300"
              >
                <MessageCircle className="w-4 h-4" />
                Secure Priority Slot via WhatsApp
              </button>
              <button
                onClick={handleEmail}
                className="w-full flex items-center justify-center gap-2 bg-transparent border border-gold-500/40 text-gold-400 text-xs sm:text-sm uppercase tracking-widest font-bold px-6 py-3.5 rounded-full hover:bg-gold-500/10 transition-all duration-300"
              >
                <Mail className="w-4 h-4" />
                Request NDA &amp; Proposal via Email
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
