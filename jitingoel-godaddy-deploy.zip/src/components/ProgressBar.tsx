import { useEffect, useRef, useState } from "react";

import { useRenderCountDev } from "../dev/perfInstrumentation";

export function ProgressBar() {
  useRenderCountDev("ProgressBar");
  const [scrollProgress, setScrollProgress] = useState(0);
  const tickingRef = useRef(false);

  useEffect(() => {
    const computeProgress = () => {
      const scrollTop = window.scrollY;
      const docHeight =
        document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(docHeight > 0 ? (scrollTop / docHeight) * 100 : 0);
      tickingRef.current = false;
    };

    const handleScroll = () => {
      if (!tickingRef.current) {
        tickingRef.current = true;
        requestAnimationFrame(computeProgress);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    computeProgress(); // Init

    // Also handle resize to recalculate document height properly
    window.addEventListener("resize", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  return (
    <div className="fixed top-0 left-0 w-full h-[3px] bg-brand-800/30 z-[60] pointer-events-none">
      <div
        className="h-full bg-gold-500 origin-left transition-transform duration-100 ease-out shadow-[0_0_10px_rgba(197,160,89,0.5)]"
        style={{ transform: `scaleX(${scrollProgress / 100})` }}
      />
    </div>
  );
}
