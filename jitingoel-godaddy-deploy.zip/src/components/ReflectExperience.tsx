import { motion } from "motion/react";
import experienceImg from "../assets/images/indian_leadership_1780754707869.webp";

const reflections = [
  "Business growth has slowed despite continued effort.",
  "A major decision feels strategically right, but the timing feels uncertain.",
  "Career direction doesn't feel as clear as it used to.",
  "Professional success is creating personal imbalance.",
  "The same patterns keep repeating, in business or in life.",
  "Multiple options exist, but the right direction isn't obvious.",
];

export function ReflectExperience() {
  return (
    <section id="reflect" className="experience-timeline-bg py-16 bg-page-bg-800 relative border-t border-gold-500/20 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.08] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${experienceImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-800 via-transparent to-page-bg-800 pointer-events-none"></div>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-10">
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
            Reflect on Your Experience
          </h2>
          <h3 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">
            Has the Experience Been Good — Or Just Average?
          </h3>
          <p className="text-sm sm:text-base text-text-main/70 max-w-2xl mx-auto leading-relaxed">
            Sometimes the issue isn't a lack of effort. A few situations worth sitting with:
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          {reflections.map((r, i) => (
            <motion.div
              key={r}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="flex items-start gap-3 bg-brand-900/40 border border-gold-500/10 rounded-lg px-4 py-3.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-gold-500 mt-1.5 shrink-0"></span>
              <p className="text-sm text-text-main/85 leading-relaxed">{r}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
