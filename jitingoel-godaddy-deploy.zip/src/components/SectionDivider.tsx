import { DimensionsTicker } from "./DimensionsTicker";

export function SectionDivider() {
  return (
    <div className="my-8">
      <DimensionsTicker />
    </div>
  );
}
