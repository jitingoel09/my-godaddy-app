import { motion, AnimatePresence } from "motion/react";
import {
  Target,
  Users,
  BrainCircuit,
  Star,
  ArrowRight,
  TrendingUp,
  Map,
  Award,
  Compass,
  User,
  Zap,
  Shield,
  RefreshCw,
  Smile,
  Trophy,
  Heart,
  DollarSign,
  Clock,
  FileText,
} from "lucide-react";
import { LikeButton } from "./LikeButton";
import { servicesImages } from "../utils/imageRegistry";
import personalReflectionImg from "../assets/images/personal_transformation_quartz.webp";
import businessCrossroadsImg from "../assets/images/business_growth_gold_veins.webp";
import professionalCrossroadsImg from "../assets/images/career_executive_suit.webp";
import { DirectLineBadge } from "./DirectLineBadge";
import { PrePaymentModal } from "./PrePaymentModal";

import { useState, useEffect } from "react";
import { BookingCalendar } from "./BookingCalendar";

const services = [
  {
    title: "Business Strategy & Growth Consulting",
    subtitle: "For businesses where effort is no longer translating into growth.",
    icon: Target,
    image: businessCrossroadsImg,
    description:
      <>Growth stalls when the real bottleneck stays hidden. <strong className="text-gold-400 font-semibold">I find it, then build your roadmap</strong> — distribution, sales systems, or operations, whatever's actually blocking you. A business bottleneck often shows up as professional pressure too.</>,
    features: [
      { text: "Ideal for: Founders, MSMEs & Growing Enterprises", icon: User },
      { text: "Core Challenge: Growth Plateaus & Hidden Bottlenecks", icon: Zap },
      { text: "My Approach: Structural Diagnostic & Sequenced Roadmap", icon: Map },
      { text: "Outcome: Predictable, Sustainable Revenue Growth", icon: TrendingUp },
    ],
    diagnostic: "Signs we need to talk: Your team is working harder but margins are shrinking; you're hesitating on a major expansion decision.",
  },
  {
    title: "Career & Professional Consulting",
    subtitle: "For professionals whose capability has outgrown their positioning.",
    icon: Users,
    image: professionalCrossroadsImg,
    description:
      <>Careers stall from unclear positioning, not low capability. <strong className="text-gold-400 font-semibold">I rebuild your narrative, resume, and interview approach</strong> — so the right opportunities finally notice you. A career transition often reshapes personal direction as well.</>,
    features: [
      { text: "Ideal for: Professionals, Managers & Senior Leaders", icon: Shield },
      { text: "Core Challenge: Career Plateaus & Unclear Positioning", icon: RefreshCw },
      { text: "My Approach: Targeted Professional Brand Strategy", icon: Award },
      { text: "Outcome: Converted Opportunities & Career Momentum", icon: Trophy },
    ],
    diagnostic: "Signs we need to talk: You've been in the same leadership bracket for 3+ years; headhunters aren't reaching out for the right roles.",
  },
  {
    title: "Personal Transformation Consulting",
    subtitle: "For high-performers with outer success but limited inner clarity.",
    icon: BrainCircuit,
    image: personalReflectionImg,
    description:
      <>Feeling stuck isn't a motivation problem — it's misalignment between your values and daily actions. <strong className="text-gold-400 font-semibold">I rebuild your decision-making around real clarity</strong>, not inherited habits. These patterns usually surface in business and career decisions too.</>,
    features: [
      { text: "Ideal for: High-Performers Seeking Clarity", icon: Compass },
      { text: "Core Challenge: Self-Doubt & Repeating Patterns", icon: Heart },
      { text: "My Approach: Structured Clarity & Mindset Framework", icon: BrainCircuit },
      { text: "Outcome: Confident Decisions & Lasting Alignment", icon: Smile },
    ],
    diagnostic: "Signs we need to talk: High revenue but high burnout; you're second-guessing decisions you used to make in seconds.",
  },
  {
    title: "Cosmic Astrology Consultation",
    subtitle: "For decision-makers who want every advantage before a major move.",
    icon: Star,
    image: servicesImages.vedicAstrology,
    description:
      <>Big decisions carry more risk without the right timing. <strong className="text-gold-400 font-semibold">I read your chart for timing and strengths</strong> — informing your next move, never dictating it. Useful alongside any business, career, or personal decision.</>,
    features: [
      { text: "Ideal for: Decision-Makers & Business Owners", icon: Star },
      { text: "Core Challenge: Uncertain Timing & Decision Risk", icon: Clock },
      { text: "My Approach: Vedic Chart Analysis & Decision Support", icon: FileText },
      { text: "Outcome: Informed Timing & Confident Decisions", icon: DollarSign },
    ],
  },
];

export function Services() {
  const [selectedService, setSelectedService] = useState<string>("");
  const [showBookingOnboarding, setShowBookingOnboarding] = useState(true);
  const [prePaymentModalOpen, setPrePaymentModalOpen] = useState(false);
  const [prePaymentServiceTitle, setPrePaymentServiceTitle] = useState("");
  const [instantReveal, setInstantReveal] = useState(false);

  // The navbar's "Consultation Planner" / "Start the Conversation" links point
  // to #book, but that element only exists once the onboarding step below is
  // dismissed. AnimatePresence's mode="wait" normally holds #book out of the
  // DOM until the onboarding card's ~0.5s exit-animation finishes, which is
  // exactly the felt delay the navbar click needs to avoid — so this path
  // also flags instantReveal, collapsing that transition to 0 duration only
  // for this trigger. The organic in-page "Continue to Calendar" button
  // (below) never sets this flag, so it keeps its normal animated transition.
  useEffect(() => {
    const handler = () => {
      setInstantReveal(true);
      setShowBookingOnboarding(false);
    };
    window.addEventListener("jg:show-booking-calendar", handler);
    return () => window.removeEventListener("jg:show-booking-calendar", handler);
  }, []);

  const handleBookNow = (title: string) => {
    setPrePaymentServiceTitle(title);
    setPrePaymentModalOpen(true);
  };

  return (
    <section
      id="services"
      className="py-14 bg-page-bg-900 relative border-t border-gold-500/20 overflow-hidden"
    >
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjUpIi8+CjxjaXJjbGUgY3g9IjcwIiBjeT0iMTUiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIxMTAiIGN5PSI1NSIgcj0iMS4yIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNCkiLz4KPGNpcmNsZSBjeD0iMTUwIiBjeT0iMjAiIHI9IjAuNiIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjE4MCIgY3k9IjcwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNDUpIi8+CjxjaXJjbGUgY3g9IjQwIiBjeT0iOTAiIHI9IjAuOCIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjkwIiBjeT0iMTEwIiByPSIxLjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8Y2lyY2xlIGN4PSIxNDAiIGN5PSIxMzAiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIyMCIgY3k9IjE1MCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjQpIi8+CjxjaXJjbGUgY3g9IjE3MCIgY3k9IjE2MCIgcj0iMC45IiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuMzUpIi8+CjxjaXJjbGUgY3g9IjYwIiBjeT0iMTgwIiByPSIwLjYiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC4zKSIvPgo8Y2lyY2xlIGN4PSIxMjAiIGN5PSIxODUiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8L3N2Zz4=')] opacity-40 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 sm:py-10 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
          >
            <h3 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-2 rounded-full inline-block border border-gold-500/30 font-bold">
              Consulting Practice Areas
            </h3>
            <h2 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif mb-6 font-bold">
              No Templates. <span className="gold-underline">No Junior Handoffs.</span>
            </h2>
            <p className="text-lg text-text-main/90 leading-relaxed max-w-2xl mx-auto font-normal">
              I start with your specific problem, not a generic framework. You work directly with me, one-on-one — across business growth, career direction, personal clarity, and astrological decision-support.
            </p>
          </motion.div>
        </div>

        {/* Interconnection visual — shows the 4 areas as one connected system */}
        <div className="relative max-w-4xl mx-auto mb-16 px-4">
          <div className="hidden sm:block absolute top-6 left-[12.5%] right-[12.5%] h-px bg-gradient-to-r from-gold-500/10 via-gold-500/50 to-gold-500/10"></div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-2 relative">
            {["Business", "Career", "Personal", "Timing"].map((label) => (
              <div key={label} className="flex flex-col items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gold-500 border-2 border-brand-900 shadow-[0_0_10px_rgba(255,153,51,0.6)]"></div>
                <span className="text-[10px] sm:text-xs uppercase tracking-widest text-gold-400/80 font-mono font-bold">{label}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-xs sm:text-sm text-text-main/60 italic mt-4">
            One decision moves through all four — I look at the complete picture, not one piece in isolation.
          </p>
          <p className="text-center text-xs sm:text-sm text-gold-400/80 mt-3 max-w-2xl mx-auto">
            No pre-packaged solutions — every engagement is built case-by-case, person-to-person, company-to-company. For businesses, that means I stay engaged for the long haul, through the full project; for individuals, I stay with you until you see real results, not just a single session.
          </p>
        </div>

        {/* Continuous ticker — the 4 dimensions flowing as one connected system */}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:[&>*:nth-child(4)]:col-start-2">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              id={service.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-55px" }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: index * 0.1 }}
              className="relative overflow-hidden p-6 sm:p-8 border border-gold-500/10 bg-brand-900 hover:bg-brand-800 transition-all duration-500 ease-out group flex flex-col h-full rounded-2xl hover:-translate-y-2 hover:scale-[1.02] shadow-[0_20px_40px_rgba(0,0,0,0.25)] hover:shadow-[0_0_40px_-10px_rgba(197,160,89,0.4)] hover:border-gold-500/50 focus-within:ring-2 focus-within:ring-gold-500"
            >
              {/* Soft golden glow effect background */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-1000 transition-opacity duration-700 pointer-events-none bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gold-500/10 via-transparent to-transparent blur-xl"></div>
              
              <div className="absolute inset-0 bg-gradient-to-br from-gold-500/10 to-transparent opacity-0 group-hover:opacity-1000 transition-opacity duration-500 pointer-events-none"></div>
              
              {/* Service Visual Representation with Float Custom Icon Medal */}
              <div className="w-full h-44 rounded-xl overflow-hidden mb-6 border border-gold-500/10 relative shrink-0">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className={`offering-card-0${index + 1}-img w-full h-full object-cover opacity-100 transition-transform duration-700 group-hover:scale-105 group-hover:opacity-1000`} 
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#6F2604] via-transparent to-transparent"></div>
                <div className="absolute bottom-3 right-3 p-2.5 rounded-full bg-brand-950/90 border border-gold-500/30 text-gold-400 shadow-lg backdrop-blur-sm group-hover:scale-110 group-hover:bg-[#8B3005] group-hover:text-white transition-all duration-300">
                  <service.icon className="h-5 w-5" />
                </div>
              </div>

              <div>
                <span className="offering-badge text-[10px] mb-4 flex items-center justify-between">
                  <span className="bg-gold-500/10 px-2.5 py-0.5 rounded border border-gold-500/20">Offering 0{index + 1}</span>
                  <span className="text-[9px] text-text-main/55 font-mono normal-case tracking-normal font-normal">Tailored to You</span>
                </span>
                <h4 className="text-xl font-serif text-text-main mb-2 font-bold group-hover:text-gold-400 transition-colors duration-300">
                  {service.title}
                </h4>
                <p className="text-xs italic text-gold-500/70 mb-3 leading-snug">
                  {service.subtitle}
                </p>
              </div>

              <p className="card-description text-sm mb-6">
                {service.description}
              </p>

              <ul className="space-y-3 mb-8 flex-grow">
                {service.features.slice(0, 4).map((feature, idx) => {
                  const FeatureIcon = feature.icon;
                  return (
                    <li
                      key={idx}
                      className="flex items-start text-sm text-text-main/90 group-hover:text-text-main transition-colors duration-200"
                    >
                      <FeatureIcon className="w-4 h-4 mt-0.5 mr-3 text-gold-500/80 group-hover:text-gold-400 group-hover:scale-110 flex-shrink-0 transition-all duration-300" />
                      <span>{feature.text}</span>
                    </li>
                  );
                })}
              </ul>

              {service.diagnostic && (
                <p className="text-xs font-bold text-gold-400/90 bg-brand-950/40 border-l-2 border-gold-500/50 pl-3 py-2 mb-4 leading-relaxed">
                  {service.diagnostic}
                </p>
              )}

              <div className="flex items-center justify-between mt-auto pt-4 border-t border-gold-500/10">
                <LikeButton />
                <button
                  onClick={() => handleBookNow(service.title)}
                  aria-label={`Book a consultation for ${service.title}`}
                  className="inline-flex flex-row items-center text-xs uppercase tracking-widest font-bold text-gold-500 hover:text-gold-400 transition-colors focus:outline-none"
                >
                  Solve This With Me{" "}
                  <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center max-w-4xl mx-auto">
          <p className="text-xs text-text-main opacity-100 italic">
            Disclaimer: Astrology consultations are intended for guidance and
            self-reflection and should not replace professional financial,
            legal, medical, or psychological advice.
          </p>
        </div>

        {/* Integrated Unified Scheduler Frame */}
        <div id="book" className="mt-20 border-t border-gold-500/15 pt-12">
          <AnimatePresence mode="wait">
            {showBookingOnboarding ? (
              <motion.div
                key="onboarding"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: instantReveal ? 0 : 0.5, ease: [0.65, 0, 0.35, 1] }}
                className="max-w-xl mx-auto text-center bg-brand-900/60 border border-gold-500/25 rounded-2xl px-6 sm:px-10 py-10 shadow-[0_0_50px_-20px_rgba(255,153,51,0.3)]"
              >
                <span className="text-[10px] uppercase tracking-widest font-mono font-bold text-gold-500/70">
                  Before You Book
                </span>
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-text-main mt-2 mb-4">
                  Let's Find Your Right Moment
                </h3>
                <p className="text-sm text-text-main/70 leading-relaxed mb-7">
                  A quick step before the calendar — this helps me understand the context of your situation, so the session starts with clarity, not small talk.
                </p>
                <button
                  onClick={() => setShowBookingOnboarding(false)}
                  className="inline-flex items-center gap-2 bg-gold-500 text-brand-900 text-xs uppercase tracking-widest font-bold px-7 py-3.5 rounded-full hover:bg-gold-400 transition-all duration-500"
                  style={{ transitionTimingFunction: "cubic-bezier(0.65, 0, 0.35, 1)" }}
                >
                  Continue to Calendar
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="calendar"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: instantReveal ? 0 : 0.5, ease: [0.65, 0, 0.35, 1] }}
              >
                <BookingCalendar 
                  selectedService={selectedService} 
                  setSelectedService={setSelectedService} 
                />
              </motion.div>
            )}
          </AnimatePresence>
          <div className="mt-10">
            <DirectLineBadge />
          </div>
        </div>
      </div>
      <PrePaymentModal
        isOpen={prePaymentModalOpen}
        onClose={() => setPrePaymentModalOpen(false)}
        serviceTitle={prePaymentServiceTitle}
      />
    </section>
  );
}
