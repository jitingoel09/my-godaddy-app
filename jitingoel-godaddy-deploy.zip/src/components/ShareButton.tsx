import { useState, useEffect, useRef } from "react";
import { Share2, Check, Copy, MessageCircle, Mail, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { safeOpenLink } from "../utils/navigation";

export function ShareButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsVisible(true);
    
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const shareData = {
    title: "Jitin - Business Consulting & Vedic Astrology",
    text: "Explore Jitin's insights on business strategy and Vedic wisdom.",
    url: window.location.href,
  };

  const handleNativeShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        setIsOpen(false);
      }
    } catch (err) {
      console.error("Error sharing:", err);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareData.url);
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
        setIsOpen(false);
      }, 2000);
    } catch (err) {
      console.error("Clipboard copy failed", err);
    }
  };

  const handleWhatsApp = () => {
    const text = `${shareData.title}\n${shareData.text}\n${shareData.url}`;
    safeOpenLink(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`);
    setIsOpen(false);
  };

  const handleEmail = () => {
    const subject = shareData.title;
    const body = `${shareData.text}\n\n${shareData.url}`;
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, "_self");
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed bottom-[102px] sm:bottom-6 left-6 z-[9999] w-[52px] h-[52px] flex flex-col items-center justify-end"
          ref={menuRef}
        >
          <AnimatePresence>
            {copied && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.9 }}
                className="bg-brand-800 text-gold-400 text-[10px] uppercase font-bold tracking-widest px-3 py-1.5 rounded-full border border-gold-400/20 shadow-lg absolute -top-12 whitespace-nowrap"
              >
                Link Copied!
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                className="absolute bottom-16 left-0 mb-2 w-48 bg-brand-800 border border-gold-400/20 rounded-2xl shadow-2xl overflow-hidden origin-bottom-left"
              >
                <div className="bg-brand-900 border-b border-white/5 p-3 flex justify-between items-center">
                  <h3 className="text-gold-400 text-[10px] uppercase font-bold tracking-widest">Share via</h3>
                  <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white">
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <div className="py-2">
                  <button onClick={handleWhatsApp} className="w-full text-left px-4 py-2.5 text-sm text-text-main hover:bg-brand-700 hover:text-gold-400 transition-colors flex items-center gap-3">
                    <MessageCircle className="w-4 h-4 text-[#25D366]" /> WhatsApp
                  </button>
                  <button onClick={handleEmail} className="w-full text-left px-4 py-2.5 text-sm text-text-main hover:bg-brand-700 hover:text-gold-400 transition-colors flex items-center gap-3">
                    <Mail className="w-4 h-4 text-gold-400" /> Email
                  </button>
                  <button onClick={handleCopy} className="w-full text-left px-4 py-2.5 text-sm text-text-main hover:bg-brand-700 hover:text-gold-400 transition-colors flex items-center gap-3">
                    <Copy className="w-4 h-4 text-gray-300" /> Copy Link
                  </button>
                  {navigator.share && (
                    <button onClick={handleNativeShare} className="w-full text-left px-4 py-2.5 text-sm text-text-main hover:bg-brand-700 hover:text-gold-400 transition-colors flex items-center gap-3 border-t border-white/5 mt-1 pt-3">
                      <Share2 className="w-4 h-4 text-gold-400" /> More Options
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="floating-control-widget share-toggle-btn group"
            aria-label="Share this website"
            title="Share this website"
            aria-expanded={isOpen}
          >
            {copied ? (
              <Check className="w-5 h-5" />
            ) : isOpen ? (
              <X className="w-5 h-5 group-hover:scale-110 transition-transform" />
            ) : (
              <Share2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
            )}
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
