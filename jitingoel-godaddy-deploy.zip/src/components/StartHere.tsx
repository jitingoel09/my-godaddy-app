import React from "react";
import { motion } from "motion/react";
import { TrendingUp, Briefcase, Compass, Star, ArrowRight } from "lucide-react";
import spiritualImg from "../assets/images/spiritual_foundations_1781004409995.webp";

const paths = [
  { icon: TrendingUp, label: "My Business Needs Direction", href: "#services" },
  { icon: Briefcase, label: "My Career Needs Clarity", href: "#services" },
  { icon: Compass, label: "I Need Personal Transformation", href: "#services" },
  { icon: Star, label: "I Need Vedic Timing Insight", href: "#interactive-tools" },
];

export function StartHere() {
  const handleClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="start-here" className="py-16 bg-page-bg-900 relative border-t border-gold-500/20 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.07] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${spiritualImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-900 via-transparent to-page-bg-900 pointer-events-none"></div>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-10">
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
            Start Here
          </h2>
          <h3 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight">
            Where Do You Need Clarity?
          </h3>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          {paths.map((p, i) => (
            <motion.a
              key={p.label}
              href={p.href}
              onClick={(e) => handleClick(e, p.href)}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45, delay: i * 0.06 }}
              className="group flex items-center justify-between gap-4 bg-brand-800/40 border border-gold-500/15 rounded-xl px-5 py-4 hover:border-gold-500/50 hover:bg-brand-800/70 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <p.icon className="w-5 h-5 text-gold-400 shrink-0" />
                <span className="text-sm font-semibold text-text-main">{p.label}</span>
              </div>
              <ArrowRight className="w-4 h-4 text-gold-500/60 shrink-0 group-hover:translate-x-1 group-hover:text-gold-400 transition-all" />
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
