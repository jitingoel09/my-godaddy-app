import { motion } from "motion/react";
import { Star, Briefcase } from "lucide-react";
import compassImg from "../assets/images/compass_strategy_timing.webp";
import distinctionTextureImg from "../assets/images/strategic_distinction_texture.webp";

export function StrategyWisdomBand() {
  return (
    <section className="py-12 sm:py-14 bg-page-bg-900 border-t border-b border-gold-500/10 overflow-hidden relative">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-[0.02] pointer-events-none"
        style={{ backgroundImage: `url(${distinctionTextureImg})` }}
      ></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="order-2 lg:order-1 philosophy-split-image"
          >
            <div className="relative rounded-2xl overflow-hidden border border-gold-500/20 shadow-2xl h-[280px] sm:h-[360px] lg:h-[420px]">
              <img
                src={compassImg}
                alt="Vintage brass compass symbolizing strategic timing and direction"
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#4D1A03]/70 via-transparent to-transparent"></div>
              <div className="absolute bottom-5 left-5 right-5 flex items-center gap-2 text-[#FFF6EC]">
                <Star className="w-4 h-4" />
                <span className="text-[10px] uppercase tracking-widest font-mono font-bold">Strategy, Timed with Vedic Precision</span>
              </div>
            </div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="order-1 lg:order-2"
          >
            <h2 className="text-xs sm:text-sm uppercase tracking-widest text-white mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
              Where Wisdom Meets Strategy
            </h2>
            <h3 className="section-title text-3xl sm:text-4xl font-serif mb-5 font-bold">
              Two Disciplines, One Decision
            </h3>
            <p className="text-base text-text-main/90 leading-relaxed mb-5">
              Every major business decision has both a strategic dimension and a timing dimension. Most advisors offer one. I bring both — Vedic timing intelligence alongside two decades of real corporate experience.
            </p>
            <div className="flex items-center gap-6 mb-5 pb-5 border-b border-gold-500/10">
              <div>
                <div className="text-2xl sm:text-3xl font-serif text-gold-400 font-bold">20+</div>
                <div className="text-[10px] uppercase tracking-wider text-text-main/60 font-mono">Years Corporate Leadership</div>
              </div>
              <div className="w-px h-10 bg-gold-500/20"></div>
              <div>
                <div className="text-2xl sm:text-3xl font-serif text-gold-400 font-bold">26</div>
                <div className="text-[10px] uppercase tracking-wider text-text-main/60 font-mono">Years Vedic Astrology Study</div>
              </div>
            </div>
            <div className="flex items-center gap-3 text-sm text-gold-400 font-medium">
              <Briefcase className="w-4 h-4 shrink-0" />
              <span>Two disciplines. One interconnected perspective.</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
