import { motion } from "motion/react";
import { CheckCircle2, XCircle, Gem } from "lucide-react";
import { valuePropImages } from "../utils/imageRegistry";
import valuePropFallbackImg from "../assets/images/abstract_architecture_helix.webp";

export function ValueProposition() {
  return (
    <section className="py-14 bg-page-bg-900 relative border-y border-gold-500/10 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-gold-500/10 via-brand-900 to-brand-950 pointer-events-none"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjUpIi8+CjxjaXJjbGUgY3g9IjcwIiBjeT0iMTUiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIxMTAiIGN5PSI1NSIgcj0iMS4yIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNCkiLz4KPGNpcmNsZSBjeD0iMTUwIiBjeT0iMjAiIHI9IjAuNiIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjE4MCIgY3k9IjcwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuNDUpIi8+CjxjaXJjbGUgY3g9IjQwIiBjeT0iOTAiIHI9IjAuOCIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjMpIi8+CjxjaXJjbGUgY3g9IjkwIiBjeT0iMTEwIiByPSIxLjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8Y2lyY2xlIGN4PSIxNDAiIGN5PSIxMzAiIHI9IjAuNyIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjM1KSIvPgo8Y2lyY2xlIGN4PSIyMCIgY3k9IjE1MCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjAwLDE0MCwwLjQpIi8+CjxjaXJjbGUgY3g9IjE3MCIgY3k9IjE2MCIgcj0iMC45IiBmaWxsPSJyZ2JhKDI1NSwyMDAsMTQwLDAuMzUpIi8+CjxjaXJjbGUgY3g9IjYwIiBjeT0iMTgwIiByPSIwLjYiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC4zKSIvPgo8Y2lyY2xlIGN4PSIxMjAiIGN5PSIxODUiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDIwMCwxNDAsMC40KSIvPgo8L3N2Zz4=')] opacity-50 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-10 bg-gradient-to-r from-[#4E1A03] via-[#752602] to-[#4E1A03] border border-gold-500/25 px-6 sm:px-10 py-8 sm:py-10 rounded-2xl sm:rounded-3xl shadow-xl shadow-black/40 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
          >
            <h2 className="inline-block px-5 py-2 rounded-full border border-gold-500/30 bg-[#8B3005] text-xs sm:text-sm uppercase tracking-[0.25em] text-white font-bold mb-4 font-mono backdrop-blur-sm">
              The Strategic Distinction
            </h2>
            <h3 className="text-2xl md:text-4xl font-serif text-gold-400 mb-4 leading-snug drop-shadow-md font-bold">
              Why Choose Jitin Goel Consulting?
            </h3>
            <p className="text-sm sm:text-base text-text-main/90 leading-relaxed font-normal">
              Most consulting firms offer textbook theory. Most spiritual advisors lack commercial grounding. I see business, career, and personal decisions as one connected system — and add Vedic timing as the missing layer.
            </p>
          </motion.div>
        </div>

        {/* Single Unified Frame - Space-Efficient & Perfectly Divided */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
          className="bg-brand-900 border border-gold-500/20 rounded-2xl overflow-hidden shadow-2xl relative"
          id="unfair-advantage-frame"
        >
          {/* Subtle decorative elements for the frame */}
          <div className="absolute top-0 left-0 w-32 h-32 bg-gray-500/5 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 right-0 w-48 h-48 bg-gold-500/5 rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-gold-500/20 relative z-10">
            
            {/* Left Part: Standard Market Approach */}
            <div className="p-5 sm:p-7 flex flex-col justify-between bg-brand-950/20">
              <div>
                <div className="flex flex-row items-center justify-between gap-2 mb-4 border-b border-white/5 pb-3">
                  <h4 className="text-lg sm:text-xl font-serif text-text-main font-medium">
                    Standard Market Pitfalls
                  </h4>
                  <div>
                    <span className="text-[9px] uppercase tracking-widest bg-white/5 px-2.5 py-0.5 rounded-full text-text-main font-mono">Common</span>
                  </div>
                </div>

                {/* Condensed Visual banner for standard market approach */}
                <div className="w-full h-28 rounded-lg overflow-hidden mb-5 border border-gray-500/10 relative">
                  <img 
                    src={valuePropImages.standardApproach} 
                    alt="Standard Textbook Corporate Approach" 
                    className="w-full h-full object-cover opacity-100 grayscale" 
                    referrerPolicy="no-referrer"
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLImageElement).src = valuePropFallbackImg; }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#4D1A03] via-transparent to-transparent"></div>
                  <div className="absolute top-2 left-2 bg-gray-900 border border-gray-500/30 text-gray-400 text-[8px] uppercase tracking-widest px-2 py-0.5 rounded font-mono">
                    Fragmented
                  </div>
                </div>

                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <XCircle className="w-5 h-5 shrink-0 text-gray-500/50 mt-0.5" />
                    <div>
                      <p className="font-medium text-text-main text-sm mb-0.5">Consultants Who Haven't Scaled Businesses</p>
                      <p className="text-xs text-text-main/80 font-normal leading-relaxed">Advisors who've <strong className="text-text-main font-semibold">never managed a real P&L</strong> — advice without ever meeting payroll.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <XCircle className="w-5 h-5 shrink-0 text-gray-500/50 mt-0.5" />
                    <div>
                      <p className="font-medium text-text-main text-sm mb-0.5">Passive Career Guidance</p>
                      <p className="text-xs text-text-main/80 font-normal leading-relaxed">Generic resume tweaks with <strong className="text-text-main font-semibold">no real positioning strategy</strong> for your next leadership role.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <XCircle className="w-5 h-5 shrink-0 text-gray-500/50 mt-0.5" />
                    <div>
                      <p className="font-medium text-text-main text-sm mb-0.5">Generic Pep Talks</p>
                      <p className="text-xs text-text-main/80 font-normal leading-relaxed">Motivational quotes and quick-fixes that <strong className="text-text-main font-semibold">never address the real pattern</strong> behind your stress or self-doubt.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <XCircle className="w-5 h-5 shrink-0 text-gray-500/50 mt-0.5" />
                    <div>
                      <p className="font-medium text-text-main text-sm mb-0.5">Fear-Based Astrological Claims</p>
                      <p className="text-xs text-text-main/80 font-normal leading-relaxed">Predictions designed to <strong className="text-text-main font-semibold">scare you into dependency</strong> — not give you real clarity for your next decision.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>

            {/* Right Part: Jitin Goel Edge */}
            <div className="p-5 sm:p-7 flex flex-col justify-between bg-brand-800/10 relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gold-500/5 rounded-full blur-3xl pointer-events-none"></div>
              
              <div>
                <div className="flex flex-row items-center justify-between gap-2 mb-4 border-b border-gold-500/20 pb-3">
                  <h4 className="text-lg sm:text-xl font-serif text-gold-400 font-medium flex items-center gap-2">
                    <Gem className="w-5 h-5 text-gold-500 animate-pulse" /> The Jitin Goel Edge
                  </h4>
                  <div>
                    <span className="text-[9px] uppercase tracking-[0.15em] bg-gold-500/15 border border-gold-500/30 text-gold-400 px-2.5 py-0.5 rounded-full font-bold font-mono">
                      Real-World Tested
                    </span>
                  </div>
                </div>

                {/* Condensed Visual banner for Jitin Goel Edge */}
                <div className="w-full h-28 rounded-lg overflow-hidden mb-5 border border-gold-500/30 relative shadow-[0_0_15px_rgba(197,160,89,0.1)] group/edge">
                  <img 
                    src={valuePropImages.jitinGoelEdge} 
                    alt="Jitin Goel - Business Strategy and Vedic Timing Expertise" 
                    className="w-full h-full object-cover opacity-100 transition-transform duration-700 group-hover/edge:scale-105" 
                    referrerPolicy="no-referrer"
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLImageElement).src = valuePropFallbackImg; }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#6F2604] via-transparent to-transparent"></div>
                  <div className="absolute top-2 left-2 bg-gold-600/90 border border-gold-500/30 text-gold-400 text-[8px] uppercase tracking-widest px-2 py-0.5 rounded font-mono font-bold">
                    Empowered
                  </div>
                </div>

                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-gold-400 mt-0.5" />
                    <div>
                      <p className="font-bold text-text-main text-sm mb-0.5">20+ Years of Frontline P&amp;L Accountability</p>
                      <p className="text-xs text-text-main font-normal leading-relaxed"><strong className="text-gold-400 font-semibold">Not theory — I've been the one accountable for the number</strong>, every year, for two decades.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-gold-400 mt-0.5" />
                    <div>
                      <p className="font-bold text-text-main text-sm mb-0.5">Career &amp; Professional Growth</p>
                      <p className="text-xs text-text-main font-normal leading-relaxed"><strong className="text-gold-400 font-semibold">Positioning built for boardroom-level roles</strong> — not just a better-formatted resume.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-gold-400 mt-0.5" />
                    <div>
                      <p className="font-bold text-text-main text-sm mb-0.5">Personal Transformation</p>
                      <p className="text-xs text-text-main font-normal leading-relaxed">A <strong className="text-gold-400 font-semibold">confidential process to rebuild real clarity</strong> — not a one-off pep talk.</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-gold-400 mt-0.5" />
                    <div>
                      <p className="font-bold text-text-main text-sm mb-0.5">Ethical Cosmic Astrology Guidance</p>
                      <p className="text-xs text-text-main font-normal leading-relaxed"><strong className="text-gold-400 font-semibold">Vedic timing as decision support</strong> — informing your next move, never dictating it.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>

          </div>
        </motion.div>
      </div>
    </section>
  );
}
