import { motion } from "motion/react";
import { Building2, UserCog, Milestone, Compass } from "lucide-react";
import audienceImg from "../assets/images/indian_business_discussion_1780754641912.webp";

const audiences = [
  {
    icon: Building2,
    title: "Business Owners & Founders",
    desc: "Facing growth, strategy, expansion, or a major operational decision.",
  },
  {
    icon: UserCog,
    title: "Senior Professionals",
    desc: "Evaluating career direction, a transition, or a major professional decision.",
  },
  {
    icon: Milestone,
    title: "Leaders at a Crossroads",
    desc: "Facing a complex choice where business, professional, and personal factors are interconnected.",
  },
  {
    icon: Compass,
    title: "Individuals in Major Transitions",
    desc: "Seeking structured clarity during an important personal transition or period of uncertainty.",
  },
];

export function WhoThisIsFor() {
  return (
    <section id="who-this-is-for" className="audience-grid-accent py-16 bg-page-bg-800 relative border-t border-gold-500/20">
      <div
        className="absolute inset-0 opacity-[0.08] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${audienceImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-800 via-transparent to-page-bg-800 pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-[#FFF] mb-3 font-mono bg-[#8B3005] px-4 py-1.5 rounded-full inline-block border border-gold-500/30 font-bold">
            Who I Work With
          </h2>
          <h3 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight">
            Is This Approach For You?
          </h3>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {audiences.map((a, i) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-brand-900/50 border border-gold-500/15 rounded-2xl p-6 hover:border-gold-500/40 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-[#8B3005] border border-gold-500/30 flex items-center justify-center mb-4">
                <a.icon className="w-5 h-5 text-gold-400" />
              </div>
              <h4 className="text-sm font-serif font-semibold text-text-main mb-2 leading-snug">{a.title}</h4>
              <p className="text-xs text-text-main/70 leading-relaxed">{a.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
