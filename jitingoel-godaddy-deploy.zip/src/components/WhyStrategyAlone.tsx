import { motion } from "motion/react";
import { Lightbulb } from "lucide-react";
import architectureImg from "../assets/images/abstract_architecture_helix.webp";

export function WhyStrategyAlone() {
  return (
    <section id="why-strategy-alone" className="py-16 bg-page-bg-900 relative border-t border-b border-gold-500/10 overflow-hidden">
      <div
        className="helix-framework-canvas absolute inset-0 opacity-[0.08] bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${architectureImg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-page-bg-900 via-transparent to-page-bg-900 pointer-events-none"></div>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-12 h-12 rounded-full bg-[#8B3005] border border-gold-500/30 flex items-center justify-center mx-auto mb-5">
            <Lightbulb className="w-5 h-5 text-gold-400" />
          </div>
          <h2 className="text-xs sm:text-sm uppercase tracking-widest text-gold-500 mb-4 font-mono font-bold">
            My Philosophy
          </h2>
          <h3 className="section-title text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight mb-6 leading-tight">
            Why Strategy Alone Is Not Always Enough
          </h3>
          <div className="space-y-4 text-sm sm:text-base text-text-main/80 leading-relaxed">
            <p>
              Market data tells you <em className="text-gold-400 not-italic font-medium">what</em> to do. It doesn't tell you <em className="text-gold-400 not-italic font-medium">when</em> to do it.
            </p>
            <p>
              I've spent 20+ years making calls based on numbers alone — and watched good numbers still lead to bad outcomes because the timing was wrong. That's the gap Vedic cycles fill.
            </p>
            <p>
              I don't replace your data with astrology. I use it alongside the data, as a second read on timing — so you're not just making the right decision, you're making it at the right moment.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
