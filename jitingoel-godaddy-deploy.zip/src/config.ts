// Central place for the backend API base URL.
//
// Default (empty string) assumes the frontend and backend are served from the
// SAME domain — e.g. everything running together via a Node.js host, or GoDaddy's
// cPanel "Setup Node.js App" feature. In that case /api/... calls just work as-is.
//
// If the frontend (static files) and backend (Express server) end up hosted
// SEPARATELY — e.g. static files on GoDaddy cPanel, API server on Render/Railway —
// set VITE_API_BASE_URL at build time to the backend's full URL, for example:
//   VITE_API_BASE_URL=https://jitin-goel-api.onrender.com
// and rebuild. All API calls will then point there instead of relative paths.
export const API_BASE_URL: string = import.meta.env.VITE_API_BASE_URL || '';
