// Chatbot knowledge base — structured for accurate keyword matching + disambiguation.
// Each topic has SPECIFIC multi-word keyword phrases (not single common words) to
// minimize accidental overlap between topics. When a user's message matches more
// than one topic with similar strength, the chatbot asks a quick clarifying
// question instead of guessing — see the matching logic in Chatbot.tsx.

export interface ChatTopic {
  id: string;
  label: string; // short human-readable label, used in disambiguation buttons
  keywords: string[]; // specific phrases; longer/more specific phrases score higher
  replyEn: string;
  replyHi: string;
}

export const chatTopics: ChatTopic[] = [
  // ============ ABOUT / GENERAL ============
  {
    id: "about-jitin",
    label: "About Jitin",
    keywords: ["who is jitin", "about jitin", "jitin goel profile", "jitin experience", "जितिन कौन है", "जितिन के बारे में", "प्रोफाइल", "जितिन"],
    replyEn: `<strong>Jitin Goel</strong> brings <strong>20+ years of executive leadership</strong> in sales, operations, and business strategy, paired with <strong>26 years studying Vedic astrology</strong>. He helps clients see how business, career, and personal decisions connect — with the right timing.`,
    replyHi: `<strong>जितिन गोयल</strong> के पास <strong>20+ वर्षों का कार्यकारी नेतृत्व अनुभव</strong> है सेल्स, ऑपरेशंस और बिजनेस स्ट्रैटेजी में, साथ ही <strong>26 वर्षों का वैदिक ज्योतिष अध्ययन</strong>। वह दिखाते हैं कि व्यापार, करियर और व्यक्तिगत निर्णय कैसे आपस में जुड़े हैं — सही समय के साथ।`,
  },
  {
    id: "credentials-legit",
    label: "Credentials",
    keywords: ["is this legit", "credentials", "qualification", "genuine astrologer", "प्रामाणिक", "योग्यता", "असली है", "प्रामाणिक", "असली"],
    replyEn: `Jitin's approach is built on <strong>real, verifiable experience</strong> — two decades running actual businesses, not theory. His astrology practice is equally rigorous: 26 years of structured Vedic study, applied as decision support, never as guaranteed predictions.`,
    replyHi: `जितिन का तरीका <strong>वास्तविक, सत्यापन योग्य अनुभव</strong> पर आधारित है — दो दशक असली व्यवसाय चलाने का, केवल सिद्धांत नहीं। उनकी ज्योतिष प्रैक्टिस भी उतनी ही सटीक है: 26 वर्षों का संरचित वैदिक अध्ययन, निर्णय-सहायता के रूप में, कभी गारंटीशुदा भविष्यवाणी के रूप में नहीं।`,
  },
  {
    id: "first-session",
    label: "First Session",
    keywords: ["first session", "what happens in session", "first consultation", "पहला सत्र", "पहली मुलाकात", "पहला सत्र"],
    replyEn: `Your first session starts with understanding your real situation — not a generic questionnaire. We diagnose the actual bottleneck, then build a practical plan, with Vedic timing added as one more layer of clarity.`,
    replyHi: `आपका पहला सत्र आपकी असली स्थिति समझने से शुरू होता है — कोई सामान्य फॉर्म नहीं। हम असली रुकावट का निदान करते हैं, फिर एक व्यावहारिक योजना बनाते हैं, वैदिक समय को स्पष्टता की एक और परत के रूप में जोड़कर।`,
  },
  {
    id: "payment-methods",
    label: "Payment",
    keywords: ["payment method", "how to pay", "payment options", "भुगतान कैसे करें", "पेमेंट", "भुगतान", "पेमेंट"],
    replyEn: `Once you book via WhatsApp, Jitin will confirm the session and share the payment link directly with you — simple and secure.`,
    replyHi: `जब आप व्हाट्सएप के माध्यम से बुक करते हैं, जितिन सत्र की पुष्टि करेंगे और सीधे आपको भुगतान लिंक भेजेंगे — सरल और सुरक्षित।`,
  },
  {
    id: "refund-policy",
    label: "Refund Policy",
    keywords: ["refund policy", "cancellation policy", "reschedule appointment", "रिफंड नीति", "रद्द करना"],
    replyEn: `You can find our full refund and cancellation policy in the footer of the website. For rescheduling, just message Jitin directly on WhatsApp — he'll sort out a new time with you.`,
    replyHi: `हमारी पूरी रिफंड और रद्दीकरण नीति वेबसाइट के फुटर में मिलेगी। पुनर्निर्धारण के लिए, सीधे जितिन को व्हाट्सएप पर संदेश भेजें — वह आपके साथ नया समय तय करेंगे।`,
  },
  {
    id: "international-clients",
    label: "International Clients",
    keywords: ["international client", "outside india", "different timezone", "अंतरराष्ट्रीय ग्राहक", "विदेश से"],
    replyEn: `Yes — all consultations happen over video call, so your location or timezone is never a barrier. Jitin works with clients across India, the Middle East, UK, US, Singapore, and Australia.`,
    replyHi: `हाँ — सभी परामर्श वीडियो कॉल पर होते हैं, इसलिए आपका स्थान या समय क्षेत्र कभी बाधा नहीं बनता। जितिन भारत, मध्य पूर्व, यूके, यूएस, सिंगापुर और ऑस्ट्रेलिया के ग्राहकों के साथ काम करते हैं।`,
  },
  {
    id: "which-service-fit",
    label: "Which Service Fits Me",
    keywords: ["which service is right", "which service should i choose", "confused which service", "कौन सी सेवा सही है", "कौन सी सेवा चुनूं", "सेवा चुनें"],
    replyEn: `Good question — think about where the real friction is right now: business growth (Business Strategy), your job or role (Career), how you feel day-to-day (Personal Transformation), or timing a big decision (Cosmic Astrology). You can also use the "Start Here" section on this page to jump straight to the right area. Not sure? Just tell me what's on your mind and I'll point you the right way.`,
    replyHi: `अच्छा सवाल — सोचिए कि असली दिक्कत कहाँ है: व्यापार वृद्धि (Business Strategy), आपकी नौकरी या भूमिका (Career), आप रोज़ कैसा महसूस करते हैं (Personal Transformation), या किसी बड़े फैसले का समय (Cosmic Astrology)। इस पेज पर "Start Here" सेक्शन का उपयोग करके भी सीधे सही जगह जा सकते हैं। पक्का नहीं? बस बताइए क्या सोच रहे हैं, मैं सही दिशा बताऊंगा।`,
  },
  {
    id: "testimonials",
    label: "Client Results",
    keywords: ["testimonials", "client results", "success stories", "past clients", "प्रशंसापत्र", "क्लाइंट के परिणाम"],
    replyEn: `We deliberately don't publish fabricated testimonials or inflated numbers — that's not how Jitin works. The best way to judge fit is a direct conversation about your specific situation.`,
    replyHi: `हम जानबूझकर मनगढ़ंत प्रशंसापत्र या बढ़ा-चढ़ाकर आंकड़े प्रकाशित नहीं करते — जितिन इस तरह काम नहीं करते। फिट judge करने का सबसे अच्छा तरीका है आपकी विशिष्ट स्थिति पर सीधी बातचीत।`,
  },
  {
    id: "tools-calculators",
    label: "Free Tools",
    keywords: ["free tools", "calculator", "numerology calculator", "vastu calculator", "मुफ्त टूल", "कैलकुलेटर"],
    replyEn: `Check out our free Numerology and Vastu calculators on the website — under "Astro Calculators" in the menu. Quick, practical, and a good starting point before a full consultation.`,
    replyHi: `हमारी वेबसाइट पर मुफ्त न्यूमेरोलॉजी और वास्तु कैलकुलेटर देखें — मेनू में "Astro Calculators" के तहत। त्वरित, व्यावहारिक, और पूर्ण परामर्श से पहले एक अच्छी शुरुआत।`,
  },

  // ============ VASTU (kept from original) ============
  {
    id: "vastu",
    label: "Vastu Shastra",
    keywords: ["vastu", "office direction", "desk direction", "vastu for home", "वास्तु", "दिशा", "ऑफिस वास्तु"],
    replyEn: `<strong>Vastu Shastra Optimization:</strong><br/>
• <strong>CEO / Leadership Desk:</strong> Southwest corner, facing Northeast — for authority and clear decisions.<br/>
• <strong>Accounts / Finance:</strong> North quadrant — for stable cash flow.<br/>
• <strong>Sales / Marketing:</strong> Northwest or Southeast — for faster momentum.<br/><br/>
Want a personalized Vastu review of your space? Message Jitin directly.`,
    replyHi: `<strong>वास्तु शास्त्र मुख्य मार्गदर्शन:</strong><br/>
• <strong>सीईओ डेस्क:</strong> दक्षिण-पश्चिम कोना, उत्तर-पूर्व की ओर मुख — अधिकार और स्पष्ट निर्णयों के लिए।<br/>
• <strong>वित्त विभाग:</strong> उत्तर दिशा — स्थिर नकदी प्रवाह के लिए।<br/>
• <strong>सेल्स/मार्केटिंग:</strong> उत्तर-पश्चिम या दक्षिण-पूर्व — तेज़ गति के लिए।<br/><br/>
अपनी जगह का व्यक्तिगत वास्तु विश्लेषण चाहिए? सीधे जितिन को संदेश भेजें।`,
  },

  // ============ BUSINESS STRATEGY (15) ============
  {
    id: "biz-what-included",
    label: "Business Strategy Overview",
    keywords: ["business strategy consulting include", "what does business consulting cover", "business strategy service", "बिजनेस स्ट्रैटेजी में क्या शामिल है", "बिजनेस स्ट्रैटेजी"],
    replyEn: `Business Strategy & Growth Consulting covers diagnosing your real growth bottleneck, then building a sequenced plan — whether that's distribution, sales systems, or operations.`,
    replyHi: `Business Strategy & Growth Consulting में आपकी असली विकास रुकावट का निदान, फिर एक क्रमबद्ध योजना बनाना शामिल है — चाहे वह वितरण हो, सेल्स सिस्टम हो, या संचालन।`,
  },
  {
    id: "biz-bottleneck-diagnosis",
    label: "Business Bottleneck",
    keywords: ["business bottleneck", "why is my business not growing", "growth stalled", "business stuck", "बिजनेस क्यों नहीं बढ़ रहा", "व्यापार रुक गया", "बिजनेस नहीं बढ़ रहा", "व्यापार रुका"],
    replyEn: `Growth usually stalls for a specific, identifiable reason — not "everything." We run a structured diagnostic to find that exact bottleneck before recommending anything.`,
    replyHi: `विकास आमतौर पर एक विशिष्ट, पहचानने योग्य कारण से रुकता है — "सब कुछ" से नहीं। हम कुछ भी सुझाने से पहले वह सटीक रुकावट खोजने के लिए एक संरचित निदान करते हैं।`,
  },
  {
    id: "biz-revenue-growth",
    label: "Revenue Growth",
    keywords: ["revenue growth strategy", "scaling strategy", "increase sales", "grow revenue", "राजस्व वृद्धि", "बिक्री बढ़ाना"],
    replyEn: `Revenue growth strategy starts with finding where you're leaking opportunity — pricing, sales process, or market positioning — then fixing that first before scaling spend.`,
    replyHi: `राजस्व वृद्धि रणनीति यह पता लगाने से शुरू होती है कि आप कहाँ अवसर खो रहे हैं — मूल्य निर्धारण, बिक्री प्रक्रिया, या बाज़ार स्थिति — फिर खर्च बढ़ाने से पहले उसे ठीक करना।`,
  },
  {
    id: "biz-sales-process",
    label: "Sales Process",
    keywords: ["sales process improvement", "improve sales team", "sales system", "बिक्री प्रक्रिया सुधार", "बिक्री सुधार"],
    replyEn: `A weak sales process usually shows up as inconsistent conversion, not lack of leads. We audit your current process and rebuild the specific step that's leaking deals.`,
    replyHi: `एक कमज़ोर बिक्री प्रक्रिया आमतौर पर असंगत रूपांतरण के रूप में दिखती है, लीड की कमी के रूप में नहीं। हम आपकी वर्तमान प्रक्रिया का ऑडिट करते हैं और उस विशिष्ट चरण को फिर से बनाते हैं जहाँ सौदे टूट रहे हैं।`,
  },
  {
    id: "biz-operations",
    label: "Operations Streamlining",
    keywords: ["operations streamlining", "operational efficiency", "business operations problem", "संचालन में सुधार", "संचालन सुधार"],
    replyEn: `Operational friction quietly eats margin. We map your current workflow, find the specific point causing delay or waste, and fix that — not a full system overhaul.`,
    replyHi: `संचालन में घर्षण चुपचाप मार्जिन खा जाता है। हम आपके वर्तमान वर्कफ़्लो का नक्शा बनाते हैं, देरी या बर्बादी का कारण बनने वाला विशिष्ट बिंदु ढूंढते हैं, और उसे ठीक करते हैं — पूरा सिस्टम ओवरहॉल नहीं।`,
  },
  {
    id: "biz-startup-vs-established",
    label: "Startup vs Established",
    keywords: ["startup consulting", "established business consulting", "small business vs large business", "स्टार्टअप परामर्श"],
    replyEn: `Both. Startups get help building a strong foundation and finding product-market fit. Established businesses get support scaling operations and navigating strategic pivots.`,
    replyHi: `दोनों। स्टार्टअप्स को एक मज़बूत नींव बनाने और प्रोडक्ट-मार्केट फिट खोजने में मदद मिलती है। स्थापित व्यवसायों को संचालन बढ़ाने और रणनीतिक बदलावों में सहायता मिलती है।`,
  },
  {
    id: "biz-pricing-packages",
    label: "Business Consulting Pricing",
    keywords: ["business consulting pricing", "business consulting package", "business consulting fees", "बिजनेस परामर्श शुल्क", "बिजनेस शुल्क", "फीस"],
    replyEn: `Pricing depends on the scope of your situation. The best way to get an accurate quote is a quick WhatsApp conversation about what you're facing.`,
    replyHi: `मूल्य आपकी स्थिति के दायरे पर निर्भर करता है। सटीक कोटेशन पाने का सबसे अच्छा तरीका है आप क्या सामना कर रहे हैं, इस पर एक त्वरित व्हाट्सएप बातचीत।`,
  },
  {
    id: "biz-engagement-duration",
    label: "Business Engagement Duration",
    keywords: ["how long business consulting", "business engagement duration", "बिजनेस परामर्श कितने समय का", "परामर्श समय"],
    replyEn: `It depends on the complexity of what we're solving — some engagements are a focused single session, others run over a few months. We'll scope this together in your first conversation.`,
    replyHi: `यह हल की जा रही जटिलता पर निर्भर करता है — कुछ जुड़ाव एक केंद्रित सत्र होते हैं, कुछ कुछ महीनों तक चलते हैं। हम आपकी पहली बातचीत में इसे साथ मिलकर तय करेंगे।`,
  },
  {
    id: "biz-partnership-issues",
    label: "Business Partnership Issues",
    keywords: ["business partnership issue", "co-founder conflict", "partner dispute", "साझेदारी विवाद", "व्यावसायिक साझेदार समस्या", "साझेदारी विवाद", "पार्टनर समस्या"],
    replyEn: `Partnership friction is common and solvable. We help clarify roles, decision rights, and expectations — often the root issue is misalignment, not personality.`,
    replyHi: `साझेदारी में घर्षण सामान्य और हल करने योग्य है। हम भूमिकाओं, निर्णय अधिकारों और अपेक्षाओं को स्पष्ट करने में मदद करते हैं — अक्सर मूल समस्या असंगति है, व्यक्तित्व नहीं।`,
  },
  {
    id: "biz-timing-astrology",
    label: "Business Timing & Astrology",
    keywords: ["business decision timing astrology", "muhurat for business", "auspicious time for launch", "व्यापार के लिए शुभ समय", "मुहूर्त", "शुभ समय", "मुहूर्त"],
    replyEn: `For major business moves — a launch, a big investment, a leadership change — we check Vedic timing alongside the business case, so you enter with more context, not less.`,
    replyHi: `बड़े व्यावसायिक कदमों के लिए — लॉन्च, बड़ा निवेश, नेतृत्व परिवर्तन — हम व्यावसायिक मामले के साथ वैदिक समय की भी जाँच करते हैं, ताकि आप अधिक संदर्भ के साथ आगे बढ़ें, कम नहीं।`,
  },
  {
    id: "biz-plan-review",
    label: "Business Plan Review",
    keywords: ["business plan review", "review my business plan", "बिजनेस प्लान समीक्षा", "प्लान समीक्षा"],
    replyEn: `Yes, we review business plans — but more importantly, we pressure-test the assumptions behind them, which is where most plans actually fall short.`,
    replyHi: `हाँ, हम बिजनेस प्लान की समीक्षा करते हैं — लेकिन अधिक महत्वपूर्ण, हम उनके पीछे की मान्यताओं का परीक्षण करते हैं, जहाँ अधिकांश योजनाएँ वास्तव में कमज़ोर पड़ती हैं।`,
  },
  {
    id: "biz-session-format",
    label: "Business Session Format",
    keywords: ["business strategy session format", "how does business consulting work", "बिजनेस सत्र कैसे काम करता है", "बिजनेस सत्र"],
    replyEn: `Sessions are conducted over video call, one-on-one with Jitin directly — no account managers, no junior associates.`,
    replyHi: `सत्र वीडियो कॉल पर आयोजित किए जाते हैं, सीधे जितिन के साथ एक-से-एक — कोई अकाउंट मैनेजर नहीं, कोई जूनियर सहयोगी नहीं।`,
  },
  {
    id: "biz-remote-online",
    label: "Remote Business Consulting",
    keywords: ["online business consulting", "remote business consulting", "ऑनलाइन बिजनेस परामर्श", "ऑनलाइन परामर्श"],
    replyEn: `Yes, all business consulting is conducted online via video call — location is never a barrier.`,
    replyHi: `हाँ, सभी बिजनेस परामर्श वीडियो कॉल के माध्यम से ऑनलाइन आयोजित किए जाते हैं — स्थान कभी बाधा नहीं है।`,
  },
  {
    id: "biz-fundraising",
    label: "Fundraising / Capital",
    keywords: ["fundraising strategy", "raising capital", "investor readiness", "पूंजी जुटाना", "निवेशक"],
    replyEn: `Before raising capital, we help you get the fundamentals right — clear metrics, a defensible growth story, and (if you want it) favorable timing based on your chart.`,
    replyHi: `पूंजी जुटाने से पहले, हम आपको बुनियादी बातें सही करने में मदद करते हैं — स्पष्ट मेट्रिक्स, एक मज़बूत विकास कहानी, और (अगर चाहें तो) आपकी कुंडली के आधार पर अनुकूल समय।`,
  },
  {
    id: "biz-double-helix",
    label: "The JG Double Helix Framework",
    keywords: ["double helix framework", "your methodology", "signature framework", "jg double helix", "डबल हेलिक्स फ्रेमवर्क", "आपकी पद्धति", "डबल हेलिक्स", "हेलिक्स फ्रेमवर्क"],
    replyEn: `The JG Double Helix Framework is our signature methodology — "Where Strategy and Timing Interconnect." Two strands, Strategy and Timing, examined together. A great plan with the wrong timing is still the wrong decision.`,
    replyHi: `द जेजी डबल हेलिक्स फ्रेमवर्क हमारी हस्ताक्षर पद्धति है — "जहाँ रणनीति और समय आपस में जुड़ते हैं।" दो धागे, रणनीति और समय, साथ में जांचे गए। गलत समय के साथ एक बेहतरीन योजना भी गलत निर्णय ही रहती है।`,
  },

  // ============ CAREER & PROFESSIONAL (15) ============
  {
    id: "career-transition",
    label: "Career Transition",
    keywords: ["career transition", "job change guidance", "switching jobs", "करियर बदलाव", "नौकरी बदलना"],
    replyEn: `Career transitions work best with a clear positioning strategy, not just applying widely. We help you identify the right move and build the narrative to support it.`,
    replyHi: `करियर बदलाव एक स्पष्ट स्थिति रणनीति के साथ सबसे अच्छे से काम करता है, केवल व्यापक रूप से आवेदन करने से नहीं। हम सही कदम पहचानने और उसका समर्थन करने वाली कहानी बनाने में मदद करते हैं।`,
  },
  {
    id: "career-resume-linkedin",
    label: "Resume / LinkedIn",
    keywords: ["resume help", "linkedin positioning", "improve my resume", "रिज़्यूमे मदद", "लिंक्डइन"],
    replyEn: `We rebuild your resume and LinkedIn presence around a clear positioning strategy — not just formatting, but the story that gets the right opportunities to notice you.`,
    replyHi: `हम आपके रिज़्यूमे और लिंक्डइन उपस्थिति को एक स्पष्ट स्थिति रणनीति के इर्द-गिर्द फिर से बनाते हैं — केवल फ़ॉर्मेटिंग नहीं, बल्कि वह कहानी जो सही अवसरों का ध्यान खींचे।`,
  },
  {
    id: "career-salary-negotiation",
    label: "Salary Negotiation",
    keywords: ["salary negotiation", "negotiate my salary", "वेतन बातचीत", "सैलरी नेगोशिएशन"],
    replyEn: `Salary negotiation is really about how you've positioned your value beforehand. We work on that positioning, which makes the actual negotiation much easier.`,
    replyHi: `वेतन बातचीत असल में इस बारे में है कि आपने पहले से अपने मूल्य को कैसे स्थापित किया है। हम उस स्थिति पर काम करते हैं, जो असली बातचीत को बहुत आसान बना देता है।`,
  },
  {
    id: "career-promotion-leadership",
    label: "Promotion / Leadership Role",
    keywords: ["promotion preparation", "leadership role prep", "getting promoted", "पदोन्नति की तैयारी", "लीडरशिप रोल", "पदोन्नति"],
    replyEn: `Preparing for a leadership role means more than doing your current job well — it's about demonstrating decision-making at the next level. We build that case with you.`,
    replyHi: `नेतृत्व भूमिका की तैयारी का मतलब सिर्फ अपने वर्तमान काम को अच्छी तरह करना नहीं है — यह अगले स्तर पर निर्णय लेने की क्षमता दिखाने के बारे में है। हम आपके साथ वह मामला बनाते हैं।`,
  },
  {
    id: "career-stuck-plateau",
    label: "Career Plateau",
    keywords: ["career stuck", "career plateau", "not growing in career", "करियर में ठहराव", "करियर रुक गया", "करियर ठहराव", "करियर रुका"],
    replyEn: `Feeling stuck despite visible success is usually a positioning problem, not a capability problem. We find the specific gap and rebuild your trajectory around it.`,
    replyHi: `दिखाई देने वाली सफलता के बावजूद अटका हुआ महसूस करना आमतौर पर एक स्थिति समस्या है, क्षमता की समस्या नहीं। हम विशिष्ट अंतर खोजते हैं और उसके इर्द-गिर्द आपका प्रक्षेपवक्र फिर से बनाते हैं।`,
  },
  {
    id: "career-industry-change",
    label: "Career Industry Change",
    keywords: ["change industry", "switch career field", "new industry transition", "उद्योग बदलना", "क्षेत्र परिवर्तन"],
    replyEn: `Moving to a new industry works when you can show how your existing experience transfers — not by hiding it. We help you build that bridge clearly.`,
    replyHi: `नए उद्योग में जाना तब काम करता है जब आप दिखा सकें कि आपका मौजूदा अनुभव कैसे स्थानांतरित होता है — उसे छिपाकर नहीं। हम आपको वह पुल स्पष्ट रूप से बनाने में मदद करते हैं।`,
  },
  {
    id: "career-interview-prep",
    label: "Interview Preparation",
    keywords: ["interview preparation", "prepare for interview", "साक्षात्कार की तैयारी", "साक्षात्कार"],
    replyEn: `Interview prep with us goes beyond common questions — we work on how you frame your specific experience for the specific role you're targeting.`,
    replyHi: `हमारे साथ साक्षात्कार की तैयारी सामान्य प्रश्नों से आगे जाती है — हम इस पर काम करते हैं कि आप अपने विशिष्ट अनुभव को लक्षित भूमिका के लिए कैसे प्रस्तुत करें।`,
  },
  {
    id: "career-astrology-combined",
    label: "Career + Astrology",
    keywords: ["career astrology", "career timing chart", "job change astrology", "करियर ज्योतिष", "नौकरी परिवर्तन ज्योतिष", "नौकरी ज्योतिष"],
    replyEn: `We look at your career decisions alongside your Vedic chart — timing a job change or career pivot around favorable periods, not just gut feeling.`,
    replyHi: `हम आपके करियर निर्णयों को आपकी वैदिक कुंडली के साथ देखते हैं — नौकरी परिवर्तन या करियर बदलाव का समय अनुकूल अवधियों के आसपास तय करना, केवल अंतर्ज्ञान से नहीं।`,
  },
  {
    id: "career-session-work",
    label: "Career Session Format",
    keywords: ["how career consulting works", "career session format", "करियर सत्र कैसे काम करता है", "करियर सत्र"],
    replyEn: `Career sessions are one-on-one with Jitin over video call — we diagnose your specific situation first, then build a plan around it.`,
    replyHi: `करियर सत्र वीडियो कॉल पर जितिन के साथ एक-से-एक होते हैं — हम पहले आपकी विशिष्ट स्थिति का निदान करते हैं, फिर उसके आसपास एक योजना बनाते हैं।`,
  },
  {
    id: "career-freshers-vs-experienced",
    label: "Freshers vs Experienced",
    keywords: ["career consulting for freshers", "career consulting for experienced", "fresh graduate career", "फ्रेशर्स के लिए करियर", "फ्रेशर्स"],
    replyEn: `Both. Freshers get help building strong early positioning; experienced professionals get support with strategic transitions and leadership positioning.`,
    replyHi: `दोनों। फ्रेशर्स को मज़बूत प्रारंभिक स्थिति बनाने में मदद मिलती है; अनुभवी पेशेवरों को रणनीतिक बदलावों और नेतृत्व स्थिति में सहायता मिलती है।`,
  },
  {
    id: "career-work-life-balance",
    label: "Work-Life Balance",
    keywords: ["work life balance", "burnout from work", "काम और जीवन संतुलन", "जीवन संतुलन"],
    replyEn: `Work-life balance issues are often really a boundaries and priorities problem tied to your career direction. We address the root, not just symptoms.`,
    replyHi: `काम-जीवन संतुलन की समस्याएँ अक्सर वास्तव में आपके करियर दिशा से जुड़ी सीमाओं और प्राथमिकताओं की समस्या होती हैं। हम मूल कारण को संबोधित करते हैं, केवल लक्षणों को नहीं।`,
  },
  {
    id: "career-confidence-imposter",
    label: "Career Confidence",
    keywords: ["imposter syndrome career", "career confidence issue", "self doubt at work", "करियर आत्मविश्वास", "इम्पॉस्टर सिंड्रोम"],
    replyEn: `Imposter syndrome at work often comes from unclear positioning, not lack of skill. Once your value is clearly articulated, confidence tends to follow.`,
    replyHi: `काम पर इम्पॉस्टर सिंड्रोम अक्सर अस्पष्ट स्थिति से आता है, कौशल की कमी से नहीं। एक बार जब आपका मूल्य स्पष्ट रूप से व्यक्त हो जाता है, तो आत्मविश्वास आमतौर पर पीछे आता है।`,
  },
  {
    id: "career-networking-branding",
    label: "Networking & Personal Brand",
    keywords: ["networking strategy", "personal branding career", "नेटवर्किंग रणनीति", "व्यक्तिगत ब्रांड"],
    replyEn: `Personal branding for your career should be specific and true to your actual strengths — not generic self-promotion. We help you find and sharpen that.`,
    replyHi: `आपके करियर के लिए व्यक्तिगत ब्रांडिंग विशिष्ट और आपकी वास्तविक शक्तियों के प्रति सच्ची होनी चाहिए — सामान्य आत्म-प्रचार नहीं। हम आपको वह खोजने और तेज़ करने में मदद करते हैं।`,
  },
  {
    id: "career-consulting-duration",
    label: "Career Consulting Duration",
    keywords: ["career consulting duration", "how long career consulting", "करियर परामर्श कितने समय का", "करियर समय"],
    replyEn: `This depends on your goal — a focused positioning session, or ongoing support through a longer transition. We'll figure out the right cadence together.`,
    replyHi: `यह आपके लक्ष्य पर निर्भर करता है — एक केंद्रित स्थिति सत्र, या लंबे बदलाव के दौरान निरंतर सहायता। हम सही गति एक साथ तय करेंगे।`,
  },

  // ============ PERSONAL TRANSFORMATION (15) ============
  {
    id: "personal-what-is",
    label: "Personal Transformation Overview",
    keywords: ["what is personal transformation", "personal transformation consulting", "व्यक्तिगत परिवर्तन क्या है", "व्यक्तिगत परिवर्तन"],
    replyEn: `Personal Transformation Consulting rebuilds your decision-making around real clarity — addressing the misalignment between your values and daily actions, not inherited habits.`,
    replyHi: `Personal Transformation Consulting आपके निर्णय लेने को वास्तविक स्पष्टता के आसपास फिर से बनाता है — आपके मूल्यों और दैनिक कार्यों के बीच असंगति को संबोधित करता है, विरासत में मिली आदतों को नहीं।`,
  },
  {
    id: "personal-stress",
    label: "Stress Management",
    keywords: ["stress management", "feeling overwhelmed", "chronic stress", "तनाव प्रबंधन", "अत्यधिक तनाव"],
    replyEn: `Chronic stress is often a signal of misalignment, not just workload. We work on identifying the real source before addressing symptoms.`,
    replyHi: `पुराना तनाव अक्सर असंगति का संकेत होता है, केवल कार्यभार का नहीं। हम लक्षणों को संबोधित करने से पहले असली स्रोत की पहचान करने पर काम करते हैं।`,
  },
  {
    id: "personal-self-doubt",
    label: "Self-Doubt",
    keywords: ["self doubt", "lack confidence personal", "आत्म-संदेह", "आत्मविश्वास की कमी", "आत्मविश्वास कमी"],
    replyEn: `Self-doubt despite outer success is a very common pattern. We use structured self-assessment to find exactly where it lives, then rebuild from there.`,
    replyHi: `बाहरी सफलता के बावजूद आत्म-संदेह एक बहुत सामान्य पैटर्न है। हम यह पता लगाने के लिए संरचित आत्म-मूल्यांकन का उपयोग करते हैं कि यह वास्तव में कहाँ है, फिर वहाँ से पुनर्निर्माण करते हैं।`,
  },
  {
    id: "personal-relationship",
    label: "Relationship Guidance",
    keywords: ["relationship guidance", "family issues personal", "marriage clarity", "रिश्ते मार्गदर्शन", "पारिवारिक समस्या"],
    replyEn: `Relationship and family clarity is part of the complete picture — since personal decisions rarely stay isolated from career and business pressure. We look at all of it together.`,
    replyHi: `रिश्ते और पारिवारिक स्पष्टता पूरी तस्वीर का हिस्सा है — क्योंकि व्यक्तिगत निर्णय शायद ही कभी करियर और व्यावसायिक दबाव से अलग रहते हैं। हम इन सबको एक साथ देखते हैं।`,
  },
  {
    id: "personal-life-purpose",
    label: "Life Purpose / Clarity",
    keywords: ["find my purpose", "life clarity", "what should i do with my life", "जीवन का उद्देश्य", "जीवन स्पष्टता", "जीवन उद्देश्य"],
    replyEn: `Finding clarity isn't about a single "aha" moment — it's a structured process of examining your values against your actual daily decisions.`,
    replyHi: `स्पष्टता खोजना एक भी "आह" पल के बारे में नहीं है — यह आपके मूल्यों की आपके वास्तविक दैनिक निर्णयों के साथ जांच करने की एक संरचित प्रक्रिया है।`,
  },
  {
    id: "personal-decision-paralysis",
    label: "Decision Paralysis",
    keywords: ["decision paralysis", "can't decide", "stuck on a decision", "निर्णय नहीं ले पा रहा", "फैसला नहीं कर पा रहा", "निर्णय नहीं", "फैसला नहीं"],
    replyEn: `Decision paralysis usually means the real options and trade-offs aren't clear yet. We help structure the decision — and add timing clarity if it's a major one.`,
    replyHi: `निर्णय पक्षाघात का आमतौर पर मतलब है कि असली विकल्प और ट्रेड-ऑफ़ अभी स्पष्ट नहीं हैं। हम निर्णय को संरचित करने में मदद करते हैं — और अगर यह बड़ा है तो समय स्पष्टता भी जोड़ते हैं।`,
  },
  {
    id: "personal-burnout",
    label: "Burnout Recovery",
    keywords: ["burnout recovery", "recovering from burnout", "बर्नआउट से उबरना", "बर्नआउट"],
    replyEn: `Burnout recovery starts with understanding what actually caused it — usually a specific misalignment, not just "too much work." We address that root cause.`,
    replyHi: `बर्नआउट से उबरना यह समझने से शुरू होता है कि इसका असली कारण क्या था — आमतौर पर एक विशिष्ट असंगति, केवल "बहुत ज़्यादा काम" नहीं। हम उस मूल कारण को संबोधित करते हैं।`,
  },
  {
    id: "personal-astrology-combined",
    label: "Personal Transformation + Astrology",
    keywords: ["personal transformation astrology", "astrology for inner clarity", "व्यक्तिगत परिवर्तन ज्योतिष", "व्यक्तिगत ज्योतिष"],
    replyEn: `We combine structured self-assessment with your Vedic chart — giving you both a practical framework and timing insight for your personal journey.`,
    replyHi: `हम संरचित आत्म-मूल्यांकन को आपकी वैदिक कुंडली के साथ जोड़ते हैं — आपको आपकी व्यक्तिगत यात्रा के लिए एक व्यावहारिक ढांचा और समय अंतर्दृष्टि दोनों देते हैं।`,
  },
  {
    id: "personal-confidentiality",
    label: "Confidentiality",
    keywords: ["confidential session", "is this private", "privacy of consultation", "गोपनीय सत्र", "गोपनीयता"],
    replyEn: `Yes — personal sessions are completely confidential, one-on-one with Jitin directly. Nothing is shared with anyone else.`,
    replyHi: `हाँ — व्यक्तिगत सत्र पूरी तरह गोपनीय होते हैं, सीधे जितिन के साथ एक-से-एक। किसी और के साथ कुछ भी साझा नहीं किया जाता।`,
  },
  {
    id: "personal-session-work",
    label: "Personal Session Format",
    keywords: ["how personal transformation works", "personal session format", "व्यक्तिगत सत्र कैसे काम करता है", "व्यक्तिगत सत्र"],
    replyEn: `Personal sessions are structured but conversational — we work through your specific situation together, over video call, at your pace.`,
    replyHi: `व्यक्तिगत सत्र संरचित लेकिन बातचीत के अंदाज़ में होते हैं — हम वीडियो कॉल पर, आपकी गति से, आपकी विशिष्ट स्थिति पर एक साथ काम करते हैं।`,
  },
  {
    id: "personal-high-achievers",
    label: "Personal Transformation for High Achievers",
    keywords: ["high achiever personal", "successful but unhappy", "सफल लेकिन खुश नहीं", "सफल खुश नहीं"],
    replyEn: `This is actually one of our most common cases — outward success with limited inner clarity. It's a design problem, not a willpower problem, and it's very solvable.`,
    replyHi: `यह वास्तव में हमारे सबसे सामान्य मामलों में से एक है — बाहरी सफलता के साथ सीमित आंतरिक स्पष्टता। यह एक डिज़ाइन समस्या है, इच्छाशक्ति की समस्या नहीं, और यह बहुत हल करने योग्य है।`,
  },
  {
    id: "personal-mindset-habits",
    label: "Mindset / Habit Change",
    keywords: ["change my mindset", "break bad habits", "मानसिकता बदलना", "आदतें बदलना"],
    replyEn: `Lasting mindset change comes from rebuilding the decision-making pattern underneath the habit — not willpower alone. That's the structured work we do together.`,
    replyHi: `स्थायी मानसिकता परिवर्तन आदत के नीचे के निर्णय-निर्माण पैटर्न को फिर से बनाने से आता है — केवल इच्छाशक्ति से नहीं। यही संरचित काम है जो हम साथ मिलकर करते हैं।`,
  },
  {
    id: "personal-session-frequency",
    label: "Personal Session Frequency",
    keywords: ["how often personal sessions", "personal transformation frequency", "व्यक्तिगत सत्र कितनी बार", "सत्र कितनी बार"],
    replyEn: `Most clients meet bi-weekly or monthly to maintain momentum. We'll set the right cadence together based on your goals.`,
    replyHi: `अधिकांश ग्राहक गति बनाए रखने के लिए द्वि-साप्ताहिक या मासिक मिलते हैं। हम आपके लक्ष्यों के आधार पर सही गति एक साथ तय करेंगे।`,
  },
  {
    id: "personal-results",
    label: "Personal Transformation Results",
    keywords: ["personal transformation results", "what outcome can i expect", "व्यक्तिगत परिवर्तन के परिणाम", "परिणाम"],
    replyEn: `The goal is renewed confidence and a deliberate, sustainable path forward — not a temporary motivational boost.`,
    replyHi: `लक्ष्य है नए सिरे से आत्मविश्वास और आगे बढ़ने का एक जानबूझकर, टिकाऊ रास्ता — एक अस्थायी प्रेरक बढ़ावा नहीं।`,
  },

  // ============ COSMIC ASTROLOGY (15) ============
  {
    id: "astro-kundli-reading",
    label: "Birth Chart Reading",
    keywords: ["birth chart reading", "kundli reading details", "जन्म कुंडली पढ़ना", "कुंडली विवरण", "कुंडली पढ़ना"],
    replyEn: `A birth chart reading covers your strengths, challenges, and cyclical timing patterns — giving you a clear lens for career, relationship, and personal decisions.`,
    replyHi: `एक जन्म कुंडली पढ़ने में आपकी शक्तियाँ, चुनौतियाँ और चक्रीय समय पैटर्न शामिल हैं — जो आपको करियर, रिश्ते और व्यक्तिगत निर्णयों के लिए एक स्पष्ट दृष्टिकोण देता है।`,
  },
  {
    id: "astro-marriage-timing",
    label: "Marriage Timing",
    keywords: ["marriage timing", "marriage compatibility chart", "विवाह का समय", "विवाह अनुकूलता", "विवाह समय"],
    replyEn: `Marriage timing and compatibility analysis looks at both charts' cycles together, to give you clarity — never a guarantee, always an added layer of insight.`,
    replyHi: `विवाह समय और अनुकूलता विश्लेषण दोनों कुंडलियों के चक्रों को एक साथ देखता है, आपको स्पष्टता देने के लिए — कभी गारंटी नहीं, हमेशा अंतर्दृष्टि की एक अतिरिक्त परत।`,
  },
  {
    id: "astro-numerology-name",
    label: "Numerology Name Analysis",
    keywords: ["numerology name analysis", "business name numerology", "नाम अंकशास्त्र", "व्यापार नाम अंकशास्त्र", "नाम अंकशास्त्र"],
    replyEn: `Numerology name analysis looks at how your name's number pattern aligns with your goals — useful for personal names or business names alike. Try our free calculator on the site.`,
    replyHi: `अंकशास्त्र नाम विश्लेषण देखता है कि आपके नाम का अंक पैटर्न आपके लक्ष्यों के साथ कैसे मेल खाता है — व्यक्तिगत नामों या व्यावसायिक नामों दोनों के लिए उपयोगी। साइट पर हमारा मुफ्त कैलकुलेटर आज़माएं।`,
  },
  {
    id: "astro-vastu-home",
    label: "Vastu for Home",
    keywords: ["vastu for home", "home vastu tips", "घर का वास्तु", "घर वास्तु"],
    replyEn: `Home Vastu covers entrance direction, room placement, and specific remedies for balance. Use our free Vastu Audit tool for a quick starting assessment.`,
    replyHi: `घर का वास्तु प्रवेश दिशा, कमरे की व्यवस्था और संतुलन के लिए विशिष्ट उपायों को शामिल करता है। त्वरित प्रारंभिक मूल्यांकन के लिए हमारे मुफ्त वास्तु ऑडिट टूल का उपयोग करें।`,
  },
  {
    id: "astro-gemstone",
    label: "Gemstone Recommendations",
    keywords: ["gemstone recommendation", "which gemstone should i wear", "रत्न सिफारिश", "कौन सा रत्न पहनूं", "रत्न"],
    replyEn: `Gemstone recommendations are made only after a full chart analysis — we don't recommend stones generically, since the wrong one can do more harm than good.`,
    replyHi: `रत्न सिफारिशें केवल पूर्ण कुंडली विश्लेषण के बाद की जाती हैं — हम सामान्य रूप से पत्थरों की सिफारिश नहीं करते, क्योंकि गलत पत्थर फायदे से ज़्यादा नुकसान कर सकता है।`,
  },
  {
    id: "astro-dasha-explanation",
    label: "Dasha / Mahadasha",
    keywords: ["dasha explanation", "mahadasha meaning", "what is dasha", "महादशा क्या है", "दशा अर्थ", "महादशा"],
    replyEn: `Dasha (planetary periods) map out phases of life where certain themes are more active — used as timing context for your decisions, not fixed fate.`,
    replyHi: `दशा (ग्रह अवधि) जीवन के उन चरणों का मानचित्रण करती है जहाँ कुछ विषय अधिक सक्रिय होते हैं — आपके निर्णयों के लिए समय संदर्भ के रूप में उपयोग किया जाता है, तय भाग्य के रूप में नहीं।`,
  },
  {
    id: "astro-major-decisions",
    label: "Astrology for Major Decisions",
    keywords: ["astrology for major decision", "astrology big life decision", "बड़े फैसले के लिए ज्योतिष", "बड़ा फैसला"],
    replyEn: `Before any major decision — a business move, a relationship step, a career pivot — a chart reading can add timing context most people overlook.`,
    replyHi: `किसी भी बड़े निर्णय से पहले — व्यावसायिक कदम, रिश्ते का कदम, करियर बदलाव — कुंडली पढ़ने से समय संदर्भ जुड़ सकता है जिसे अधिकांश लोग नज़रअंदाज़ कर देते हैं।`,
  },
  {
    id: "astro-scientific-accuracy",
    label: "Is Astrology Scientific",
    keywords: ["is astrology scientific", "how accurate is astrology", "ज्योतिष कितना सटीक है", "वैज्ञानिक है क्या", "वैज्ञानिक", "सटीक"],
    replyEn: `We treat Vedic astrology as structured decision support, not superstition or guaranteed prediction — rigorous chart analysis applied practically, alongside real business experience.`,
    replyHi: `हम वैदिक ज्योतिष को संरचित निर्णय-सहायता के रूप में मानते हैं, अंधविश्वास या गारंटीशुदा भविष्यवाणी के रूप में नहीं — वास्तविक व्यावसायिक अनुभव के साथ, व्यावहारिक रूप से लागू सख्त कुंडली विश्लेषण।`,
  },
  {
    id: "astro-session-format",
    label: "Astrology Session Format",
    keywords: ["astrology session format", "how does astrology consultation work", "ज्योतिष सत्र कैसा होता है", "ज्योतिष सत्र"],
    replyEn: `Astrology sessions are a detailed chart walkthrough over video call, directly with Jitin — focused on your specific questions, not a generic reading.`,
    replyHi: `ज्योतिष सत्र वीडियो कॉल पर एक विस्तृत कुंडली वॉकथ्रू है, सीधे जितिन के साथ — आपके विशिष्ट प्रश्नों पर केंद्रित, सामान्य पठन नहीं।`,
  },
  {
    id: "astro-retrograde",
    label: "Retrograde Planets",
    keywords: ["retrograde planet effect", "mercury retrograde", "वक्री ग्रह प्रभाव", "वक्री"],
    replyEn: `Retrograde periods are often over-hyped online. In a real chart reading, we look at what it specifically means for your unique chart, not generic warnings.`,
    replyHi: `वक्री अवधियों को अक्सर ऑनलाइन बहुत बढ़ा-चढ़ाकर पेश किया जाता है। एक असली कुंडली पठन में, हम देखते हैं कि इसका आपकी अनूठी कुंडली के लिए विशेष रूप से क्या मतलब है, सामान्य चेतावनियाँ नहीं।`,
  },
  {
    id: "astro-health",
    label: "Astrology for Health Decisions",
    keywords: ["astrology health decision", "chart for health timing", "स्वास्थ्य के लिए ज्योतिष", "स्वास्थ्य ज्योतिष"],
    replyEn: `We can look at timing patterns related to wellbeing, but for any medical concern, please always consult a qualified doctor first — astrology is complementary, not a substitute.`,
    replyHi: `हम भलाई से संबंधित समय पैटर्न देख सकते हैं, लेकिन किसी भी चिकित्सा चिंता के लिए, कृपया हमेशा पहले एक योग्य डॉक्टर से सलाह लें — ज्योतिष पूरक है, विकल्प नहीं।`,
  },
  {
    id: "astro-online",
    label: "Astrology Consultation Online",
    keywords: ["astrology consultation online", "remote astrology session", "ऑनलाइन ज्योतिष परामर्श", "ऑनलाइन ज्योतिष"],
    replyEn: `Yes, all astrology consultations are conducted over video call — just share your accurate birth details (date, time, place) beforehand.`,
    replyHi: `हाँ, सभी ज्योतिष परामर्श वीडियो कॉल पर आयोजित किए जाते हैं — बस पहले अपना सटीक जन्म विवरण (तारीख, समय, स्थान) साझा करें।`,
  },
  {
    id: "astro-business-fusion",
    label: "Astrology + Business Fusion",
    keywords: ["astrology business fusion", "combine astrology and business", "ज्योतिष और व्यापार संयोजन", "ज्योतिष व्यापार"],
    replyEn: `This is exactly what makes our approach different — most advisors offer either pure business consulting or pure astrology. We bring both together, deliberately.`,
    replyHi: `यही है जो हमारे तरीके को अलग बनाता है — अधिकांश सलाहकार या तो शुद्ध व्यावसायिक परामर्श या शुद्ध ज्योतिष देते हैं। हम जानबूझकर दोनों को एक साथ लाते हैं।`,
  },
  {
    id: "astro-general",
    label: "Astrology General",
    keywords: ["astrology", "horoscope", "kundli", "dasha", "planet", "ज्योतिष", "कुंडली", "राशि", "ग्रह"],
    replyEn: `<strong>Vedic Astrology & Business Decisions:</strong><br/>
Through Vedic chart readings and Dasha timing metrics, Jitin advises on favorable periods for capital raising, leadership changes, and career direction — based on your Sun and Saturn placements.`,
    replyHi: `<strong>वैदिक ज्योतिष और व्यावसायिक निर्णय:</strong><br/>
कुंडली और दशा गणना के माध्यम से, जितिन पूँजी जुटाने, नेतृत्व परिवर्तन और करियर दिशा के लिए अनुकूल अवधियों पर मार्गदर्शन देते हैं — आपके सूर्य और शनि की स्थिति के आधार पर।`,
  },

  // ============ BOOKING / SERVICES (kept + expanded) ============
  {
    id: "booking",
    label: "Booking & Fees",
    keywords: ["how to book", "consultation fee", "booking process", "appointment cost", "बुक कैसे करें", "परामर्श शुल्क", "बुकिंग"],
    replyEn: `<strong>Booking is simple:</strong> click any service below to message Jitin directly on WhatsApp with your name and preferred time — he'll confirm your session personally.`,
    replyHi: `<strong>बुकिंग सरल है:</strong> नीचे किसी भी सेवा पर क्लिक करें और अपने नाम और पसंदीदा समय के साथ सीधे जितिन को व्हाट्सएप पर संदेश भेजें — वह व्यक्तिगत रूप से आपके सत्र की पुष्टि करेंगे।`,
  },
  {
    id: "services-overview",
    label: "All Services",
    keywords: ["what services", "services offered", "what do you offer", "सेवाएं क्या हैं", "क्या पेशकश करते हैं", "सेवाएं"],
    replyEn: `<strong>Our 4 Services:</strong><br/>
1. Business Strategy & Growth Consulting<br/>
2. Career & Professional Consulting<br/>
3. Personal Transformation Consulting<br/>
4. Cosmic Astrology Consultation<br/><br/>
<em>Click any to message Jitin directly on WhatsApp.</em>`,
    replyHi: `<strong>हमारी 4 सेवाएं:</strong><br/>
1. बिजनेस स्ट्रैटेजी परामर्श<br/>
2. करियर परामर्श<br/>
3. पर्सनल ट्रांसफॉर्मेशन परामर्श<br/>
4. कॉस्मिक एस्ट्रोलॉजी परामर्श<br/><br/>
<em>सीधे व्हाट्सएप पर जितिन को संदेश भेजने के लिए किसी पर भी क्लिक करें।</em>`,
  },
  {
    id: "difference-4-services",
    label: "Difference Between Services",
    keywords: ["difference between services", "how are the 4 services different", "चारों सेवाओं में अंतर", "सेवाओं में अंतर"],
    replyEn: `Business Strategy solves company problems, Career solves your professional path, Personal Transformation solves inner clarity, and Astrology adds timing to any of the three — they're connected, not separate silos.`,
    replyHi: `बिजनेस स्ट्रैटेजी कंपनी की समस्याओं को हल करती है, करियर आपके पेशेवर रास्ते को हल करता है, पर्सनल ट्रांसफॉर्मेशन आंतरिक स्पष्टता को हल करता है, और ज्योतिष इन तीनों में से किसी में भी समय जोड़ता है — ये जुड़े हुए हैं, अलग-अलग नहीं।`,
  },
  {
    id: "session-language",
    label: "Session Language",
    keywords: ["session in hindi", "consultation in english", "language of session", "सत्र किस भाषा में", "हिंदी में परामर्श", "हिंदी परामर्श"],
    replyEn: `Sessions are conducted in Hindi or English — whichever you're most comfortable with. Just let Jitin know when you book.`,
    replyHi: `सत्र हिंदी या अंग्रेज़ी में आयोजित किए जाते हैं — जिसमें भी आप सबसे सहज हों। बुक करते समय बस जितिन को बता दें।`,
  },
  {
    id: "numerology-general",
    label: "Numerology",
    keywords: ["numerology", "number meaning", "life path number", "अंकशास्त्र", "अंक ज्योतिष"],
    replyEn: `Numerology looks at the patterns in your name and birth date — useful for naming a business, understanding personal tendencies, or timing decisions. Try our free calculator on the site.`,
    replyHi: `अंकशास्त्र आपके नाम और जन्म तिथि के पैटर्न को देखता है — व्यवसाय के नामकरण, व्यक्तिगत प्रवृत्तियों को समझने, या निर्णयों का समय तय करने के लिए उपयोगी। साइट पर हमारा मुफ्त कैलकुलेटर आज़माएं।`,
  },
  {
    id: "why-not-free-apps",
    label: "Why Not Free Astrology Apps",
    keywords: ["why not use free astrology app", "difference from astrology app", "मुफ्त ज्योतिष ऐप से अंतर", "मुफ्त ऐप"],
    replyEn: `Free apps give generic, templated readings. Jitin combines a detailed personal chart reading with real business and career experience — context an app simply can't offer.`,
    replyHi: `मुफ्त ऐप्स सामान्य, टेम्पलेटेड पठन देते हैं। जितिन एक विस्तृत व्यक्तिगत कुंडली पठन को वास्तविक व्यावसायिक और करियर अनुभव के साथ जोड़ते हैं — ऐसा संदर्भ जो कोई ऐप नहीं दे सकता।`,
  },
  {
    id: "corporate-workshop",
    label: "Corporate Workshops",
    keywords: ["corporate workshop", "team training", "company-wide session", "कॉर्पोरेट कार्यशाला", "टीम ट्रेनिंग", "कार्यशाला"],
    replyEn: `For teams or organizations interested in a workshop format, message Jitin directly on WhatsApp to discuss what you have in mind.`,
    replyHi: `कार्यशाला प्रारूप में रुचि रखने वाली टीमों या संगठनों के लिए, आपके मन में जो है उस पर चर्चा करने के लिए सीधे जितिन को व्हाट्सएप पर संदेश भेजें।`,
  },
];
