// DEV-ONLY runtime performance instrumentation.
// Guarded by import.meta.env.DEV everywhere it's called from, so Vite's
// production build statically eliminates this entire module (dead-code
// elimination on the `if (import.meta.env.DEV)` branches that import/call
// it). No network requests, no telemetry, no third-party packages — only
// browser-native Performance APIs, purely for local console-inspection.

type PerfState = {
  started: boolean;
  rafCount: number;
  fpsWindowStart: number;
  fpsSamples: number[];
  longTasks: { count: number; longest: number };
  mutationCallbacks: number;
  scrollEvents: number;
  resizeEvents: number;
  pointerEvents: number;
  renderCounts: Record<string, number>;
  lcp: number | null;
  cls: number;
  interactions: number[];
};

const state: PerfState = {
  started: false,
  rafCount: 0,
  fpsWindowStart: 0,
  fpsSamples: [],
  longTasks: { count: 0, longest: 0 },
  mutationCallbacks: 0,
  scrollEvents: 0,
  resizeEvents: 0,
  pointerEvents: 0,
  renderCounts: {},
  lcp: null,
  cls: 0,
  interactions: [],
};

// Exported so the App-level MutationObserver (already in App.tsx) can bump
// this counter with a single extra line, without duplicating an observer.
export function notePerfMutation() {
  if (import.meta.env.DEV) state.mutationCallbacks++;
}

export function useRenderCountDev(name: string) {
  if (!import.meta.env.DEV) return;
  state.renderCounts[name] = (state.renderCounts[name] || 0) + 1;
}

function rafLoop(now: number) {
  state.rafCount++;
  if (!state.fpsWindowStart) state.fpsWindowStart = now;
  const elapsed = now - state.fpsWindowStart;
  if (elapsed >= 1000) {
    state.fpsSamples.push((state.rafCount * 1000) / elapsed);
    state.rafCount = 0;
    state.fpsWindowStart = now;
  }
  requestAnimationFrame(rafLoop);
}

export function startPerfInstrumentation() {
  if (!import.meta.env.DEV || state.started) return;
  state.started = true;

  requestAnimationFrame(rafLoop);

  const onScroll = () => state.scrollEvents++;
  const onResize = () => state.resizeEvents++;
  const onPointer = () => state.pointerEvents++;
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onResize, { passive: true });
  window.addEventListener("pointermove", onPointer, { passive: true });

  try {
    const longTaskObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        state.longTasks.count++;
        state.longTasks.longest = Math.max(state.longTasks.longest, entry.duration);
      }
    });
    longTaskObserver.observe({ type: "longtask", buffered: true });
  } catch {
    /* longtask not supported in this browser */
  }

  try {
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const last = entries[entries.length - 1] as any;
      if (last) state.lcp = last.renderTime || last.loadTime;
    });
    lcpObserver.observe({ type: "largest-contentful-paint", buffered: true });
  } catch {
    /* not supported */
  }

  try {
    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries() as any[]) {
        if (!entry.hadRecentInput) state.cls += entry.value;
      }
    });
    clsObserver.observe({ type: "layout-shift", buffered: true });
  } catch {
    /* not supported */
  }

  try {
    const eventObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries() as any[]) {
        state.interactions.push(entry.duration);
      }
    });
    eventObserver.observe({ type: "event", buffered: true, durationThreshold: 16 } as any);
  } catch {
    /* not supported */
  }

  (window as any).printPerfSummary = () => {
    const avgFps = state.fpsSamples.length
      ? (state.fpsSamples.reduce((a, b) => a + b, 0) / state.fpsSamples.length).toFixed(1)
      : "n/a";
    const nav = performance.getEntriesByType("navigation")[0] as any;
    const mem = (performance as any).memory;

    console.log(
      "%c--- Perf Summary ---",
      "font-weight:bold;color:#8B4A33",
      "\nAvg FPS:", avgFps,
      "\nLong Tasks:", state.longTasks.count, "| Longest:", state.longTasks.longest.toFixed(1), "ms",
      "\nMutationObserver callbacks:", state.mutationCallbacks,
      "\nScroll events:", state.scrollEvents,
      "\nResize events:", state.resizeEvents,
      "\nPointer events:", state.pointerEvents,
      "\nRender counts:", state.renderCounts,
      "\nMemory (MB):", mem ? (mem.usedJSHeapSize / 1048576).toFixed(1) : "n/a",
      "\nLCP (ms):", state.lcp ? state.lcp.toFixed(0) : "n/a",
      "\nCLS:", state.cls.toFixed(4),
      "\nSlow interactions (>16ms):", state.interactions.length,
      "\nNav — domContentLoaded:", nav ? nav.domContentLoadedEventEnd.toFixed(0) : "n/a",
      "ms | load:", nav ? nav.loadEventEnd.toFixed(0) : "n/a", "ms",
    );
  };

  console.log(
    "%c[perf] Instrumentation active (dev-only). Run window.printPerfSummary() in the console after interacting with the page.",
    "color:#8B4A33",
  );
}
