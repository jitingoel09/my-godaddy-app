import { useState, useEffect } from 'react';

export const HERO_IMAGE_KEY = 'custom_hero_image';
export const PROFILE_IMAGE_KEY = 'custom_profile_image';

export function useCustomImages() {
  const [heroImage, setHeroImage] = useState<string | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);

  useEffect(() => {
    const updateImages = () => {
      setHeroImage(localStorage.getItem(HERO_IMAGE_KEY));
      setProfileImage(localStorage.getItem(PROFILE_IMAGE_KEY));
    };

    updateImages();

    window.addEventListener('custom_images_updated', updateImages);
    return () => window.removeEventListener('custom_images_updated', updateImages);
  }, []);

  return { heroImage, profileImage };
}
