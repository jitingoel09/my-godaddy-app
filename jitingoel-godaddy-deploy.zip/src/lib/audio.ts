class AudioEngine {
  private ctx: AudioContext | null = null;
  private primaryOsc: OscillatorNode | null = null;
  private secondaryOsc: OscillatorNode | null = null;
  private masterGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private lfo: OscillatorNode | null = null;
  private lfoGain: GainNode | null = null;
  public isPlaying: boolean = false;
  private subscribers: Array<(playing: boolean) => void> = [];

  subscribe(callback: (playing: boolean) => void) {
    this.subscribers.push(callback);
    callback(this.isPlaying);
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb(this.isPlaying));
  }

  init() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    
    this.ctx = new AudioContextClass();
  }

  play() {
    if (!this.ctx) this.init();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    if (this.isPlaying) return;
    this.isPlaying = true;
    this.notify();

    // Master Gain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0, this.ctx.currentTime);
    // Smooth fade in over 5 seconds for ambient feel
    this.masterGain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 5);
    this.masterGain.connect(this.ctx.destination);

    // Filter
    this.filter = this.ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.setValueAtTime(200, this.ctx.currentTime);
    this.filter.connect(this.masterGain);

    // LFO for filter sweep (cosmic breathing effect)
    this.lfo = this.ctx.createOscillator();
    this.lfo.type = 'sine';
    this.lfo.frequency.setValueAtTime(0.05, this.ctx.currentTime); // very slow
    this.lfoGain = this.ctx.createGain();
    this.lfoGain.gain.setValueAtTime(100, this.ctx.currentTime);
    this.lfo.connect(this.lfoGain);
    this.lfoGain.connect(this.filter.frequency);
    this.lfo.start();

    // Primary Oscillator (Drone Base)
    this.primaryOsc = this.ctx.createOscillator();
    this.primaryOsc.type = 'sine';
    // Frequency corresponding to a low Om/Cosmic frequency (around 108Hz or 136.1Hz - Om frequency)
    this.primaryOsc.frequency.setValueAtTime(136.1, this.ctx.currentTime); 
    this.primaryOsc.connect(this.filter);
    this.primaryOsc.start();

    // Secondary Oscillator (Harmonic)
    this.secondaryOsc = this.ctx.createOscillator();
    this.secondaryOsc.type = 'triangle';
    this.secondaryOsc.frequency.setValueAtTime(136.1 * 1.5, this.ctx.currentTime); // Perfect fifth
    const secondaryGain = this.ctx.createGain();
    secondaryGain.gain.setValueAtTime(0.4, this.ctx.currentTime);
    this.secondaryOsc.connect(secondaryGain);
    secondaryGain.connect(this.filter);
    this.secondaryOsc.start();
  }

  stop() {
    if (!this.ctx || !this.isPlaying || !this.masterGain) return;
    
    // Smooth fade out
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, this.ctx.currentTime);
    this.masterGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 3);
    
    setTimeout(() => {
      this.primaryOsc?.stop();
      this.secondaryOsc?.stop();
      this.lfo?.stop();
      this.primaryOsc?.disconnect();
      this.secondaryOsc?.disconnect();
      this.lfo?.disconnect();
      this.filter?.disconnect();
      this.masterGain?.disconnect();
      this.isPlaying = false;
      this.notify();
    }, 3000);
  }

  playChime() {
    if (!this.ctx || !this.isPlaying) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    
    // Sine wave for clear, pure tone
    osc.type = 'sine';
    // Frequency corresponding to a higher harmonic of the base frequency
    osc.frequency.setValueAtTime(136.1 * 4, this.ctx.currentTime); // 544.4 Hz
    // Add a slight pitch sweep for "magical" feel
    osc.frequency.exponentialRampToValueAtTime(136.1 * 8, this.ctx.currentTime + 0.1); 

    // Envelope for a bell/chime like sound
    gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.1, this.ctx.currentTime + 0.02); // quick attack
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.8); // longer tail

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 1);
  }

  playHoverSwell() {
    if (!this.ctx || !this.isPlaying) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    
    osc.type = 'sine';
    // Frequency relating to the base drone, an octave up + arbitrary ratio for ethereal feel
    osc.frequency.setValueAtTime(136.1 * 2, this.ctx.currentTime); 

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(400, this.ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.2); // filter sweep up
    filter.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.6); // filter sweep down

    // Swell envelope: fade in, fade out
    gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.03, this.ctx.currentTime + 0.2);
    gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.6);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.6);
  }

  toggle() {
    if (this.isPlaying) {
      this.stop();
    } else {
      this.play();
    }
  }
}

export const audioEngine = new AudioEngine();
