import { blogPosts } from "../data/blogPosts";

// Helper function to optimize Unsplash URLs dynamically for different screen sizes and device pixel densities.
// Utilizing 'auto=format' negotiates modern, high-compression formats like WebP or AVIF natively, 
// providing exceptional speeds on Android devices and gorgeous crispness on high-DPI Apple Retina displays.
export function optimizeUnsplash(url: string, width = 800, height = 500, quality = 80): string {
  if (!url || !url.includes("images.unsplash.com")) {
    return url;
  }
  const [baseUrl] = url.split("?");
  return `${baseUrl}?auto=format&fit=crop&q=${quality}&w=${width}&h=${height}`;
}

import glassPatternImg from "../assets/images/cosmic_starfield_timing.webp";

export const servicesImages = {
  businessGrowth: "https://images.unsplash.com/photo-1552664730-d307ca884978",
  careerCoaching: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2",
  careerConsulting: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7",
  lifeTransformation: "https://images.unsplash.com/photo-1506126613408-eca07ce68773",
  vedicAstrology: glassPatternImg,
};

export const faqImage = "https://images.unsplash.com/photo-1451187580459-43490279c0fa"; 

export const contactImage = "https://images.unsplash.com/photo-1507679799987-c73779587ccf"; 

export const valuePropImages = {
  standardApproach: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e", 
  jitinGoelEdge: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab", 
};

// Highly targeted Unsplash photography mapped exactly to the headline of each of the 27 blog posts (Primary Banner Images)
export const blogImagesMap: Record<number, string> = {
  1: "https://images.unsplash.com/photo-1509228468518-180dd4864904", // The Numerology of Business Names
  2: "https://images.unsplash.com/photo-1497366216548-37526070297c", // Vastu in the Workspace
  3: "https://images.unsplash.com/photo-1560250097-0b93528c311a", // Career Growth After 40
  4: "https://images.unsplash.com/photo-1532960401447-7dd05bef20b0", // Timing and Success: Strategy Meets Astrology
  5: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7", // Leadership Lessons from Real Life Challenges
  6: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0", // The Power of Sade Sati: Restructuring
  7: "https://images.unsplash.com/photo-1531538606174-0f90ff5dce83", // Corporate Workshops: Team Cosmic Rhythms
  8: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3", // Finding Your Life Path Number
  9: "https://images.unsplash.com/photo-1543269865-cbf427effbad", // Overcoming Imposter Syndrome
  10: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c", // Vastu for Wealth: North/East Directions
  11: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a", // Mercury Retrograde in Business
  12: "https://images.unsplash.com/photo-1460925895917-afdab827c52f", // The Art of the Pivot
  13: "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5", // Personal Consulting
  14: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e", // The Sun's Placement: Your Core Confidence
  15: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e", // Mastering the Interview: Coach View
  16: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44", // Number 8 in Business: Karma of Wealth
  17: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38", // Color Therapy in Vastu
  18: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f", // Building Resilience in Startups
  19: "https://images.unsplash.com/photo-1532693322450-2cb5c511067d", // The Moon and Mental Health
  20: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7", // Effective Conflict Resolution in Teams
  21: "https://images.unsplash.com/photo-1441986300917-64674bd600d8", // Venus and Luxury Branding
  22: "https://images.unsplash.com/photo-1470246973918-29a93221c455", // The 5 Elements of Work-Life Balance
  23: "https://images.unsplash.com/photo-1512820790803-83ca734da794", // Name Change post-Marriage
  24: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85", // Sleeping Layouts: Vastu for Deep Rest
  25: "https://images.unsplash.com/photo-1455390582262-044cdead277a", // Scaling from 1M to 10M
  26: "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2", // Identifying Burnout Before It Hits
  27: "https://images.unsplash.com/photo-1451187580459-43490279c0fa", // Jupiter's Transit
};

// Highly customized, premium branded placeholder image library for each category topic.
// These guarantee beautiful, high-resolution photographs that cycle per article ID, ensuring non-repeating visuals.
export const blogPlaceholdersLibrary: Record<string, string[]> = {
  "Numerology": [
    "https://images.unsplash.com/photo-1509228468518-180dd4864904", // Vintage calculations
    "https://images.unsplash.com/photo-1628157582853-a796fa650a6a", // Golden codes and digital structures
    "https://images.unsplash.com/photo-1453733190148-c44698c26588", // Retro sandglass timer 
    "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3", // Detailed complex geometric digits
  ],
  "Vastu Shastra": [
    "https://images.unsplash.com/photo-1497366216548-37526070297c", // Elegant bright corporate workspace lobby
    "https://images.unsplash.com/photo-1618219908412-a29a1bb7b86e", // Dynamic wooden desk working area
    "https://images.unsplash.com/photo-1513519245088-0e12902e5a38", // Symmetrical color & light interior balance
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c", // Clean natural architecture layout
  ],
  "Career Consulting": [
    "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e", // High poise corporate mentoring presenter
    "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40", // Laptop, resumes & analytical planning
    "https://images.unsplash.com/photo-1560250097-0b93528c311a", // Elite officer overlooking high-growth sky horizons
    "https://images.unsplash.com/photo-1522202176988-66273c2fd55f", // Active collaborative team discussion
  ],
  "Vedic Astrology": [
    "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a", // Deep dazzling star celestial cosmic galaxy
    "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0", // Rare antique golden brass astronomical scope
    "https://images.unsplash.com/photo-1451187580459-43490279c0fa", // Starry celestial pathways & networking orbits
    "https://images.unsplash.com/photo-1532960401447-7dd05bef20b0", // Beautiful starry sky with glowing constellations
  ],
  "Business Strategy": [
    "https://images.unsplash.com/photo-1460925895917-afdab827c52f", // High-growth business strategy dashboard
    "https://images.unsplash.com/photo-1551836022-d5d88e9218df", // Boardroom collaborative consultation
    "https://images.unsplash.com/photo-1455390582262-044cdead277a", // Notes outline on clean leather workstation
    "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab", // Skyscraper tall architecture ascending with utmost clarity
  ],
  "Personal Transformation": [
    "https://images.unsplash.com/photo-1506126613408-eca07ce68773", // Tranquil seaside yogic wellness meditation
    "https://images.unsplash.com/photo-1499209974431-9dddcece7f88", // Bright sunbeams morning horizon breakthrough
    "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5", // Serene peaceful pathway in glowing clean woods
    "https://images.unsplash.com/photo-1507525428034-b723cf961d3e", // Soft sandy beach quiet meditative dawn
  ],
  "Corporate Workshops": [
    "https://images.unsplash.com/photo-1531538606174-0f90ff5dce83", // Interactive team training engagement
    "https://images.unsplash.com/photo-1522071820081-009f0129c71c", // Aligned group active workshop brainstorming
    "https://images.unsplash.com/photo-1515187029135-18ee286d815b", // Elite corporate seminar event mapping Jitin Goel style
    "https://images.unsplash.com/photo-1542744173-8e0ee26df799", // Strategic workshop design maps and agile outline
  ],
  "Professional Consulting": [
    "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7", // Elite corporate coach advising passionately
    "https://images.unsplash.com/photo-1565728741316-652317a766fc", // Professional guiding profile notes
    "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40", // Clean high contrast workspace with notebook and laptop 
    "https://images.unsplash.com/photo-1507679799987-c73779587ccf", // Executive coach outlook & strategic pathways
  ],
};

// Central primary blog image getter with responsive optimization
export function getBlogImage(postId: number, category?: string): string {
  let rawUrl = "https://images.unsplash.com/photo-1518156677180-95a2893f3e9f";
  
  if (postId && blogImagesMap[postId]) {
    rawUrl = blogImagesMap[postId];
  } else {
    let postCategory = category;
    if (!postCategory) {
      const post = blogPosts.find((p) => p.id === postId);
      postCategory = post?.category;
    }

    if (postCategory && blogPlaceholdersLibrary[postCategory]) {
      const list = blogPlaceholdersLibrary[postCategory];
      const index = postId % list.length;
      rawUrl = list[index];
    }
  }

  return optimizeUnsplash(rawUrl, 1200, 750, 85); // High quality responsive dimensions for primary layout banner
}

// 100% unique, non-repeating, carefully aligned secondary photography maps for each of the 27 specific blog items
export const blogPostSecondaryMap: Record<number, string> = {
  1: "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23", // Business Names - meeting room discussions
  2: "https://images.unsplash.com/photo-1497366216548-37526070297c", // Vastu Workspace - beautiful office lobby structure
  3: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2", // Career Over 40 - confident executive mentor advisor
  4: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0", // Timing and Success - majestic brass scope
  5: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7", // Leadership Lessons - presenter showing strategic slides
  6: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a", // Sade Sati - sublime starry deep nebula space
  7: "https://images.unsplash.com/photo-1531538606174-0f90ff5dce83", // Corporate Workshops - dynamic teamwork brainstorming
  8: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a", // Life Path Number - golden numeric algorithm codes
  9: "https://images.unsplash.com/photo-1534528741775-53994a69daeb", // Imposter Syndrome - candid, thoughtful executive reflection
  10: "https://images.unsplash.com/photo-1600585154526-990dced4db0d", // Vastu Wealth - symmetrical modern residential courtyard
  11: "https://images.unsplash.com/photo-1451187580459-43490279c0fa", // Mercury Retrograde - stellar networking orbits
  12: "https://images.unsplash.com/photo-1519389950473-47ba0277781c", // Art of the Pivot - team changing strategy board direction
  13: "https://images.unsplash.com/photo-1506126613408-eca07ce68773", // Personal Transformation - quiet meditation seaside
  14: "https://images.unsplash.com/photo-1531844251246-9a1bfaae0d76", // Sun Placement - beautiful solar twilight skyline
  15: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e", // Mastering Interview - candid candidate presenting poise
  16: "https://images.unsplash.com/photo-1453733190148-c44698c26588", // Number 8 Karma - vintage dual glass hourglass loop
  17: "https://images.unsplash.com/photo-1513694203232-719a280e022f", // Color Vastu - warm light ray filtering into colored space
  18: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4", // Startup Resilience - founders high fiving in office
  19: "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5", // Moon and Support - silent pathway forest night calmness
  20: "https://images.unsplash.com/photo-1521737711867-e3b97375f902", // Conflict Resolution - coordinator aligning professional teams
  21: "https://images.unsplash.com/photo-1441986300917-64674bd600d8", // Venus Luxury - ultimate luxury fashion boutique storefront
  22: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b", // 5 Elements Balance - healthy early morning yoga stretching
  23: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8", // Name Change - proposal rings ceremony
  24: "https://images.unsplash.com/photo-1505693314120-0d443867891c", // Sleeping Layouts - quiet layout natural lit cozy bedroom
  25: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40", // Scaling 1M to 10M - analytic charts workspace laptop
  26: "https://images.unsplash.com/photo-1512486130939-2c4f79935e4f", // Burnout Identification - tired professional resting eyes
  27: "https://images.unsplash.com/photo-1532960401447-7dd05bef20b0", // Jupiter Transit - starry system constellation map
};

export function getBlogSecondaryImage(postId: number, category: string): string {
  let rawUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa";
  
  if (postId && blogPostSecondaryMap[postId]) {
    rawUrl = blogPostSecondaryMap[postId];
  } else if (category && blogPlaceholdersLibrary[category]) {
    const list = blogPlaceholdersLibrary[category];
    const index = (postId + 1) % list.length;
    rawUrl = list[index];
  }

  return optimizeUnsplash(rawUrl, 800, 500, 80); // Structured premium layout optimization query
}

// 100% unique, non-repeating, carefully aligned tertiary photography maps for each of the 27 specific blog items
export const blogPostTertiaryMap: Record<number, string> = {
  1: "https://images.unsplash.com/photo-1542744094-3a31f103e35f", // Business Names - real-time metrics analytical dashboard
  2: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7", // Vastu Workspace - balanced office desk designs
  3: "https://images.unsplash.com/photo-1507679799987-c73779587ccf", // Career Over 40 - executive looking at horizon
  4: "https://images.unsplash.com/photo-1534447677768-be436bb09401", // Timing and Success - celestial lightwaves cosmos
  5: "https://images.unsplash.com/photo-1522071820081-009f0129c71c", // Leadership Lessons - dynamic team execution and targets
  6: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d", // Sade Sati - smiling proud senior executive confident of lessons
  7: "https://images.unsplash.com/photo-1515187029135-18ee286d815b", // Corporate Workshops - premium grand lecture seminar event
  8: "https://images.unsplash.com/photo-1509228468518-180dd4864904", // Life Path Number - sacred notebook layouts & math formulas
  9: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d", // Imposter Syndrome - trusted senior adviser portrait
  10: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750", // Vastu Wealth - stunning, sunlit luxury penthouse salon
  11: "https://images.unsplash.com/photo-1450133064473-71024230f91b", // Mercury Retrograde - corporate signature contract review
  12: "https://images.unsplash.com/photo-1460925895917-afdab827c52f", // Art of the Pivot - financial forecast strategy board
  13: "https://images.unsplash.com/photo-1499209974431-9dddcece7f88", // Personal Transformation - majestic sunrise morning mist
  14: "https://images.unsplash.com/photo-1560250097-0b93528c311a", // Sun Placement - executive observing skyscrapers skyline
  15: "https://images.unsplash.com/photo-1551836022-d5d88e9218df", // Mastering Interview - professional mentoring session feedback
  16: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3", // Number 8 Karma - complex equations on blackboard representing cosmic math
  17: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6", // Color Vastu - symmetric feng shui colorful room decor
  18: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab", // Startup Resilience - corporate high-rise architect building safety
  19: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e", // Moon and Support - silent night starry coast seaside reflection
  20: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7", // Conflict Resolution - harmonious creative team room
  21: "https://images.unsplash.com/photo-1441984969893-c5a6e09c89bb", // Venus Luxury - glass luxury bottle aesthetic reflections
  22: "https://images.unsplash.com/photo-1502082553048-f009c37129b9", // 5 Elements Balance - majestic green wilderness forest elements Vastu canopy
  23: "https://images.unsplash.com/photo-1455390582262-044cdead277a", // Name Change - hand signing legal documents with ink pen
  24: "https://images.unsplash.com/photo-1618219908412-a29a1bb7b86e", // Sleeping Layouts - clean, beautiful Vastu bedroom layouts
  25: "https://images.unsplash.com/photo-1451187580459-43490279c0fa", // Scaling 1M to 10M - infinite global network grid data connection
  26: "https://images.unsplash.com/photo-1499209974431-9dddcece7f88", // Burnout Identification - bright sun rising over valley
  27: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a", // Jupiter Transit - grand nebula universe stars
};

export function getBlogTertiaryImage(postId: number, category: string): string {
  let rawUrl = "https://images.unsplash.com/photo-1518156677180-95a2893f3e9f";
  
  if (postId && blogPostTertiaryMap[postId]) {
    rawUrl = blogPostTertiaryMap[postId];
  } else if (category && blogPlaceholdersLibrary[category]) {
    const list = blogPlaceholdersLibrary[category];
    const index = (postId + 2) % list.length;
    rawUrl = list[index];
  }

  return optimizeUnsplash(rawUrl, 800, 500, 80); // Structured premium layout optimization query
}
