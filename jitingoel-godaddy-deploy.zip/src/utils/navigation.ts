/**
 * Bulletproof link Opener for seamless cross-device compatibility (Desktop, Android, iOS, and iframe environments).
 * Simulates a direct anchor tag click attached to the document body to prevent mobile popup-blockers
 * and sandboxed iframe restrictions from blocking external redirections like WhatsApp.
 */
export function safeOpenLink(url: string) {
  if (!url) return;

  try {
    // Generate anchor element
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    
    // Append to body temporarily
    document.body.appendChild(anchor);
    
    // Simulate user interaction click
    anchor.click();
    
    // Cleanup
    document.body.removeChild(anchor);
  } catch (error) {
    console.error("Error opening link safely, falling back directly:", error);
    // Ultimate fallback if DOM interaction fails
    window.location.href = url;
  }
}
